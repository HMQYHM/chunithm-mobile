'use strict';

// QQ 官方机器人适配器。命令本身只负责权限、参数和回复；
// 群组加入码、设备群组变更和审计仍由服务端回调完成。
const https = require('https');
const http = require('http');
const crypto = require('crypto');

const OP = { DISPATCH: 0, HEARTBEAT: 1, IDENTIFY: 2, RESUME: 6, RECONNECT: 7, INVALID_SESSION: 9, HELLO: 10, HEARTBEAT_ACK: 11 };
const INTENTS = (1 << 30) | (1 << 25) | (1 << 26) | (1 << 27); // guild message + group/c2c events

function requestJson(urlString, options = {}, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlString);
    const request = https.request({
      protocol: url.protocol,
      hostname: url.hostname,
      port: url.port || 443,
      path: url.pathname + url.search,
      method: options.method || 'GET',
      headers: { Accept: 'application/json', ...(options.headers || {}) }
    }, response => {
      const chunks = [];
      response.on('data', chunk => chunks.push(chunk));
      response.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let value = {};
        try { value = text ? JSON.parse(text) : {}; } catch (_) { value = { raw: text }; }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          const error = new Error(value.message || value.msg || `QQ API HTTP ${response.statusCode}`);
          error.statusCode = response.statusCode;
          error.body = value;
          return reject(error);
        }
        resolve(value);
      });
    });
    request.on('error', reject);
    request.setTimeout(15000, () => request.destroy(new Error('QQ API request timeout')));
    if (body !== null) request.write(JSON.stringify(body));
    request.end();
  });
}

function wsFrame(payload, opcode = 1) {
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(payload);
  const mask = crypto.randomBytes(4);
  const masked = Buffer.alloc(body.length);
  for (let i = 0; i < body.length; i += 1) masked[i] = body[i] ^ mask[i % 4];
  let header;
  if (body.length < 126) header = Buffer.from([0x80 | opcode, 0x80 | body.length]);
  else if (body.length < 65536) { header = Buffer.alloc(4); header[0] = 0x80 | opcode; header[1] = 0x80 | 126; header.writeUInt16BE(body.length, 2); }
  else { header = Buffer.alloc(10); header[0] = 0x80 | opcode; header[1] = 0x80 | 127; header.writeBigUInt64BE(BigInt(body.length), 2); }
  return Buffer.concat([header, mask, masked]);
}

class GatewaySocket {
  constructor(url, handlers, headers = {}) { this.url = new URL(url); this.handlers = handlers; this.headers = headers; this.buffer = Buffer.alloc(0); this.socket = null; this.closed = false; }
  connect() {
    return new Promise((resolve, reject) => {
      const key = crypto.randomBytes(16).toString('base64');
      const transport = this.url.protocol === 'wss:' ? https : http;
      const request = transport.request({ hostname: this.url.hostname, port: this.url.port || (this.url.protocol === 'wss:' ? 443 : 80), path: this.url.pathname + this.url.search,
        method: 'GET', headers: { Upgrade: 'websocket', Connection: 'Upgrade', 'Sec-WebSocket-Key': key, 'Sec-WebSocket-Version': '13', ...this.headers } });
      request.once('upgrade', (_response, socket) => {
        this.socket = socket; socket.setNoDelay(true); socket.on('data', chunk => this.receive(chunk));
        socket.on('error', error => this.handlers.error(error)); socket.on('close', () => this.handlers.close()); resolve();
      });
      request.once('response', response => reject(new Error(`QQ Gateway rejected WebSocket upgrade: ${response.statusCode}`)));
      request.once('error', reject); request.end();
    });
  }
  receive(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (this.buffer.length >= 2) {
      const first = this.buffer[0]; const second = this.buffer[1]; let length = second & 0x7f; let offset = 2;
      if (length === 126) { if (this.buffer.length < 4) return; length = this.buffer.readUInt16BE(2); offset = 4; }
      else if (length === 127) { if (this.buffer.length < 10) return; const longLength = this.buffer.readBigUInt64BE(2); if (longLength > BigInt(16 * 1024 * 1024)) return this.close(); length = Number(longLength); offset = 10; }
      if (this.buffer.length < offset + length) return;
      const payload = this.buffer.subarray(offset, offset + length); this.buffer = this.buffer.subarray(offset + length);
      const opcode = first & 0x0f;
      if (opcode === 1) { try { this.handlers.message(JSON.parse(payload.toString('utf8'))); } catch (_) {} }
      else if (opcode === 8) return this.close();
      else if (opcode === 9) this.send('', 10);
    }
  }
  send(value, opcode = 1) { if (this.socket && !this.closed) this.socket.write(wsFrame(typeof value === 'string' ? value : JSON.stringify(value), opcode)); }
  close() { if (this.closed) return; this.closed = true; try { this.send('', 8); } catch (_) {} try { this.socket?.destroy(); } catch (_) {} }
}

function safeText(value, max = 120) {
  // Keep line feeds so QQ renders structured command responses correctly.
  return String(value ?? '').replace(/\r\n?/g, '\n')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').slice(0, max);
}
function duration(ms) { const seconds = Math.max(0, Math.floor(ms / 1000)); const h = Math.floor(seconds / 3600); const m = Math.floor((seconds % 3600) / 60); const s = seconds % 60; return h ? `${h}小时${m}分` : `${m}分${s}秒`; }
function persistentLibraryText(selection) {
  const value = selection || {};
  if (value.mode === 'songs') return `指定歌曲：${(value.songIds || []).join('、') || '未设置'}`;
  if (value.mode === 'levels') return `指定等级：${(value.levels || []).join('、') || '未设置'}`;
  if (value.mode === 'random') {
    const levels = (value.levels || []).join('、') || '全部等级';
    return value.randomCount === 0 ? `随机循环：${levels}` : `随机：${levels}，数量 ${value.randomCount || 1}`;
  }
  return '全部曲库';
}
function persistentStateText(state) {
  return ({ lobby: '等待中', syncing: '同步中', loading: '加载中', countdown: '倒计时', playing: '游玩中', personalResults: '个人结算', groupResults: '多人结算' })[state] || state || '未知';
}

class QQBot {
  constructor(options) {
    this.getConfig = options.getConfig; this.getPublicRooms = options.getPublicRooms; this.getAdminOverview = options.getAdminOverview;
    this.getRecentLogins = options.getRecentLogins || (() => ({ items: [], expiresAt: Date.now() }));
    this.consumeGroupJoinCode = options.consumeGroupJoinCode || (() => ({ error: '服务端未启用群组加入码。' }));
    this.createGroupJoinCodes = options.createGroupJoinCodes || (() => ({ error: { message: '服务端未启用群组加入码。' } }));
    this.listGroupJoinCodes = options.listGroupJoinCodes || (() => []);
    this.setGroupJoinCodeStatus = options.setGroupJoinCodeStatus || (() => ({ error: { message: '服务端未启用群组加入码。' } }));
    this.audit = options.audit;
    this.recordChat = options.recordChat || (() => {}); this.consumeBindingCode = options.consumeBindingCode || (() => false);
    this.log = options.log || (() => {}); this.socket = null; this.accessToken = ''; this.sequence = null; this.sessionId = ''; this.heartbeatTimer = null; this.reconnectTimer = null; this.running = false; this.stopped = true; this.rate = new Map(); this.logs = []; this.seenMessages = new Map(); this.replySequences = new Map(); this.recentSnapshots = new Map();
  }
  config() { return this.getConfig() || {}; }
  provider() { return this.config().provider === 'napcat' ? 'napcat' : 'official'; }
  enabledConfig() { const value = this.config(); return value.enabled && (this.provider() === 'napcat' ? value.oneBotUrl : value.appId && value.appSecret); }
  status() { return { provider: this.provider(), enabled: Boolean(this.enabledConfig()), connected: Boolean(this.socket && !this.socket.closed), sessionId: this.sessionId || '', selfId: this.selfId || '', logs: this.logs.slice(-80).reverse() }; }
  addLog(message, level = 'info') { const entry = { at: new Date().toISOString(), level, message: safeText(message, 240) }; this.logs.push(entry); if (this.logs.length > 100) this.logs.shift(); this.log(`[qq-bot] ${entry.message}`); }
  async start() { this.stopped = false; if (!this.enabledConfig()) { this.addLog(this.provider() === 'napcat' ? '未配置 OneBot WebSocket 地址，Bot 保持关闭。' : '未配置 AppID/AppSecret，Bot 保持关闭。', 'warn'); return; } await this.connect(); }
  stop() { this.stopped = true; clearTimeout(this.reconnectTimer); clearInterval(this.heartbeatTimer); this.reconnectTimer = null; this.heartbeatTimer = null; if (this.socket) this.socket.close(); this.socket = null; this.addLog('Bot 已停止。'); }
  scheduleReconnect() { if (this.stopped || this.reconnectTimer) return; this.reconnectTimer = setTimeout(() => { this.reconnectTimer = null; this.connect().catch(() => {}); }, 5000); }
  async getToken() {
    const value = this.config(); const result = await requestJson('https://bots.qq.com/app/getAppAccessToken', { method: 'POST', headers: { 'Content-Type': 'application/json' } }, { appId: value.appId, clientSecret: value.appSecret });
    if (!result.access_token) throw new Error('QQ access token response did not contain access_token');
    return result.access_token;
  }
  async connect() {
    if (this.running || this.stopped || !this.enabledConfig()) return;
    this.running = true; try {
      if (this.provider() === 'napcat') return await this.connectNapCat();
      this.accessToken = await this.getToken();
      const apiBase = this.config().apiBase || 'https://api.sgroup.qq.com';
      const gateway = await requestJson(`${apiBase}/gateway`, { headers: { Authorization: `QQBot ${this.accessToken}` } });
      const gatewayUrl = gateway.url || gateway.data?.url; if (!gatewayUrl) throw new Error('QQ Gateway URL missing');
      const socket = new GatewaySocket(gatewayUrl, { message: value => this.onMessage(value), error: error => this.addLog(error.message, 'error'), close: () => { this.socket = null; clearInterval(this.heartbeatTimer); this.addLog('Gateway 已断开。', 'warn'); this.scheduleReconnect(); } });
      await socket.connect(); this.socket = socket; this.addLog('Gateway 已连接。');
    } catch (error) { this.addLog(`连接失败：${error.message}`, 'error'); this.scheduleReconnect(); } finally { this.running = false; }
  }
  async connectNapCat() {
    const value = this.config();
    const url = String(value.oneBotUrl || '');
    if (!/^wss?:\/\//i.test(url)) throw new Error('NapCat OneBot 地址必须使用 ws:// 或 wss://');
    const headers = value.oneBotToken ? { Authorization: `Bearer ${value.oneBotToken}` } : {};
    const socket = new GatewaySocket(url, {
      message: event => this.onNapCatEvent(event),
      error: error => this.addLog(`OneBot 连接错误：${error.message}`, 'error'),
      close: () => { this.socket = null; this.addLog('OneBot WebSocket 已断开。', 'warn'); this.scheduleReconnect(); }
    }, headers);
    await socket.connect();
    if (this.stopped) { socket.close(); return; }
    this.socket = socket;
    this.addLog(`NapCat OneBot 已连接：${new URL(url).origin}（令牌不记录）。`);
  }
  onNapCatEvent(event = {}) {
    if (event.post_type === 'meta_event' && event.meta_event_type === 'lifecycle' && event.sub_type === 'connect') {
      this.selfId = String(event.self_id || '');
      this.addLog(`OneBot 生命周期已连接，QQ=${this.selfId || '未知'}。`);
      return;
    }
    if (event.post_type === 'notice' && event.notice_type === 'notify' && event.sub_type === 'poke') {
      this.handleNapCatPoke(event).catch(error => this.addLog(`戳一戳指令失败：${error.message}`, 'error'));
      return;
    }
    if (event.post_type !== 'message' || !['group', 'private'].includes(event.message_type)) return;
    if (event.message_type === 'group' && !['', 'normal', 'anonymous'].includes(event.sub_type || '')) return;
    const group = event.message_type === 'group';
    const configuredGroups = Array.isArray(this.config().oneBotGroupAllowlist) ? this.config().oneBotGroupAllowlist : [];
    if (group && this.config().oneBotGroupOnly && !configuredGroups.includes(String(event.group_id || ''))) return;
    if (!group && this.config().oneBotPrivateReplies === false) return;
    const containsImage = Array.isArray(event.message) && event.message.some(segment => segment?.type === 'image');
    const content = Array.isArray(event.message)
      ? event.message.filter(segment => segment?.type === 'text' || (segment?.type === 'image' && this.config().recordOneBotImages))
        .map(segment => segment.type === 'image' ? '[图片]' : segment.data?.text || '').join('')
      : String(event.raw_message || event.message || '');
    const data = {
      platform: 'onebot', id: String(event.message_id || `${event.time || Date.now()}-${event.user_id || ''}`),
      author: { id: String(event.user_id || '') }, group_openid: group ? String(event.group_id || '') : '',
      group_id: group ? String(event.group_id || '') : '', user_id: String(event.user_id || ''),
      user_openid: group ? '' : String(event.user_id || ''), containsImage, content: safeText(content, 500)
    };
    this.handleDispatch(group ? 'ONEBOT_GROUP' : 'ONEBOT_PRIVATE', data).catch(error => this.addLog(`OneBot 消息处理失败：${error.message}`, 'error'));
  }
  async handleNapCatPoke(event) {
    const value = this.config();
    if (!event.group_id && value.oneBotPrivateReplies === false) return;
    const selfId = String(event.self_id || this.selfId || '');
    if (!selfId || String(event.target_id || '') !== selfId) return;
    const senderId = String(event.user_id || '');
    if (!senderId || !this.allowedSource({ platform: 'onebot', group_id: event.group_id, user_id: senderId })) return;
    if (!this.canQuery({ platform: 'onebot', user_id: senderId })) return;
    const command = this.normalizeCommand(value.pokeCommand || 'zxrs');
    if (!command || ['bindadmin', 'jrzq', 'scjrm', 'gljrm', 'jyjrm', 'qyjrm', 'glzxry', 'glfj', 'glycfj'].includes(command)) return;
    const data = {
      platform: 'onebot', id: `poke-${event.time || Date.now()}-${senderId}`,
      author: { id: senderId }, group_openid: event.group_id ? String(event.group_id) : '',
      group_id: event.group_id ? String(event.group_id) : '', user_id: senderId,
      user_openid: event.group_id ? '' : senderId
    };
    const context = this.oneBotContext(data);
    const output = this.command(command, [], this.isAdmin(data), context);
    this.addLog(`QQ ${senderId} 戳一戳，执行 ${command}。`);
    await this.reply('ONEBOT_POKE', { ...data, group_id: event.group_id, user_id: senderId }, output);
  }
  allowedSource(data) {
    const value = this.config();
    if (data.platform === 'onebot' && data.group_id && value.oneBotGroupOnly &&
        !(value.oneBotGroupAllowlist || []).includes(String(data.group_id))) return false;
    const source = data.platform === 'onebot'
      ? (data.group_id || data.group_openid || data.user_id || data.author?.id || '')
      : (data.guild_id || data.group_openid || data.author?.id || data.user_openid || '');
    const list = Array.isArray(value.sourceAllowlist) ? value.sourceAllowlist.filter(Boolean) : [];
    return list.length === 0 || list.includes(String(source));
  }
  isAdmin(data) {
    const value = this.config();
    const id = String(data.author?.id || data.user_openid || data.author?.user_openid || '');
    const admins = data.platform === 'onebot' ? value.adminQqIds || [] : value.adminOpenIds || [];
    return new Set(admins.map(String)).has(id);
  }
  canQuery(data) {
    const key = String(data.platform === 'onebot' ? data.user_id : data.author?.id || data.user_openid || data.author?.user_openid || 'unknown');
    const current = Date.now(); const timestamps = (this.rate.get(key) || []).filter(value => current - value < 60000);
    if (timestamps.length >= Number(this.config().rateLimitPerMinute || 20)) return false;
    timestamps.push(current); this.rate.set(key, timestamps); return true;
  }
  oneBotContext(data) {
    return { openId: String(data.author?.id || data.user_openid || ''), sourceOpenId: String(data.group_openid || 'private'), platform: 'onebot' };
  }
  onMessage(message) {
    if (message.s !== undefined && message.s !== null) this.sequence = message.s;
    if (message.op === OP.HELLO) {
      clearInterval(this.heartbeatTimer);
      const interval = Number(message.d?.heartbeat_interval || 45000);
      // Gateway heartbeat is an opcode envelope, not the bare sequence value.
      // Sending only the number causes QQ to close an otherwise healthy session.
      const heartbeat = () => this.socket?.send({ op: OP.HEARTBEAT, d: this.sequence });
      this.heartbeatTimer = setInterval(heartbeat, interval);
      this.identify();
      return;
    }
    if (message.op === OP.HEARTBEAT_ACK) return;
    if (message.op === OP.RECONNECT) { this.addLog('Gateway 请求重连。', 'warn'); this.socket?.close(); return; }
    if (message.op === OP.INVALID_SESSION) {
      this.sessionId = '';
      const detail = message.d === true ? '不可恢复' : message.d === false ? '可恢复' : (message.d ? JSON.stringify(message.d) : '未提供详情');
      this.addLog(`Gateway 会话无效（${detail}），正在重连。`, 'error');
      this.socket?.close();
      return;
    }
    if (message.op === OP.DISPATCH) {
      if (message.t === 'READY') {
        this.sessionId = message.d?.session_id || '';
        this.addLog(`Gateway READY，会话已建立${this.sessionId ? `（${this.sessionId.slice(0, 8)}）` : ''}。`);
      }
      this.handleDispatch(message.t, message.d).catch(error => this.addLog(error.message, 'error'));
    }
  }
  identify() { const value = this.config(); this.socket?.send({ op: OP.IDENTIFY, d: { token: `QQBot ${this.accessToken}`, intents: Number(value.intents || INTENTS), shard: [0, 1], properties: { '$os': 'windows', '$browser': 'chunithm-admin', '$device': 'chunithm-server' } } }); }
  snapshotKey(context) { return `${String(context.openId || 'unknown')}:${String(context.sourceOpenId || 'private')}`; }
  async handleDispatch(type, data = {}) {
    if (!['AT_MESSAGE_CREATE', 'MESSAGE_CREATE', 'GROUP_AT_MESSAGE_CREATE', 'C2C_MESSAGE_CREATE', 'ONEBOT_GROUP', 'ONEBOT_PRIVATE'].includes(type)) return;
    // QQ Gateway may redeliver an event after reconnecting. Ignore the same
    // message ID for five minutes so one command produces exactly one reply.
    const now = Date.now();
    for (const [id, seenAt] of this.seenMessages) if (now - seenAt > 5 * 60 * 1000) this.seenMessages.delete(id);
    const messageId = String(data.id || '');
    if (messageId && this.seenMessages.has(messageId)) { this.addLog(`忽略重复事件 ${messageId.slice(0, 12)}。`, 'warn'); return; }
    if (messageId) this.seenMessages.set(messageId, now);
    const senderOpenId = String(data.author?.id || data.user_openid || data.author?.user_openid || 'unknown');
    this.addLog(`收到事件 ${type}，发送者 OpenID=${senderOpenId.slice(0, 80)}。`);
    if (!this.allowedSource(data)) { this.addLog(`事件 ${type} 被来源白名单拦截。`, 'warn'); return; }
    if (!this.canQuery(data)) { this.addLog(`事件 ${type} 被请求频率限制拦截。`, 'warn'); return; }
    let content = safeText(data.content || data.message?.content || '', 500).replace(/<@!?.*?>/g, '').trim();
    if (data.platform === 'onebot') {
      const imageMarker = this.config().recordOneBotImages ? '[图片]' : '';
      content = content.replace(/\[CQ:image[^\]]*\]/gi, imageMarker).trim();
    }
    const sourceOpenId = String(data.group_openid || data.channel_id || data.guild_id || 'private');
    this.recordChat({ direction: 'in', platform: data.platform || 'official', eventType: type, userOpenId: senderOpenId, sourceOpenId,
      content: /^\/bindadmin\s+/i.test(content) ? '/bindadmin [已隐藏]' : content });
    const configuredPrefix = this.config().commandPrefix || '!';
    const prefixed = content.startsWith('/') || content.startsWith(configuredPrefix);
    const isOneBotGroup = type === 'ONEBOT_GROUP';
    if (isOneBotGroup && !prefixed && this.config().allowNoPrefixGroup === false) return;
    const commandText = prefixed ? content.slice(content.startsWith('/') ? 1 : configuredPrefix.length).trim() : content.trim();
    const rawParts = commandText.split(/\s+/).filter(Boolean);
    const command = this.normalizeCommand(rawParts[0] || (prefixed ? 'help' : ''));
    // In groups, accept only known command words/initials without a prefix. This
    // prevents ordinary conversation from being treated as a command or reply.
    if (!prefixed && (!isOneBotGroup || !command)) { this.addLog(`事件内容不是指令：${content.slice(0, 60)}`); return; }
    if (!command) { this.addLog(`无法识别指令：${content.slice(0, 60)}`); return; }
    const parts = rawParts.slice(1);
    const context = type.startsWith('ONEBOT_') ? this.oneBotContext(data) : { openId: senderOpenId, sourceOpenId };
    if (command === 'bindadmin') {
      const bound = this.consumeBindingCode(parts[0], senderOpenId, data.group_openid || '', data.platform || 'official');
      const output = bound ? '管理员绑定成功。\n该一次性绑定码已失效。' : '绑定码无效或已过期。';
      this.addLog(`管理员绑定${bound ? '成功' : '失败'}，OpenID=${senderOpenId.slice(0, 80)}。`, bound ? 'info' : 'warn');
      await this.reply(type, data, output); return;
    }
    const admin = this.isAdmin(data); const output = this.command(command, parts, admin, context);
    this.addLog(`执行指令 ${prefixed ? (content.startsWith('/') ? '/' : configuredPrefix) : ''}${command}${admin ? '（管理员）' : ''}。`);
    if (output) await this.reply(type, { ...data, mentionRequester: type === 'ONEBOT_GROUP' && command === 'jrzq' }, output);
  }
  normalizeCommand(value) {
    const text = String(value || '').trim().toLowerCase().replace(/[，。！？!?、:：]/g, '');
    const aliases = {
      help: ['help', 'h', '帮助', '菜单'], fwqzt: ['fwqzt', 'f', '服务器状态', '服务状态', '状态'],
      zxrs: ['zxrs', 'z', '在线人数', '在线', '人数'], zxdl: ['zxdl', '最近登录', '最近在线'],
      jrm: ['jrm', '加入码教程', '加入码使用方法', '教程'], jrzq: ['jrzq', '加入群组', '入组'],
      zxwj: ['zxwj', '在线玩家', '玩家'], gkfj: ['gkfj', '公开房间', '房间列表'], czfj: ['czfj', '常驻房间'], fj: ['fj', '房间详情'],
      glzxry: ['glzxry', '管理在线人员'], glfj: ['glfj', '管理房间'], glycfj: ['glycfj', '管理隐藏房间'],
      scjrm: ['scjrm', '生成加入码'], gljrm: ['gljrm', '管理加入码'], jyjrm: ['jyjrm', '禁用加入码'],
      qyjrm: ['qyjrm', '启用加入码'], bindadmin: ['bindadmin']
    };
    for (const [canonical, words] of Object.entries(aliases)) if (words.includes(text)) return canonical;
    return '';
  }
  command(command, args, admin, context = {}) {
    const prefix = this.config().commandPrefix || '!';
    if (['帮助', 'help', 'h'].includes(command)) return [
      admin ? '指令帮助（管理员）' : '指令帮助',
      '',
      'fwqzt / 服务器状态：查看在线设备和房间概况',
      'zxrs / 在线人数：查看在线总人数与群组分布',
      'zxdl / 最近登录：列出最近半小时内最多三位登录玩家',
      'zxwj / 在线玩家：查看在线玩家昵称和在线时长',
      'gkfj / 公开房间：列出当前公开房间',
      'czfj / 常驻房间：查看常驻房间名称、人数、状态、模式和曲库范围',
      'fj 房间号 / 房间详情：查看公开房间信息',
      'jrm / 加入码教程：查看私聊 Bot 绑定群组的步骤',
      'jrzq 编号 加入码 / 加入群组：将最近登录列表中的设备加入目标群组',
      ...(admin ? ['', '管理员指令',
        'glzxry / 在线人员详情：查看在线设备标识和所在位置',
        'glfj [房间号] / 房间管理：查看所有房间或指定房间成员设置',
        'glycfj / 隐藏房间：单独列出未公开房间',
        'scjrm 群组ID 数量 次数 / 生成加入码',
        'gljrm / 加入码列表；jyjrm 编号 / 禁用；qyjrm 编号 / 启用'] : [])
    ].join('\n');
    const overview = this.getAdminOverview(); const publicRooms = this.getPublicRooms();
    if (['服务器状态', '状态', 'status', 'fwqzt', 'f'].includes(command)) return `服务器正常\n在线设备：${overview.onlineDeviceCount}\n当前房间：${overview.roomCount}\n公开房间：${publicRooms.length}\n版本：${overview.version || 'unknown'}`;
    if (['在线人数', '人数', 'online', 'zxrs', 'z'].includes(command)) {
      const groups = new Map();
      for (const item of overview.devices.filter(device => device.online)) {
        const name = item.group?.name || '默认群组';
        groups.set(name, (groups.get(name) || 0) + 1);
      }
      const groupText = [...groups.entries()].map(([name, count]) => `${name} ${count}人`).join('、') || '暂无在线群组';
      return `当前在线 ${overview.onlineDeviceCount} 人\n群组在线：${groupText}\n公开房间 ${publicRooms.length} 个。`;
    }
    if (['最近登录', '最近在线', 'recent', 'zxdl'].includes(command)) {
      const snapshot = this.getRecentLogins(context.openId, context.sourceOpenId);
      this.recentSnapshots.set(this.snapshotKey(context), snapshot);
      if (!snapshot.items.length) return '最近30分钟没有登录记录。';
      return `最近30分钟登录（查询编号有效5分钟）\n${snapshot.items.map((item, index) => `[${index + 1}] ${item.playerName || '未命名'} · ${item.online ? '在线' : '已离线'} · 登录 ${new Date(item.loginAt).toLocaleTimeString('zh-CN', { hour12: false })} · ID尾号 ${item.idSuffix} · 群组 ${item.groupName}`).join('\n')}`;
    }
    if (['加入码教程', '加入码使用方法', '教程', 'code-help', 'jrm'].includes(command)) return [
      '加入码使用方法',
      '',
      '建议全程私聊Bot操作，不要在群聊公开加入码。',
      '1. 私聊Bot发送 /zxdl',
      '2. 在返回的列表中找到目标玩家，记住前面的编号（1、2、3）。',
      '3. 发送：/jrzq 编号 加入码',
      '   例如：/jrzq 1 ABCD-1234',
      '4. 绑定成功后，该设备会加入加入码对应的群组。',
      '',
      '注意：查询编号仅在5分钟内有效；加入码区分大小写；加入码只能按服务端剩余次数使用。',
      '如果提示没有登录记录，请先让目标设备打开游戏并进入联机大厅，再重新发送 /zxdl。'
    ].join('\n');
    if (['加入群组', '入组', 'join-group', 'jrzq'].includes(command)) {
      const snapshot = this.recentSnapshots.get(this.snapshotKey(context));
      const result = this.consumeGroupJoinCode(args[1], snapshot, args[0], context);
      if (result.error) return result.error;
      return `加入群组成功\n用户：${result.playerName}\nID尾号：${result.idSuffix}\n群组：${result.groupName}${result.previousGroupName === result.groupName ? '\n该用户原本已在此群组。' : `\n原群组：${result.previousGroupName}`}${result.remainingUses < 0 ? '\n加入码剩余次数：不限' : `\n加入码剩余次数：${result.remainingUses}`}`;
    }
    if (['公开房间', '房间', 'rooms', 'gkfj'].includes(command)) return publicRooms.length ? `公开房间（${publicRooms.length}）：\n` + publicRooms.map(room => `${room.roomId} ${room.roomName} · ${room.memberCount}/${room.maxPlayers} · ${room.state} · ${room.mode}`).join('\n') : '当前没有公开房间。';
    if (['常驻房间', 'persistent-rooms', 'czfj'].includes(command)) {
      const rooms = publicRooms.filter(room => room.persistent === true);
      return rooms.length ? `常驻房间（${rooms.length}）：\n` + rooms.map(room => `${room.roomName}（${room.roomId}）\n人数：${room.memberCount}/${room.maxPlayers} · 模式：${room.mode === 'normal' ? '普通' : '休闲'} · 状态：${persistentStateText(room.state)}\n曲库：${persistentLibraryText(room.librarySelection)}`).join('\n\n') : '当前没有常驻房间。';
    }
    if (['在线玩家', 'players', 'zxwj'].includes(command)) return overview.devices.filter(item => item.online).map(item => `${item.playerName || '未命名'} · 在线 ${duration(Date.now() - Date.parse(item.connectedAt))}`).join('\n') || '当前没有在线玩家。';
    if (['房间', 'room', 'fj'].includes(command)) {
      const room = publicRooms.find(item => item.roomId === args[0]);
      if (!room) return '找不到公开房间。隐藏房间需要管理员权限。';
      return `${room.roomName}（${room.roomId}）\n房主：${room.hostName}\n人数：${room.memberCount}/${room.maxPlayers}\n模式：${room.mode}\n选歌：${room.selectionMode}\n状态：${room.state}\n歌曲：${room.song?.songName || '未选择'}`;
    }
    if (!admin) return '该指令需要 Bot 管理员权限。';
    if (['生成加入码', 'scjrm', 'group-code'].includes(command)) {
      const result = this.createGroupJoinCodes(args[0], args[1], args[2], context.openId || 'qq-admin');
      if (result.error) return result.error.message || '生成加入码失败。';
      return `群组加入码已生成\n群组：${result.groupName}（${result.groupId}）\n数量：${result.codes.length}\n每个加入码次数：${Number(args[2]) < 0 ? '不限' : args[2]}\n\n${result.codes.join('\n')}\n\n请立即保存以上加入码；服务端只保存哈希，无法恢复明文。`;
    }
    if (['管理加入码', 'gljrm', 'list-group-codes'].includes(command)) {
      const list = this.listGroupJoinCodes();
      return list.length ? `群组加入码（仅显示内部编号）\n${list.map(item => `${item.id} · ${item.groupName} · ${item.enabled ? '启用' : '禁用'} · ${item.maxUses < 0 ? '不限' : `${item.usedCount}/${item.maxUses}`}`).join('\n')}` : '当前没有群组加入码。';
    }
    if (['禁用加入码', 'jyjrm', 'disable-group-code'].includes(command)) {
      const result = this.setGroupJoinCodeStatus(args[0], false);
      return result.error ? (result.error.message || '禁用加入码失败。') : `加入码 ${args[0]} 已禁用。`;
    }
    if (['启用加入码', 'qyjrm', 'enable-group-code'].includes(command)) {
      const result = this.setGroupJoinCodeStatus(args[0], true);
      return result.error ? (result.error.message || '启用加入码失败。') : `加入码 ${args[0]} 已启用。`;
    }
    if (['管理在线人员', 'admin-online', 'glzxry'].includes(command)) return overview.devices.filter(item => item.online).map(item => `${item.playerName || '未命名'} | ${item.gameId} | ${duration(Date.now() - Date.parse(item.connectedAt))} | ${item.roomName || '大厅'}`).join('\n') || '当前没有在线人员。';
    if (['管理房间', 'admin-room', 'glfj'].includes(command) && args[0]) {
      const room = overview.rooms.find(item => item.roomId === args[0]);
      if (!room) return '找不到该房间。';
      return `${room.roomName}（${room.roomId}）\n可见性：${room.listed ? '公开' : '隐藏'}\n房主：${room.hostName}\n人数：${room.memberCount}/${room.maxPlayers}\n模式：${room.mode}\n选歌：${room.selectionMode}\n状态：${room.state}\n歌曲：${room.song?.songName || '未选择'}\n成员：${room.members.map(member => `${member.name}（${member.gameId}，${member.online ? '在线' : '离线'}）`).join('、') || '无成员'}`;
    }
    if (['管理房间', 'admin-rooms', 'glfj'].includes(command)) return overview.rooms.length ? overview.rooms.map(room => `${room.roomId} ${room.roomName} | ${room.listed ? '公开' : '隐藏'} | ${room.memberCount}/${room.maxPlayers} | ${room.state} | 房主 ${room.hostName}`).join('\n') : '当前没有房间。';
    if (['管理隐藏房间', 'admin-hidden', 'glycfj'].includes(command) || (command === 'gl' && args[0] === 'ycfj')) { const rooms = overview.rooms.filter(room => !room.listed); return rooms.length ? rooms.map(room => `${room.roomId} ${room.roomName} | ${room.memberCount}/${room.maxPlayers} | ${room.state} | ${room.members.map(member => member.name).join('、') || '无成员'}`).join('\n') : '当前没有隐藏房间。'; }
    return '未知指令，请发送帮助查看指令。';
  }
  async reply(type, data, content) {
    if (type.startsWith('ONEBOT_')) {
      if (!this.socket || this.socket.closed) { this.addLog('OneBot 回复失败：WebSocket 未连接。', 'error'); return; }
      if (!data.group_id && this.config().oneBotPrivateReplies === false) return;
      const mention = data.mentionRequester && data.group_id && data.user_id ? `[CQ:at,qq=${data.user_id}] ` : '';
      const params = { message: mention + safeText(content, 3500) };
      if (data.group_id) { params.group_id = String(data.group_id); this.socket.send({ action: 'send_group_msg', params, echo: `reply-${data.id || Date.now()}` }); }
      else { params.user_id = String(data.user_id || data.author?.id || ''); this.socket.send({ action: 'send_private_msg', params, echo: `reply-${data.id || Date.now()}` }); }
      this.addLog('OneBot 消息发送成功。');
      this.recordChat({ direction: 'out', platform: 'onebot', eventType: type, userOpenId: String(data.user_id || data.author?.id || ''),
        sourceOpenId: String(data.group_id || 'private'), content: safeText(content, 3500) });
      return;
    }
    const apiBase = this.config().apiBase || 'https://api.sgroup.qq.com'; const headers = { Authorization: `QQBot ${this.config().appId}.${this.accessToken}`, 'Content-Type': 'application/json' };
    // QQ clients are inconsistent when rendering bare LF in C2C/group plain
    // text. Send canonical CRLF so every command response keeps its lines.
    let url; let body = { content: safeText(content, 1900).replace(/\n/g, '\r\n') };
    if (type === 'C2C_MESSAGE_CREATE') { url = `${apiBase}/v2/users/${encodeURIComponent(data.author?.id || data.user_openid)}/messages`; body.msg_type = 0; body.msg_id = data.id; }
    else if (type === 'GROUP_AT_MESSAGE_CREATE') { url = `${apiBase}/v2/groups/${encodeURIComponent(data.group_openid)}/messages`; body.msg_type = 0; body.msg_id = data.id; }
    else { url = `${apiBase}/v2/channels/${encodeURIComponent(data.channel_id)}/messages`; body.msg_id = data.id; }
    // msg_seq must increase when QQ accepts more than one response associated
    // with the same source message. Keeping it explicit also avoids API-side
    // deduplication during retry races.
    if (data.id) {
      const key = String(data.id); const next = (this.replySequences.get(key) || 0) + 1;
      this.replySequences.set(key, next); body.msg_seq = next;
      if (this.replySequences.size > 1000) this.replySequences.clear();
    }
    try { await requestJson(url, { method: 'POST', headers: { ...headers, Authorization: `QQBot ${this.accessToken}` } }, body); this.addLog('消息回复成功。'); } catch (error) { this.addLog(`回复消息失败：${error.message}`, 'error'); }
    this.recordChat({ direction: 'out', eventType: type, userOpenId: String(data.author?.id || data.user_openid || ''),
      sourceOpenId: String(data.group_openid || data.channel_id || data.guild_id || 'private'), content: safeText(content, 1900) });
  }
}

module.exports = { QQBot };
