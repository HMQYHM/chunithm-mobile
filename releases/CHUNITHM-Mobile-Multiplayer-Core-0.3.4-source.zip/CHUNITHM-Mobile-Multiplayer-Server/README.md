# CHUNITHM Mobile Multiplayer Server

当前服务端版本：`0.3.4`

This is the Windows room server for the Unity client. It uses only Node.js
built-in modules, so no npm package installation is required.

## Run

1. Install Node.js 18 or newer.
2. Edit `config.json`.
3. Double-click `start-server.bat`, or run `node server.js`.
4. Point the client at `server-address:27960`.

To run the protocol smoke test against the local server from PowerShell:

```powershell
$env:TEST_HOST='your-server-address'
$env:TEST_PORT='27960'
node smoke-test.js
```

The test uses fresh device IDs and verifies reservations, quota accounting,
personal/persistent room limits, authenticated package transfer with range
download, song synchronization, unified loading, tied results, host rotation,
and vote behavior after a disconnect. Vote thresholds use only
currently connected room members, so a disconnected member cannot keep a vote
from reaching its configured ratio. Health and configuration
endpoints are administrator-only; set `TEST_ADMIN_TOKEN` for a remote test.

The default server is intentionally HTTP/WebSocket without TLS for local LAN
testing. Do not port-forward this default configuration to the public Internet.
Before doing that, enable TLS and set a long random `authToken` in `config.json`.
The certificate files are resolved relative to this directory.

On first start the server creates a `data` directory containing a private
identity secret, the persistent device-to-game-ID map, and the block list. The
raw device ID is never written to disk or to the log. The server prints a
generated administrator token once on first start. Keep it private. Open
`http://127.0.0.1:27960/admin` on the Windows server and enter that token.
The administrator page and every administrator API are restricted to the
server machine's loopback address. They cannot be opened from another device.

## Implemented protocol

- WebSocket endpoint: `/ws`
- Administrator-only health endpoint: `/health`
- Administrator-only configuration endpoint: `/api/v1/config`
- Six-digit cryptographically random room IDs
- Stable server-issued game IDs derived from a device ID HMAC
- One active connection and one room per game ID
- Persistent game-ID records and administrator block list
- Persistent latest nickname and recent nickname history for every device
- Authenticated WebSocket room lists with exact-ID hidden-room lookup
- Server-side room-list filters for idle, not-full, unencrypted, room mode and room type
- Optional room password with salted scrypt verification
- Casual rooms: any known MOD combination, no score saving
- Normal rooms: server-side score-counting MOD allowlist only
- Current-host-controlled room settings, song selection and automatic start
- Host transfer after everyone returns from a round
- Current-host-only kick in the lobby
- Ready, syncing, loading, playing and result states visible to every room member
- Room members must use the exact same client version as the room creator
- Full-chart AUTO is unavailable in multiplayer; normal rooms accept only score-counting MODs
- Server-enforced per-day create/join room quotas by administrator-managed group
- Heartbeat, connection limits, message limits and idle cleanup
- Local administrator dashboard for game-ID and room inspection
- Administrator block and unblock actions; blocking disconnects the active client
- Client inactivity warning and disconnect, with loading/playing clients exempt
- A one-minute server-enforced cooldown after explicitly leaving the multiplayer lobby
- Ten-minute background timeout, including during a round
- Host-to-server-to-member ZIP transfer with SHA-256 verification and range resume
- Two-stage round synchronization and server-side result validation
- Server-managed persistent rooms with administrator edit/delete controls; personal rooms remain limited to 8 players and persistent rooms can be configured up to 20 players
- Server song library import from ZIP packages with SHA-256 indexing for songs, charts and covers
- Persistent-room library selection modes: all songs, selected song IDs, levels, and random selection
- Separate Discord Bot administrator page and encrypted write-only token storage; QQ Bot configuration remains independent

`idleClientMinutes` controls how long an authenticated client may remain in
the lobby, preparing, results, or outside a room without a meaningful action.
The default is 30 minutes. `idleWarningSeconds` controls the warning sent before
disconnect (60 seconds by default). WebSocket ping/pong traffic does not reset
this timer. Loading and playing clients receive a fresh idle period when play
ends.

`backgroundTimeoutMinutes` controls how long a client may remain backgrounded;
the default is 10 minutes. `roomReservationSeconds` controls how long a
server-reserved six-digit personal room number remains valid. Persistent rooms use
a three-digit number chosen by the administrator or allocated by the server.

The Unity client sends the WebSocket `sessionToken` as a bearer token for file
transfer. Only the current room host may upload; only room members may
download. Temporary packages are removed when a song changes, a room closes,
or the retention window expires.

The client sends a hashed device identity. On Android, the client prefers the
system `ANDROID_ID` and falls back to Unity's device identifier; only devices
where neither identifier is available use a local installation seed. During an
upgrade from an older client identity format it may also send `legacyDeviceId`;
the server migrates the existing record to the new fingerprint so a device
keeps its game ID.

## Room rules

The server never trusts a client-provided `recordsScore` flag. Normal mode is
validated against its own allowlist. At the moment the score-counting MODs are
`airLongNoMotion` and `flickSimpleMode`; the base configuration with no MOD is
also valid. AUTO, AIR AUTO, mine immunity and music-rate changes are rejected
in normal rooms.

Room numbers are locators, not passwords. Personal rooms use six digits and
persistent rooms use three digits. Use a room password for
hidden rooms and keep the server token private. A room in `loading`,
`countdown`, `playing`, `personalResults`, or `groupResults` is always rejected
by the server when a client attempts to join it, even if it appears in a room
list or is found by exact room ID.

Rooms can be created as `personal` or `persistent`, but the two room types have
different owners and capacity limits. A normal client can create only a
`personal` room, which is removed when the last member leaves and is limited to
8 players. A `persistent` room is a server-managed resource: it can only be
created from the administrator page or the administrator API, is stored in
`data/persistent-rooms.json`, and can be listed separately in the client lobby.
Persistent rooms can hold up to 20 players (the effective limit is the lower of
20 and `maxPlayersPerRoom`). A client request that tries to create a persistent
room is rejected with `PERSISTENT_ROOM_ADMIN_ONLY`.

To create one from the local administrator page, open `/admin-v2`, sign in, select
“房间管理”, and use “创建常驻房间”. The equivalent authenticated endpoint is
`POST /admin/api/rooms/persistent` with an optional three-digit `roomId`,
`roomName` (up to 15 characters), `roomMode`, `maxPlayers` (2–20), `listed`,
and an optional `password`. If `roomId` is omitted, the server allocates a
free three-digit number. Persistent rooms use server-managed library selection;
the old host/loop selection setting is not exposed by the admin panel.
For random library selection, `randomCount` accepts `0–20`; `0` means that the
server reselects a song every minute while the room is idle and has members.
The page also provides `PATCH /admin/api/rooms/persistent/:roomId` for editing and
`DELETE /admin/api/rooms/persistent/:roomId` for deleting an empty persistent room.

## Server song library and Discord Bot

The `/admin-v2` pages “谱面曲库” and “Discord Bot” are local administrator tools.
The song library accepts both of these formats:

- Standard server ZIP: contains `chunithm-song.json` or `songs.json`, chart
  files referenced by the manifest, and optional cover files.
- Game import directory: click “生成导入文件夹” in “谱面曲库”, extract the
  original game song ZIP into the displayed directory, then click “扫描并生成
  索引”. The scanner reads each song's `manifest.json`, `Music.xml`, `category.txt`,
  `.c2s` charts, audio files, and `CHU_UI_Jacket_*.dds` cover. It does not
  require a global `songs.json` file.

The directory scan writes indexed metadata to `data/song-library/index.json` and
keeps the extracted source under `data/song-library/import-staging`. When a
persistent-room host selects a scanned song, the server creates a per-song ZIP
under `data/song-library/generated`, computes its real SHA-256, and serves that
package through the existing authenticated transfer endpoint. This keeps the
client's package verification and cover/audio transfer behavior unchanged.
A package in use by a room cannot be deleted.

The Discord page is separate from QQ Bot. Configure the Discord Application ID,
Bot Token, optional server/channel allowlists and Gateway Intents, then save and
connect. The token is encrypted in `config.json` and is never returned by the
API or written to logs. The Bot registers slash commands such as `/fwqzt`,
`/zxrs`, `/zxdl`, `/zxwj`, `/gkfj`, `/fj` and `/jrzq`, while also accepting the
same prefixed text commands as QQ Bot. Administrator commands are visible in
the command list but require a bound administrator user or role.

The Discord panel supports a member-role allowlist, administrator role IDs,
administrator user IDs, and a one-time administrator binding code. Generate a
code in the panel, then run `/bindadmin` in Discord; the user ID is saved in the
local encrypted configuration. Enable Message Content Intent in Discord
Developer Portal when using text-command compatibility. Discord connectivity
needs Node.js 22 or newer; the multiplayer server itself still runs on Node.js
18 or newer when Discord is disabled.

When a song is selected, any member can start a song-change vote. The server
counts one vote per connected member and calculates the threshold from
`songChangeVoteRequiredRatio` (default `0.5`, clamped to 10%–100%). The ratio
can be changed from the local administrator settings page and is sent in room
snapshots so the client displays the active percentage and current vote count.
When the threshold is reached, the server clears the old transfer, returns the
room to song selection, and broadcasts `songChangeVotePassed` followed by
`returnedToLobby`; clients cannot approve a vote locally.

## Client versions and daily quotas

The client must send a non-empty `clientVersion` during `hello`. A room records
the creator's version, and the server rejects a join from a different version
with `CLIENT_VERSION_MISMATCH`. This prevents clients with incompatible chart,
judgement or protocol behavior from entering the same room.

Every device belongs to an administrator-managed group. The default group allows
5 successful room creations and 20 successful room joins per UTC day. A quota is
only consumed after the server has accepted the operation; failed validation,
wrong passwords, full rooms and version mismatches do not consume a quota. The
server sends the current quota in `helloAccepted`, `roomList`, `roomCreated`,
`roomJoined` and `quotaUpdated` messages. A limit of `-1` means unlimited.

The local administrator page exposes group creation, limit changes, deletion of
non-default groups and game-ID assignment. These controls are available only
from the Windows server machine at `/admin`.

The administrator device table keeps showing a device's latest nickname after
it disconnects. It also supports searching by game ID, current or historical
nickname, and group, filtering by online/offline/blocked state, and expanding a
device's recent nickname history. Existing `data/server-state.json` files are
read compatibly; the server adds the nickname fields when a device next logs
in and never replaces the existing data file with a blank one.

For an isolated local test, set `CHUNITHM_DATA_DIR` to a temporary directory
before starting the server. The default remains `./data` for production:

```powershell
$env:CHUNITHM_DATA_DIR = "$env:TEMP\chunithm-server-test"
node server.js
```

## Game ID identity rule

The client must send a stable `deviceId` in its first `hello` message. The
server returns a stable `gameId` such as `GM8K4P2Q9X1`. The client must
store that server-issued value and display it when needed; it must not invent
or replace it. A second active connection using the same device ID is rejected,
and a game ID cannot create or join a second room while already in one.

This prevents accidental duplicate sessions, but it is not a tamper-proof
account system: a modified client can present a different device ID. Internet
deployment should later add an account/login layer if identity abuse matters.
## QQ Bot 群组加入码

所有成员可以在群聊或私聊 Bot 中使用：

- `/zxrs`：查看当前在线人数，并按群组汇总。
- `/zxdl`：查看最近 30 分钟最多 3 条登录记录，显示玩家名、登录时间、在线状态、游戏 ID 后四位和当前群组。
- `/jrm`：查看加入码详细使用方法；建议用户私聊 Bot 查询，避免在群聊公开设备信息和加入码。
- `/jrzq 编号 加入码`：使用 `/zxdl` 返回的固定编号和群组加入码加入对应群组。查询编号在 5 分钟内固定，不会被后续登录替换。

只有 Bot 管理员可以使用：

- `/scjrm 群组ID 数量 次数`：生成群组加入码；次数填 `-1` 表示不限次数。
- `/gljrm`：查看加入码内部编号、所属群组、状态和使用次数。
- `/jyjrm 加入码编号` / `/qyjrm 加入码编号`：禁用或启用加入码。

网页后台的“分类群组”页面也可以批量生成加入码并立即下载 TXT。加入码明文只在生成响应中出现一次，服务端 `data/server-state.json` 只保存 SHA-256 哈希、使用次数和审计信息，不保存明文。每次使用会记录 QQ OpenID、来源、目标玩家、游戏 ID 后四位、目标群组和时间。
