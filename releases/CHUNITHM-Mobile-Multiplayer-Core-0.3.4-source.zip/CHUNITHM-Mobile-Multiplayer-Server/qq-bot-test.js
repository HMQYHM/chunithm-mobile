'use strict';

const assert = require('assert');
const { QQBot } = require('./qq-bot');

function makeBot(overrides = {}) {
  const config = {
    enabled: true,
    provider: 'napcat',
    adminQqIds: ['12345678'],
    adminOpenIds: ['official-admin'],
    oneBotPrivateReplies: true,
    oneBotGroupOnly: true,
    oneBotGroupAllowlist: ['87654321'],
    allowNoPrefixGroup: true,
    commandPrefix: '!',
    rateLimitPerMinute: 120,
    pokeCommand: 'zxrs',
    recordOneBotImages: false,
    ...overrides
  };
  const sent = [];
  const records = [];
  const bot = new QQBot({
    getConfig: () => config,
    getPublicRooms: () => [],
    getAdminOverview: () => ({ onlineDeviceCount: 2, roomCount: 0, version: 'test', devices: [], rooms: [] }),
    getRecentLogins: () => ({ items: [], expiresAt: Date.now() }),
    consumeGroupJoinCode: () => ({ playerName: '测试玩家', idSuffix: '1234', groupName: '测试组', previousGroupName: '默认组', remainingUses: 0 }),
    recordChat: entry => records.push(entry),
    consumeBindingCode: () => false,
    log: () => {}
  });
  bot.socket = { closed: false, send: value => sent.push(typeof value === 'string' ? JSON.parse(value) : value) };
  bot.stopped = false;
  return { bot, config, sent, records };
}

async function send(bot, event) {
  await bot.handleDispatch(event.type, {
    platform: 'onebot', id: `id-${Math.random()}`, author: { id: event.userId },
    user_id: event.userId, group_id: event.groupId, group_openid: event.groupId,
    content: event.content, message: { content: event.content }
  });
}

async function main() {
  const { bot, sent } = makeBot();
  await send(bot, { type: 'ONEBOT_GROUP', groupId: '87654321', userId: '33333333', content: '在线人数' });
  assert.match(sent.at(-1).params.message, /当前在线 2 人/);
  assert.ok(!sent.at(-1).params.message.includes('[CQ:at'));

  await send(bot, { type: 'ONEBOT_GROUP', groupId: '87654321', userId: '33333333', content: 'h' });
  assert.ok(!sent.at(-1).params.message.includes('管理员指令'));
  await send(bot, { type: 'ONEBOT_GROUP', groupId: '87654321', userId: '12345678', content: 'help' });
  assert.ok(sent.at(-1).params.message.includes('管理员指令'));

  await send(bot, { type: 'ONEBOT_GROUP', groupId: '87654321', userId: '33333333', content: 'jrzq 1 CODE' });
  assert.ok(sent.at(-1).params.message.startsWith('[CQ:at,qq=33333333]'));
  await send(bot, { type: 'ONEBOT_GROUP', groupId: '87654321', userId: '33333333', content: 'jrm' });
  assert.ok(!sent.at(-1).params.message.includes('[CQ:at'));

  const beforeBlockedGroup = sent.length;
  await send(bot, { type: 'ONEBOT_GROUP', groupId: '11111111', userId: '33333333', content: 'zxrs' });
  assert.strictEqual(sent.length, beforeBlockedGroup);

  const privateBot = makeBot({ oneBotPrivateReplies: false });
  await send(privateBot.bot, { type: 'ONEBOT_PRIVATE', userId: '33333333', content: '/zxrs' });
  assert.strictEqual(privateBot.sent.length, 0);

  const imageBot = makeBot({ recordOneBotImages: true });
  await send(imageBot.bot, { type: 'ONEBOT_GROUP', groupId: '87654321', userId: '33333333', content: '普通消息 [图片]' });
  assert.ok(imageBot.records.some(entry => entry.content.includes('[图片]')));
  await privateBot.bot.handleNapCatPoke({ self_id: '99999999', target_id: '99999999', user_id: '33333333', time: Date.now() });
  assert.strictEqual(privateBot.sent.length, 0);

  const adminBindingBot = makeBot();
  await send(adminBindingBot.bot, { type: 'ONEBOT_GROUP', groupId: '87654321', userId: '87654321', content: '/bindadmin ABCD' });
  assert.match(adminBindingBot.sent.at(-1).params.message, /无效或已过期/);
  console.log('QQ Bot tests passed.');
}

main().catch(error => { console.error(error); process.exitCode = 1; });
