'use strict';

const fs = require('fs');
const path = require('path');

const domain = String(process.argv[2] || '').trim().toLowerCase();
if (!/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(domain)) {
  console.error('ERROR: Invalid public domain name.');
  process.exit(1);
}

const configPath = path.join(__dirname, 'config.json');
let config;
try {
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
} catch (error) {
  console.error(`ERROR: Unable to read config.json: ${error.message}`);
  process.exit(1);
}

const backupPath = path.join(__dirname, 'config.before-caddy.json');
if (!fs.existsSync(backupPath)) fs.copyFileSync(configPath, backupPath);

// Caddy owns public TLS. The Node process must remain plain HTTP/WS on the
// loopback proxy target, otherwise Caddy cannot reach /health or /ws.
config.tls = {
  ...(config.tls || {}),
  enabled: false,
  domain
};
// Only Caddy should be reachable from the Internet in proxy mode.
config.host = '127.0.0.1';

const temporaryPath = `${configPath}.tmp`;
fs.writeFileSync(temporaryPath, `${JSON.stringify(config, null, 2)}\n`, 'utf8');
fs.renameSync(temporaryPath, configPath);
console.log(`Caddy proxy mode saved for ${domain}. Node TLS is disabled.`);
console.log('Node will listen on 127.0.0.1 only.');
console.log(`Backup: ${backupPath}`);
