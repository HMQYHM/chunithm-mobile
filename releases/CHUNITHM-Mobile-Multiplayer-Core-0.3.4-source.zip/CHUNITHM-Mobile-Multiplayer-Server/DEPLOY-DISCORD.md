# Discord Bot 上线说明

这份服务端支持 Discord Gateway、斜杠指令和带前缀的文本指令。Discord 配置与 QQ Bot 配置相互独立。

## 1. Discord Developer Portal

1. 打开 Discord Developer Portal，进入应用的 **Bot** 页面。
2. 开启 `Server Members Intent`。
3. 开启 `Message Content Intent`。只有需要兼容 `!fwqzt`、`!zxrs` 等文本指令时才会读取消息内容。
4. 复制 Bot Token。Token 只在本机管理后台保存，不能写入 GitHub、README、ZIP 或聊天记录。

## 2. 邀请 Bot

使用下面的授权链接，将 `APPLICATION_ID` 替换为应用的 Application ID：

```text
https://discord.com/oauth2/authorize?client_id=APPLICATION_ID&scope=bot%20applications.commands&permissions=3072
```

授权范围是 `bot` 和 `applications.commands`，权限整数 `3072` 包含查看频道、发送消息。选择目标服务器并完成 Discord 的验证。

## 3. 服务端配置

1. 使用 Node.js 22 或更新版本启动服务端。启用 Discord Bot 时需要 Node.js 22 的内置 `fetch` 和 `WebSocket`。
2. 打开本机管理后台：`http://127.0.0.1:27960/admin-v2`。
3. 登录后进入 **Discord Bot** 页面。
4. 填写 Application ID 和 Bot Token，勾选启用，然后点击“保存并连接”。
5. 如果只允许指定服务器使用 Bot，填写 Server ID 白名单。Channel ID 白名单可以进一步限制到指定频道。
6. 保存后等待状态变为“已连接”。后台日志应出现“已登录”和“已注册 17 个斜杠指令”。

Token 输入框是只写入控件，保存后不会回显 Token。服务端会使用本机 `data/security.json` 中的身份密钥加密保存。

## 4. 管理员和成员

- 在 Discord Bot 页面填写管理员用户 ID 或管理员角色 ID，可以直接保存。
- 也可以点击“生成后台绑定码”，然后由目标 Discord 账号在服务器内执行 `/bindadmin` 并填写一次性绑定码。
- `membersOnly` 开启后，只有拥有成员角色 ID 的用户可以使用 Bot；管理员用户和管理员角色不受该限制。
- 管理员指令会额外检查绑定的用户 ID或管理员角色。

## 5. 验证

在目标服务器输入 `/`，应能看到服务端注册的指令，例如：

```text
/fwqzt
/zxrs
/zxdl
/zxwj
/gkfj
/fj
/jrzq
```

也可以使用文本兼容指令：

```text
!fwqzt
!zxrs
```

管理员绑定成功后，执行 `/glzxry` 或 `!glzxry` 验证管理员权限。若斜杠指令已经出现但 Bot 不在线，先检查 Node.js 版本、服务端日志、系统网络代理和 Developer Portal 中的 Intent 开关。

## 6. 重新部署和安全要求

- 发布 ZIP 不包含生产 `config.json`、`data/`、Bot Token、管理员启动令牌、管理员绑定码或运行记录。
- 首次启动会生成新的本地管理员令牌；只在服务端本机终端中显示。
- Bot Token 泄露后应立即在 Developer Portal 重置，再在本地管理后台填写新 Token。
- 服务端默认是本地/LAN 使用的 HTTP 和 WebSocket。公网部署前应配置 TLS、长随机 `authToken` 和防火墙规则。

如果本机只能通过 Clash 访问 Discord，可在启动前设置：

```bash
export NODE_USE_ENV_PROXY=1
export HTTPS_PROXY=http://127.0.0.1:7897
export HTTP_PROXY=http://127.0.0.1:7897
node start-server.js
```

Windows PowerShell 对应写法：

```powershell
$env:NODE_USE_ENV_PROXY = "1"
$env:HTTPS_PROXY = "http://127.0.0.1:7897"
$env:HTTP_PROXY = "http://127.0.0.1:7897"
node start-server.js
```
