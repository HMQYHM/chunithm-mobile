'use strict';

// Generate the per-process administrator token before server.js is loaded.
// Keeping this in Node avoids shell and PowerShell quoting differences across
// Windows Server releases.
const crypto = require('crypto');

const token = crypto.randomBytes(32).toString('hex');
process.env.CHUNITHM_ADMIN_TOKEN = token;
process.env.CHUNITHM_TOKEN_DISPLAYED = '1';

console.log('================================================================');
console.log('CHUNITHM Multiplayer Server');
console.log('================================================================');
console.log('本次启动的管理员登录令牌（下次启动会重新生成）:');
console.log(token);
console.log('');
console.log('新版管理后台:');
console.log('http://127.0.0.1:27960/admin-v2');
console.log('================================================================');
console.log('');

require('./server').start();
