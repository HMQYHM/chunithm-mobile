'use strict';

// Discord Gateway/REST adapter. The server supplies command execution and
// administrator binding callbacks so Discord and QQ use the same command set.
class DiscordBot {
  constructor(options) {
    this.getConfig = options.getConfig;
    this.getPublicRooms = options.getPublicRooms || (() => []);
    this.normalizeCommand = options.normalizeCommand || (value => String(value || '').toLowerCase());
    this.executeCommand = options.executeCommand || (() => '服务端未配置指令处理器。');
    this.consumeBindingCode = options.consumeBindingCode || (() => false);
    this.audit = options.audit || (() => {});
    this.log = options.log || (() => {});
    this.socket = null; this.heartbeat = null; this.reconnectTimer = null;
    this.stopping = false; this.sequence = null; this.applicationId = '';
    this.statusValue = { enabled: false, configured: false, connected: false, ready: false, message: '未启用', commandsRegistered: false, logs: [] };
  }
  config() { return this.getConfig() || {}; }
  status() { return { ...this.statusValue, logs: this.statusValue.logs.slice(-30) }; }
  addLog(message, level = 'info') { const entry = { at: new Date().toISOString(), level, message: String(message).replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 240) }; this.statusValue.logs.push(entry); if (this.statusValue.logs.length > 30) this.statusValue.logs.shift(); this.log(`[discord-bot] ${entry.message}`); }
  async start() {
    this.stopping = false; const config = this.config();
    this.statusValue.enabled = config.enabled === true; this.statusValue.configured = Boolean(config.token);
    this.statusValue.connected = false; this.statusValue.ready = false; this.statusValue.commandsRegistered = false;
    if (!config.enabled) { this.statusValue.message = '未启用'; return; }
    if (!config.token) { this.statusValue.message = '未配置 Bot Token'; this.addLog(this.statusValue.message, 'warn'); return; }
    if (typeof WebSocket !== 'function' || typeof fetch !== 'function') { this.statusValue.message = '需要 Node.js 22 或更高版本'; this.addLog(this.statusValue.message, 'error'); return; }
    await this.connect();
  }
  async connect() {
    const config = this.config();
    try {
      const response = await fetch('https://discord.com/api/v10/gateway/bot', { headers: { Authorization: `Bot ${config.token}` } });
      if (!response.ok) throw new Error(`Gateway 查询失败（HTTP ${response.status}）`);
      const data = await response.json(); if (!data.url) throw new Error('Discord 没有返回 Gateway 地址');
      this.socket = new WebSocket(`${data.url}?v=10&encoding=json`);
      this.socket.onopen = () => { this.statusValue.connected = true; this.statusValue.message = '已连接，等待鉴权'; };
      this.socket.onmessage = event => this.handleMessage(event.data);
      this.socket.onerror = () => { this.statusValue.message = 'Gateway 连接错误'; };
      this.socket.onclose = () => { this.statusValue.connected = false; this.statusValue.ready = false; this.statusValue.commandsRegistered = false; if (!this.stopping && this.config().enabled) this.scheduleReconnect(); };
    } catch (error) { this.statusValue.message = error.message; this.addLog(error.message, 'error'); this.scheduleReconnect(); }
  }
  handleMessage(raw) {
    let packet; try { packet = JSON.parse(String(raw)); } catch (_) { return; }
    if (packet.s !== null && packet.s !== undefined) this.sequence = packet.s;
    if (packet.op === 10) {
      clearInterval(this.heartbeat); this.heartbeat = setInterval(() => this.send({ op: 1, d: this.sequence }), packet.d.heartbeat_interval);
      const config = this.config(); this.send({ op: 2, d: { token: config.token, intents: Number(config.intents) || 33281, properties: { os: process.platform, browser: 'chunithm-mobile-server', device: 'chunithm-mobile-server' } } }); return;
    }
    if (packet.op === 7) { this.socket?.close(); return; }
    if (packet.op === 9) { this.statusValue.message = 'Discord 鉴权被拒绝'; this.addLog(this.statusValue.message, 'error'); return; }
    if (packet.op === 0 && packet.t === 'READY') {
      this.statusValue.ready = true; this.applicationId = String(packet.d?.application?.id || this.config().applicationId || packet.d?.user?.id || '');
      this.statusValue.message = `已登录 ${packet.d?.user?.username || 'Discord Bot'}`; this.addLog(this.statusValue.message); this.audit('discordBotReady', { userId: packet.d?.user?.id || '' });
      this.registerCommands().catch(error => this.addLog(`斜杠指令注册失败：${error.message}`, 'error')); return;
    }
    if (packet.op === 0 && packet.t === 'MESSAGE_CREATE') this.handleMessageCreate(packet.d).catch(error => this.addLog(error.message, 'error'));
    if (packet.op === 0 && packet.t === 'INTERACTION_CREATE') this.handleInteraction(packet.d).catch(error => this.addLog(error.message, 'error'));
  }
  allowed(source) { const config = this.config(), guild = String(source.guild_id || ''), channel = String(source.channel_id || ''); if (config.guildAllowlist?.length && !config.guildAllowlist.includes(guild)) return false; if (config.channelAllowlist?.length && !config.channelAllowlist.includes(channel)) return false; return true; }
  userId(source) { return String(source.member?.user?.id || source.user?.id || source.author?.id || ''); }
  roles(source) { return Array.isArray(source.member?.roles) ? source.member.roles.map(String) : []; }
  isAdmin(source) { const config = this.config(), id = this.userId(source); return (config.adminUserIds || []).map(String).includes(id) || this.roles(source).some(role => (config.adminRoleIds || []).map(String).includes(role)); }
  isMember(source) { const config = this.config(); return this.isAdmin(source) || config.membersOnly !== true || this.roles(source).some(role => (config.memberRoleIds || []).map(String).includes(role)); }
  canUse(source) { return this.allowed(source) && this.isMember(source); }
  normalize(value) { return this.normalizeCommand(value) || String(value || '').trim().toLowerCase(); }
  context(source) { return { openId: this.userId(source), sourceOpenId: String(source.channel_id || source.guild_id || 'private'), platform: 'discord' }; }
  async handleMessageCreate(message) {
    if (!message || message.author?.bot || !this.allowed(message)) return;
    const content = String(message.content || '').trim(), prefix = this.config().commandPrefix || '!';
    if (!content.startsWith('/') && !content.startsWith(prefix)) return;
    const text = content.slice(content.startsWith('/') ? 1 : prefix.length).trim(), parts = text.split(/\s+/).filter(Boolean), command = this.normalize(parts.shift() || 'help');
    if (command !== 'bindadmin' && !this.isMember(message)) return;
    if (command === 'bindadmin') { const bound = this.consumeBindingCode(parts[0]?.replace(/^code:/i, ''), this.userId(message), message.guild_id); return this.reply(message.channel_id, bound ? 'Discord 管理员绑定成功。' : '绑定码无效或已过期。'); }
    const output = this.executeCommand(command, parts, this.isAdmin(message), this.context(message)); if (output) await this.reply(message.channel_id, output);
  }
  optionValues(interaction) { const result = {}; const visit = options => (options || []).forEach(option => { if (option.type === 1 || option.type === 2) visit(option.options); else result[option.name] = option.value; }); visit(interaction.data?.options); return result; }
  async handleInteraction(interaction) {
    if (interaction.type !== 2 || !this.allowed(interaction)) return;
    const name = String(interaction.data?.name || '').toLowerCase(), options = this.optionValues(interaction), ephemeral = ['zxdl', 'jrzq', 'bindadmin', 'glzxry', 'glfj', 'glycfj', 'scjrm', 'gljrm', 'jyjrm', 'qyjrm'].includes(name);
    if (name !== 'bindadmin' && !this.isMember(interaction)) return;
    let output;
    if (name === 'bindadmin') { const bound = this.consumeBindingCode(String(options.code || '').replace(/^code:/i, ''), this.userId(interaction), interaction.guild_id); output = bound ? 'Discord 管理员绑定成功。' : '绑定码无效或已过期。'; }
    else {
      const command = this.normalize(name), args = [];
      if (name === 'fj' || name === 'glfj') args.push(options.room_id || '');
      if (name === 'jrzq') args.push(String(options.index || ''), String(options.code || ''));
      if (name === 'scjrm') args.push(String(options.group_id || ''), String(options.count || ''), String(options.uses || ''));
      if (['jyjrm', 'qyjrm'].includes(name)) args.push(String(options.code_id || ''));
      output = this.executeCommand(command, args, this.isAdmin(interaction), this.context(interaction));
    }
    await this.respondInteraction(interaction, output || '没有可返回的内容。', ephemeral);
  }
  async respondInteraction(interaction, content, ephemeral) {
    const token = this.config().token, applicationId = this.applicationId || this.config().applicationId; if (!token || !applicationId || !interaction.id || !interaction.token) return;
    const response = await fetch(`https://discord.com/api/v10/interactions/${interaction.id}/${interaction.token}/callback`, { method: 'POST', headers: { Authorization: `Bot ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 4, data: { content: String(content).slice(0, 1900), flags: ephemeral ? 64 : 0 } }) });
    if (!response.ok) throw new Error(`发送 Discord 斜杠回复失败（HTTP ${response.status}）`);
  }
  async reply(channelId, content) {
    const token = this.config().token; if (!channelId || !token) return;
    const response = await fetch(`https://discord.com/api/v10/channels/${encodeURIComponent(channelId)}/messages`, { method: 'POST', headers: { Authorization: `Bot ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ content: String(content).slice(0, 1900) }) });
    if (!response.ok) throw new Error(`发送 Discord 消息失败（HTTP ${response.status}）`);
  }
  commandDefinitions() {
    const string = (name, description, required = true) => ({ type: 3, name, description, required });
    const integer = (name, description, required = true, min = 1) => ({ type: 4, name, description, required, min_value: min });
    return [
      ['help', '显示可用指令'], ['fwqzt', '查看服务端状态'], ['zxrs', '查看在线人数'], ['zxdl', '查看最近登录玩家'], ['zxwj', '查看在线玩家'], ['gkfj', '查看公开房间'], ['czfj', '查看当前常驻房间'],
      { name: 'fj', description: '查看公开房间详情', options: [string('room_id', '六位房间号')] }, ['jrm', '查看群组加入码使用说明'],
      { name: 'jrzq', description: '使用加入码绑定玩家群组', options: [integer('index', '最近登录列表编号'), string('code', '群组加入码')] },
      { name: 'bindadmin', description: '使用后台一次性绑定码成为管理员', options: [string('code', '后台生成的绑定码')] }, ['glzxry', '管理员：查看在线人员'],
      { name: 'glfj', description: '管理员：查看房间管理信息', options: [string('room_id', '可选，六位房间号', false)] }, ['glycfj', '管理员：查看隐藏房间'],
      { name: 'scjrm', description: '管理员：生成群组加入码', options: [string('group_id', '群组 ID'), integer('count', '生成数量'), integer('uses', '每个码使用次数', false, -1)] }, ['gljrm', '管理员：查看加入码'],
      { name: 'jyjrm', description: '管理员：禁用加入码', options: [string('code_id', '加入码内部编号')] }, { name: 'qyjrm', description: '管理员：启用加入码', options: [string('code_id', '加入码内部编号')] }
    ].map(item => Array.isArray(item) ? { name: item[0], description: item[1] } : item);
  }
  async registerCommands() {
    const config = this.config(), applicationId = this.applicationId || config.applicationId; if (!applicationId) { this.addLog('未配置 Application ID，无法注册斜杠指令。', 'warn'); return; }
    const body = this.commandDefinitions(), guilds = Array.isArray(config.guildAllowlist) ? config.guildAllowlist.filter(Boolean) : [], targets = guilds.length ? guilds.map(id => `guilds/${encodeURIComponent(id)}/commands`) : ['commands'];
    for (const suffix of targets) { const response = await fetch(`https://discord.com/api/v10/applications/${encodeURIComponent(applicationId)}/${suffix}`, { method: 'PUT', headers: { Authorization: `Bot ${config.token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); if (!response.ok) throw new Error(`HTTP ${response.status}`); }
    this.statusValue.commandsRegistered = true; this.addLog(`已注册 ${body.length} 个斜杠指令（${guilds.length ? '指定服务器' : '全局'}）。`);
  }
  send(packet) { if (this.socket && this.socket.readyState === 1) this.socket.send(JSON.stringify(packet)); }
  scheduleReconnect() { if (this.reconnectTimer || this.stopping) return; this.reconnectTimer = setTimeout(() => { this.reconnectTimer = null; this.start(); }, 10000); this.reconnectTimer.unref?.(); }
  stop() { this.stopping = true; clearInterval(this.heartbeat); clearTimeout(this.reconnectTimer); this.heartbeat = null; this.reconnectTimer = null; if (this.socket) { try { this.socket.close(); } catch (_) {} } this.socket = null; this.statusValue.connected = false; this.statusValue.ready = false; this.statusValue.commandsRegistered = false; this.statusValue.message = '已停止'; }
}

module.exports = { DiscordBot };
