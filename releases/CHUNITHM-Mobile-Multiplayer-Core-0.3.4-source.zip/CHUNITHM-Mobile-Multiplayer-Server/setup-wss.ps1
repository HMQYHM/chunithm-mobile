﻿param([ValidateSet('zh','en')][string]$Language='zh')
$ErrorActionPreference='Stop'; Set-Location $PSScriptRoot
$m=if($Language -eq 'zh'){@{domain='请输入域名，例如 game.example.com';dns='检查域名解析';caddy='检查 Caddy';write='生成 Caddyfile';validate='校验配置';backend='检查本地服务';start='本地服务未运行，正在启动';ready='配置完成，Caddy 将自动申请并续期证书';keep='请保持此窗口运行';missing='未找到 caddy.exe，请将它放到服务端目录';fail='操作失败';timeout='本地服务在 30 秒内未能启动，请查看 server-startup.log';client='客户端地址'}}else{@{domain='Enter domain name, for example game.example.com';dns='Checking DNS resolution';caddy='Checking Caddy';write='Writing Caddyfile';validate='Validating configuration';backend='Checking local server';start='Local server is not running. Starting it';ready='Setup is ready. Caddy will request and renew certificates automatically';keep='Keep this window open';missing='caddy.exe was not found. Place it in the server directory';fail='Operation failed';timeout='The local server did not start within 30 seconds. Check server-startup.log';client='Client address'}}
try{
  $domain=Read-Host $m.domain;if($null -eq $domain){$domain=''};$domain=$domain.Trim().ToLowerInvariant();if($domain -notmatch '^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$'){throw 'Invalid domain name'}
  $caddy=Join-Path $PSScriptRoot 'caddy.exe';if(!(Test-Path $caddy)){throw $m.missing}
  Write-Host "[1/4] $($m.dns): $domain";Resolve-DnsName $domain|Out-Null
  Write-Host "[2/4] $($m.caddy)";& $caddy version;if($LASTEXITCODE){throw 'caddy.exe could not run'}
  Write-Host "[3/4] $($m.write)";"$domain {`r`n    reverse_proxy 127.0.0.1:27960`r`n}"|Set-Content (Join-Path $PSScriptRoot 'Caddyfile') -Encoding utf8
  & $caddy fmt --overwrite (Join-Path $PSScriptRoot 'Caddyfile')|Out-Null
  Write-Host "[4/4] $($m.validate)";& $caddy validate --config (Join-Path $PSScriptRoot 'Caddyfile');if($LASTEXITCODE){throw 'Caddy validation failed'}
  & node (Join-Path $PSScriptRoot 'configure-caddy-mode.js') $domain;if($LASTEXITCODE){throw 'Unable to update config.json'}
  Write-Host $m.backend
  function Test-Backend{try{$c=[Net.Sockets.TcpClient]::new();$c.Connect('127.0.0.1',27960);$c.Dispose();$true}catch{$false}}
  if(!(Test-Backend)){Write-Host $m.start;Start-Process (Join-Path $PSScriptRoot 'start-wss-backend.bat');$ok=$false;1..30|ForEach-Object{if(!$ok){Start-Sleep 1;$ok=Test-Backend}};if(!$ok){throw $m.timeout}}
  Write-Host '';Write-Host $m.ready -ForegroundColor Green;Write-Host "$($m.client): wss://$domain/ws";Write-Host $m.keep
  & $caddy run --config (Join-Path $PSScriptRoot 'Caddyfile')
}catch{Write-Host "$($m.fail): $($_.Exception.Message)" -ForegroundColor Red;Read-Host 'Press Enter';exit 1}
