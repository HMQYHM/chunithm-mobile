'use strict';

const fs = require('fs');
const http = require('http');
const https = require('https');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const dns = require('dns');
const { URL } = require('url');
const { QQBot } = require('./qq-bot');
const { DiscordBot } = require('./discord-bot');

const SERVER_VERSION = '0.3.4';
const PROTOCOL_VERSION = 2;
const MAX_PLAYER_NAME_HISTORY = 10;
const LOBBY_REENTRY_COOLDOWN_MS = 60 * 1000;
const WEBSOCKET_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const DEFAULT_CONFIG = {
  host: '0.0.0.0',
  port: 27960,
  authToken: '',
  adminToken: '',
  adminLocalOnly: true,
  maxConnections: 64,
  maxConnectionsPerIp: 8,
  maxRooms: 128,
  maxPlayersPerRoom: 20,
  songChangeVoteRequiredRatio: 0.5,
  songLibraryPath: '',
  maxMessageBytes: 65536,
  messagesPer10Seconds: 80,
  roomIdleMinutes: 60,
  idleClientMinutes: 30,
  idleWarningSeconds: 60,
  backgroundTimeoutMinutes: 10,
  roomReservationSeconds: 120,
  maxTransferBytes: 1024 * 1024 * 1024,
  transferRetentionMinutes: 60,
  qqBot: {
    enabled: false,
    provider: 'official',
    appId: '',
    appSecret: '',
    oneBotUrl: 'ws://127.0.0.1:3001',
    oneBotToken: '',
    allowNoPrefixGroup: true,
    oneBotGroupOnly: false,
    oneBotGroupAllowlist: [],
    oneBotPrivateReplies: true,
    recordOneBotImages: false,
    pokeCommand: 'zxrs',
    apiBase: 'https://api.sgroup.qq.com',
    commandPrefix: '!',
    sourceAllowlist: [],
    adminOpenIds: [],
    // Public channel messages + group/C2C private-message events.
    intents: 1107296256,
    rateLimitPerMinute: 20
  },
  discordBot: {
    enabled: false,
    token: '',
    applicationId: '',
    commandPrefix: '!',
    guildAllowlist: [],
    channelAllowlist: [],
    membersOnly: false,
    memberRoleIds: [],
    adminRoleIds: [],
    adminUserIds: [],
    intents: 33281
  },
  tls: { enabled: false, domain: '', keyPath: 'certs/server.key', certPath: 'certs/server.crt' }
};

const MOD_KEYS = [
  'autoPlay',
  'airAreaAuto',
  'directionalAirAuto',
  'airLongNoMotion',
  'flickAllTap',
  'flickSimpleMode',
  'mineImmunity',
  'mirrorChart',
  'fullscreenTouchpad'
];
const ALLOWED_RATES = [0.8, 1.0, 1.2, 1.5];
const ROOM_MODES = new Set(['casual', 'normal']);
const SELECTION_MODES = new Set(['host', 'loop']);
const ROOM_TYPES = new Set(['personal', 'persistent']);
const PERSONAL_ROOM_MAX_PLAYERS = 8;
const PERSISTENT_ROOM_MAX_PLAYERS = 20;
const ROOM_STATES = new Set([
  'lobby', 'syncing', 'loading', 'countdown', 'playing',
  'personalResults', 'groupResults'
]);
const DEFAULT_GROUP = {
  id: 'default',
  name: '默认群组',
  createRoomLimit: 5,
  joinRoomLimit: 20
};
const MEANINGFUL_ACTIVITY_TYPES = new Set([
  'listRooms',
  'createRoom',
  'joinRoom',
  'leaveRoom',
  'reserveRoomId',
  'releaseRoomId',
  'setReady',
  'setSongSyncStatus',
  'setMemberBest',
  'setRoundLoaded',
  'roundLoadFailed',
  'exitRound',
  'submitResult',
  'confirmPersonalResult',
  'confirmGroupResult',
  'appState',
  'leaveLobby',
  'updateRoomSettings',
  'selectSong',
  'listLibrarySongs',
  'selectLibrarySong',
  'requestRandomLibrarySong',
  'transferHost',
  'transferProgress',
  'startRound',
  'kickPlayer',
  'requestSongChangeVote',
  'castSongChangeVote'
]);

function loadConfig() {
  const configPath = path.join(__dirname, 'config.json');
  let fromDisk = {};
  try {
    fromDisk = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  } catch (error) {
    console.warn(`[config] Unable to read config.json, using defaults: ${error.message}`);
  }
  const config = {
    ...DEFAULT_CONFIG,
    ...fromDisk,
    tls: { ...DEFAULT_CONFIG.tls, ...(fromDisk.tls || {}) }
  };
  config.port = integerInRange(config.port, 1, 65535, DEFAULT_CONFIG.port);
  config.maxConnections = integerInRange(config.maxConnections, 1, 512, DEFAULT_CONFIG.maxConnections);
  config.maxConnectionsPerIp = integerInRange(config.maxConnectionsPerIp, 1, 32, DEFAULT_CONFIG.maxConnectionsPerIp);
  config.maxRooms = integerInRange(config.maxRooms, 1, 4096, DEFAULT_CONFIG.maxRooms);
  config.maxPlayersPerRoom = integerInRange(config.maxPlayersPerRoom, 2, 20, DEFAULT_CONFIG.maxPlayersPerRoom);
  const voteRatio = Number(config.songChangeVoteRequiredRatio);
  config.songChangeVoteRequiredRatio = Number.isFinite(voteRatio)
    ? Math.max(0.1, Math.min(1, voteRatio)) : DEFAULT_CONFIG.songChangeVoteRequiredRatio;
  config.songLibraryPath = typeof config.songLibraryPath === 'string'
    ? config.songLibraryPath.trim().slice(0, 1024) : '';
  config.maxMessageBytes = integerInRange(config.maxMessageBytes, 1024, 1024 * 1024, DEFAULT_CONFIG.maxMessageBytes);
  config.messagesPer10Seconds = integerInRange(config.messagesPer10Seconds, 10, 1000, DEFAULT_CONFIG.messagesPer10Seconds);
  config.roomIdleMinutes = integerInRange(config.roomIdleMinutes, 5, 24 * 60, DEFAULT_CONFIG.roomIdleMinutes);
  config.idleClientMinutes = integerInRange(config.idleClientMinutes, 5, 24 * 60, DEFAULT_CONFIG.idleClientMinutes);
  config.idleWarningSeconds = integerInRange(config.idleWarningSeconds, 15, 300, DEFAULT_CONFIG.idleWarningSeconds);
  config.backgroundTimeoutMinutes = integerInRange(config.backgroundTimeoutMinutes, 1, 60, DEFAULT_CONFIG.backgroundTimeoutMinutes);
  config.roomReservationSeconds = integerInRange(config.roomReservationSeconds, 30, 600, DEFAULT_CONFIG.roomReservationSeconds);
  config.maxTransferBytes = integerInRange(config.maxTransferBytes, 1024 * 1024, 2 * 1024 * 1024 * 1024,
    DEFAULT_CONFIG.maxTransferBytes);
  config.transferRetentionMinutes = integerInRange(config.transferRetentionMinutes, 5, 24 * 60,
    DEFAULT_CONFIG.transferRetentionMinutes);
  if (config.idleWarningSeconds >= config.idleClientMinutes * 60) {
    config.idleWarningSeconds = DEFAULT_CONFIG.idleWarningSeconds;
  }
  config.host = typeof config.host === 'string' && config.host.length > 0 ? config.host : DEFAULT_CONFIG.host;
  config.authToken = typeof config.authToken === 'string' ? config.authToken : '';
  config.adminToken = typeof config.adminToken === 'string' ? config.adminToken : '';
  config.adminLocalOnly = fromDisk.adminLocalOnly !== false;
  config.tls.enabled = config.tls.enabled === true;
  config.tls.domain = typeof config.tls.domain === 'string' ? config.tls.domain.trim().slice(0, 253) : '';
  config.qqBot = normalizeQqBotConfig(config.qqBot);
  config.discordBot = normalizeDiscordBotConfig(config.discordBot);
  return config;
}

function normalizeDiscordBotConfig(value) {
  const input = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const list = key => Array.isArray(input[key])
    ? [...new Set(input[key].filter(item => typeof item === 'string').map(item => item.trim()).filter(item => /^\d{5,25}$/.test(item)))].slice(0, 200)
    : [];
  const prefix = typeof input.commandPrefix === 'string' && input.commandPrefix.trim().length <= 8
    ? input.commandPrefix.trim() : '!';
  const intents = Number(input.intents);
  return {
    enabled: input.enabled === true,
    token: typeof input.token === 'string' ? input.token.trim().slice(0, 512) : '',
    applicationId: typeof input.applicationId === 'string' ? input.applicationId.trim().slice(0, 32) : '',
    commandPrefix: prefix || '!',
    guildAllowlist: list('guildAllowlist'),
    channelAllowlist: list('channelAllowlist'),
    membersOnly: input.membersOnly === true,
    memberRoleIds: list('memberRoleIds'),
    adminRoleIds: list('adminRoleIds'),
    adminUserIds: list('adminUserIds'),
    intents: Number.isSafeInteger(intents) && intents > 0 ? intents : 33281
  };
}

function normalizeQqBotConfig(value) {
  const input = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const list = key => Array.isArray(input[key]) ? input[key].filter(item => typeof item === 'string').map(item => item.trim()).filter(Boolean).slice(0, 200) : [];
  const prefix = typeof input.commandPrefix === 'string' && input.commandPrefix.trim().length <= 8 ? input.commandPrefix.trim() : '!';
  const rate = Number(input.rateLimitPerMinute);
  const oneBotUrl = typeof input.oneBotUrl === 'string' && /^wss?:\/\//i.test(input.oneBotUrl.trim()) && input.oneBotUrl.length <= 512
    ? input.oneBotUrl.trim() : DEFAULT_CONFIG.qqBot.oneBotUrl;
  const pokeCommand = typeof input.pokeCommand === 'string' ? input.pokeCommand.trim().slice(0, 32) : 'zxrs';
  return {
    enabled: input.enabled === true,
    provider: input.provider === 'napcat' ? 'napcat' : 'official',
    appId: typeof input.appId === 'string' ? input.appId.trim().slice(0, 128) : '',
    appSecret: typeof input.appSecret === 'string' ? input.appSecret.trim().slice(0, 256) : '',
    oneBotUrl,
    oneBotToken: typeof input.oneBotToken === 'string' ? input.oneBotToken.trim().slice(0, 512) : '',
    allowNoPrefixGroup: input.allowNoPrefixGroup !== false,
    oneBotGroupOnly: input.oneBotGroupOnly === true,
    oneBotGroupAllowlist: list('oneBotGroupAllowlist').filter(id => /^\d{5,20}$/.test(id)),
    oneBotPrivateReplies: input.oneBotPrivateReplies !== false,
    recordOneBotImages: input.recordOneBotImages === true,
    pokeCommand: pokeCommand || 'zxrs',
    apiBase: typeof input.apiBase === 'string' && /^https:\/\//.test(input.apiBase) ? input.apiBase.replace(/\/$/, '') : 'https://api.sgroup.qq.com',
    commandPrefix: prefix || '!',
    sourceAllowlist: list('sourceAllowlist'),
    adminOpenIds: list('adminOpenIds'),
    adminQqIds: list('adminQqIds').filter(id => /^\d{5,20}$/.test(id)),
    intents: Number.isSafeInteger(Number(input.intents)) ? Number(input.intents) : 1107296256,
    rateLimitPerMinute: Number.isInteger(rate) && rate >= 1 && rate <= 120 ? rate : 20
  };
}

function integerInRange(value, min, max, fallback) {
  const number = Number(value);
  return Number.isInteger(number) && number >= min && number <= max ? number : fallback;
}

const config = loadConfig();
const clients = new Set();
const rooms = new Map();
const reservedRoomIds = new Map();
const ipConnectionCounts = new Map();
// A temporary data directory can be supplied for smoke tests or staging. The
// production default remains the existing data directory so deployments keep
// their device IDs, quotas, security token, and audit history.
const DATA_DIR = process.env.CHUNITHM_DATA_DIR
  ? path.resolve(process.env.CHUNITHM_DATA_DIR)
  : path.join(__dirname, 'data');
const SECURITY_PATH = path.join(DATA_DIR, 'security.json');
const SERVER_STATE_PATH = path.join(DATA_DIR, 'server-state.json');
const PERSISTENT_ROOMS_PATH = path.join(DATA_DIR, 'persistent-rooms.json');
const TRANSFER_DIR = path.join(DATA_DIR, 'transfers');
const SONG_LIBRARY_DIR = config.songLibraryPath
  ? path.resolve(config.songLibraryPath)
  : path.join(DATA_DIR, 'song-library');
const SONG_LIBRARY_PACKAGES_DIR = path.join(SONG_LIBRARY_DIR, 'packages');
const SONG_LIBRARY_STAGING_DIR = path.join(SONG_LIBRARY_DIR, 'import-staging');
const SONG_LIBRARY_GENERATED_DIR = path.join(SONG_LIBRARY_DIR, 'generated');
const SONG_LIBRARY_INDEX_PATH = path.join(SONG_LIBRARY_DIR, 'index.json');
const SONG_LIBRARY_SESSIONS_PATH = path.join(SONG_LIBRARY_DIR, 'import-sessions.json');
fs.mkdirSync(TRANSFER_DIR, { recursive: true });
fs.mkdirSync(SONG_LIBRARY_PACKAGES_DIR, { recursive: true });
fs.mkdirSync(SONG_LIBRARY_STAGING_DIR, { recursive: true });
fs.mkdirSync(SONG_LIBRARY_GENERATED_DIR, { recursive: true });
const securityFileWasPresent = fs.existsSync(SECURITY_PATH);
const security = loadSecurity();
config.qqBot.appSecret = decryptQqSecret(config.qqBot.appSecret);
config.qqBot.oneBotToken = decryptQqSecret(config.qqBot.oneBotToken);
config.discordBot.token = decryptQqSecret(config.discordBot.token);
const serverState = loadServerState();

function normalizeLibrarySelection(value) {
  const input = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const mode = ['all', 'songs', 'levels', 'random'].includes(input.mode) ? input.mode : 'all';
  const songIds = Array.isArray(input.songIds)
    ? [...new Set(input.songIds.filter(item => typeof item === 'string').map(item => item.trim()).filter(Boolean))].slice(0, 500)
    : [];
  const levels = Array.isArray(input.levels)
    ? [...new Set(input.levels.filter(item => typeof item === 'string').map(item => item.trim()).filter(Boolean))].slice(0, 100)
    : [];
  const randomCount = integerInRange(input.randomCount, 0, 20, 1);
  return { mode, songIds, levels, randomCount };
}

function readZipDirectory(filePath) {
  const size = fs.statSync(filePath).size;
  const tailSize = Math.min(size, 1024 * 1024 + 65557);
  const handle = fs.openSync(filePath, 'r');
  try {
    const tail = Buffer.alloc(tailSize);
    fs.readSync(handle, tail, 0, tailSize, size - tailSize);
    let eocd = -1;
    for (let index = tail.length - 22; index >= 0; index -= 1) {
      if (tail.readUInt32LE(index) === 0x06054b50) { eocd = index; break; }
    }
    if (eocd < 0) throw new Error('ZIP 目录不存在或格式不受支持。');
    const entries = tail.readUInt16LE(eocd + 10);
    const directorySize = tail.readUInt32LE(eocd + 12);
    const directoryOffset = tail.readUInt32LE(eocd + 16);
    if (entries > 100000 || directorySize > 64 * 1024 * 1024 || directoryOffset + directorySize > size)
      throw new Error('ZIP 目录大小无效。');
    const directory = Buffer.alloc(directorySize);
    fs.readSync(handle, directory, 0, directorySize, directoryOffset);
    const result = [];
    let offset = 0;
    while (offset + 46 <= directory.length && result.length < entries) {
      if (directory.readUInt32LE(offset) !== 0x02014b50) throw new Error('ZIP 中央目录损坏。');
      const method = directory.readUInt16LE(offset + 10);
      const compressedSize = directory.readUInt32LE(offset + 20);
      const uncompressedSize = directory.readUInt32LE(offset + 24);
      const nameSize = directory.readUInt16LE(offset + 28);
      const extraSize = directory.readUInt16LE(offset + 30);
      const commentSize = directory.readUInt16LE(offset + 32);
      const localOffset = directory.readUInt32LE(offset + 42);
      const name = directory.subarray(offset + 46, offset + 46 + nameSize).toString('utf8');
      result.push({ name, method, compressedSize, uncompressedSize, localOffset });
      offset += 46 + nameSize + extraSize + commentSize;
    }
    if (result.length !== entries) throw new Error('ZIP 条目数量不一致。');
    return result;
  } finally { fs.closeSync(handle); }
}

function readZipEntry(filePath, entry) {
  const handle = fs.openSync(filePath, 'r');
  try {
    const localHeader = Buffer.alloc(30);
    fs.readSync(handle, localHeader, 0, 30, entry.localOffset);
    if (localHeader.readUInt32LE(0) !== 0x04034b50) throw new Error('ZIP 本地文件头损坏。');
    const nameSize = localHeader.readUInt16LE(26);
    const extraSize = localHeader.readUInt16LE(28);
    if (entry.compressedSize > 32 * 1024 * 1024) throw new Error('ZIP 元数据条目过大。');
    const compressed = Buffer.alloc(entry.compressedSize);
    fs.readSync(handle, compressed, 0, entry.compressedSize, entry.localOffset + 30 + nameSize + extraSize);
    if (entry.method === 0) return compressed;
    if (entry.method === 8) return zlib.inflateRawSync(compressed, { maxOutputLength: 32 * 1024 * 1024 });
    throw new Error(`ZIP 条目压缩方式不支持：${entry.method}`);
  } finally { fs.closeSync(handle); }
}

// The game importer stores one song per directory instead of writing a
// server-side songs.json manifest. These helpers keep that format dependency
// free and produce a normal ZIP only when a song is selected for multiplayer.
const ZIP_CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let index = 0; index < table.length; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) value = (value & 1) ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    table[index] = value >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let value = 0xffffffff;
  for (const byte of bytes) value = ZIP_CRC_TABLE[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}

function pathIsInside(root, candidate) {
  const base = path.resolve(root);
  const value = path.resolve(candidate);
  return value === base || value.startsWith(base + path.sep);
}

function walkSongFiles(root, current = root, output = []) {
  if (!pathIsInside(root, current) || output.length > 100000) throw new Error('歌曲目录层级或文件数量超出限制。');
  for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
    const fullPath = path.join(current, entry.name);
    if (entry.isSymbolicLink()) throw new Error(`歌曲目录不允许包含符号链接：${entry.name}`);
    if (entry.isDirectory()) walkSongFiles(root, fullPath, output);
    else if (entry.isFile()) output.push({ absolutePath: fullPath, relativePath: path.relative(root, fullPath).split(path.sep).join('/') });
  }
  return output;
}

function fileHash(filePath) {
  const hash = crypto.createHash('sha256');
  hash.update(fs.readFileSync(filePath));
  return hash.digest('hex');
}

function xmlTagValues(xml, names) {
  const values = [];
  for (const name of names) {
    const expression = new RegExp(`<${name}\\b[^>]*>([\\s\\S]*?)</${name}>`, 'gi');
    let match;
    while ((match = expression.exec(xml))) values.push(match[1].replace(/<[^>]+>/g, '').trim());
  }
  return values.filter(Boolean);
}

function xmlPathValue(xml, tags) {
  let value = xml;
  for (const tag of tags.split('/')) {
    const match = new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)</${tag}>`, 'i').exec(value);
    if (!match) return '';
    value = match[1];
  }
  return value.replace(/<[^>]+>/g, '').trim();
}

function folderRelativeFile(files, predicate) {
  return files.find(file => predicate(file.relativePath)) || null;
}

function chartDifficultyFromName(fileName) {
  const match = /_(0[0-4])\.c2s$/i.exec(fileName);
  if (!match) return 'UNKNOWN';
  return ['BASIC', 'ADVANCED', 'EXPERT', 'MASTER', 'ULTIMA'][Number(match[1])];
}

function normalizeFolderSong(session, songDirectory, files) {
  const manifestFile = files.find(file => file.relativePath.toLowerCase() === 'manifest.json');
  let manifest = {};
  if (manifestFile) {
    try { manifest = JSON.parse(fs.readFileSync(manifestFile.absolutePath, 'utf8')); }
    catch (error) { throw new Error(`manifest.json 解析失败：${error.message}`); }
  }
  const musicFile = files.find(file => file.relativePath.toLowerCase() === 'chart/music.xml');
  const musicXml = musicFile ? fs.readFileSync(musicFile.absolutePath, 'utf8') : '';
  const fumenMeta = new Map([...musicXml.matchAll(/<MusicFumenData\b[^>]*>([\s\S]*?)<\/MusicFumenData>/gi)]
    .map(match => match[1])
    .filter(block => /^true$/i.test(xmlPathValue(block, 'enable')) && xmlPathValue(block, 'file/path'))
    .map(block => {
      const decimal = Number(xmlPathValue(block, 'levelDecimal'));
      let level = xmlPathValue(block, 'level');
      if (Number.isInteger(decimal) && decimal >= 50 && decimal <= 99) level += '+';
      return [path.basename(xmlPathValue(block, 'file/path')), {
        difficulty: xmlPathValue(block, 'type/data') || xmlPathValue(block, 'type/str'),
        level,
        designer: xmlPathValue(block, 'notesDesigner/str') || xmlPathValue(block, 'notesDesigner')
      }];
    }));
  const levels = xmlTagValues(musicXml, ['level', 'lev', 'levelValue', 'levelName']);
  const designers = xmlTagValues(musicXml, ['designer', 'maker', 'author']);
  const categoryFile = files.find(file => file.relativePath.toLowerCase() === 'category.txt');
  const category = categoryFile ? fs.readFileSync(categoryFile.absolutePath, 'utf8').trim() : '';
  const chartFiles = files.filter(file => /\.c2s$/i.test(file.relativePath));
  if (!chartFiles.length) throw new Error('歌曲目录至少需要一份 .c2s 谱面文件。');
  const manifestCharts = Array.isArray(manifest.files)
    ? manifest.files.filter(item => item && item.type === 'chart' && /\.c2s$/i.test(String(item.file || ''))).map(item => String(item.file))
    : [];
  const fileDescriptors = files.map(file => ({ path: file.relativePath, size: fs.statSync(file.absolutePath).size, hash: fileHash(file.absolutePath) }));
  const fileHashes = new Map(fileDescriptors.map(file => [file.path, file.hash]));
  const charts = chartFiles.map((file, index) => {
    const name = path.basename(file.relativePath);
    const metadata = fumenMeta.get(name) || {};
    return {
      difficulty: cleanText(metadata.difficulty || chartDifficultyFromName(name), 32),
      level: cleanText(metadata.level || levels[index] || '', 16),
      designer: cleanText(metadata.designer || designers[index] || '', 96),
      chartPath: file.relativePath,
      chartHash: fileHashes.get(file.relativePath),
      sourceFile: manifestCharts[index] || name
    };
  });
  const cover = folderRelativeFile(files, value => /(?:^|\/)CHU_UI_Jacket_[^/]+\.(?:dds|png|jpe?g)$/i.test(value)) ||
    folderRelativeFile(files, value => /\.(?:dds|png|jpe?g)$/i.test(value));
  const audio = folderRelativeFile(files, value => /(?:^|\/)audio\/[^/]+\.(?:mp3|ogg|wav)$/i.test(value)) ||
    folderRelativeFile(files, value => /\.(?:mp3|ogg|wav)$/i.test(value));
  const sourceFingerprint = crypto.createHash('sha256').update(JSON.stringify(fileDescriptors)).digest('hex');
  const rawSongId = manifest.songId ?? manifest.id ?? path.basename(songDirectory);
  const songId = cleanText(String(rawSongId), 128);
  const songName = cleanText(manifest.songName || manifest.name || xmlPathValue(musicXml, 'name/str') || songId, 160);
  const packageHash = crypto.createHash('sha256').update(`folder-v1\\0${session.id}\\0${songId}\\0${sourceFingerprint}`).digest('hex');
  return {
    packageHash,
    packageSize: 0,
    fileName: `folder:${session.id}/${songId}`,
    path: '',
    sourceType: 'folder',
    sourceRoot: session.path,
    songDirectory,
    sourceFingerprint,
    importedAt: isoTime(),
    songs: [{
      songId,
      songName,
      artist: cleanText(manifest.artist || manifest.composer || xmlPathValue(musicXml, 'artistName/str'), 160),
      category: category || xmlPathValue(musicXml, 'genreNames/list/StringID/str'),
      bpm: cleanText(manifest.bpm || '', 24),
      durationText: cleanText(manifest.durationText || '', 16),
      coverPath: cover ? cover.relativePath : '',
      coverHash: cover ? fileHashes.get(cover.relativePath) : '',
      coverSize: cover ? fs.statSync(cover.absolutePath).size : 0,
      audioPath: audio ? audio.relativePath : '',
      charts
    }]
  };
}

function collectFolderSongs(session) {
  const directories = [];
  const visit = current => {
    if (!pathIsInside(session.path, current)) throw new Error('扫描目录越界。');
    const entries = fs.readdirSync(current, { withFileTypes: true });
    const hasManifest = entries.some(entry => entry.isFile() && entry.name.toLowerCase() === 'manifest.json');
    const hasChartDirectory = entries.some(entry => entry.isDirectory() && entry.name.toLowerCase() === 'chart');
    if (hasManifest || hasChartDirectory) {
      const files = walkSongFiles(current);
      if (files.some(file => /\.c2s$/i.test(file.relativePath))) directories.push({ directory: path.relative(session.path, current).split(path.sep).join('/'), files });
      return;
    }
    for (const entry of entries) if (entry.isDirectory() && !entry.isSymbolicLink()) visit(path.join(current, entry.name));
  };
  visit(session.path);
  return directories;
}

function createZipFromFolder(sourceRoot, outputPath) {
  const files = walkSongFiles(sourceRoot);
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  let totalSize = 0;
  for (const file of files) {
    const name = Buffer.from(file.relativePath, 'utf8');
    const input = fs.readFileSync(file.absolutePath);
    totalSize += input.length;
    if (totalSize > config.maxTransferBytes) throw new Error('单首歌曲数据包超过服务端大小限制。');
    const compressed = zlib.deflateRawSync(input);
    const method = compressed.length < input.length ? 8 : 0;
    const payload = method === 8 ? compressed : input;
    const crc = crc32(input);
    const local = Buffer.alloc(30 + name.length + payload.length);
    local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x800, 6);
    local.writeUInt16LE(method, 8); local.writeUInt32LE(crc, 14); local.writeUInt32LE(payload.length, 18);
    local.writeUInt32LE(input.length, 22); local.writeUInt16LE(name.length, 26); name.copy(local, 30); payload.copy(local, 30 + name.length);
    localParts.push(local);
    const central = Buffer.alloc(46 + name.length);
    central.writeUInt32LE(0x02014b50, 0); central.writeUInt16LE(20, 4); central.writeUInt16LE(20, 6); central.writeUInt16LE(0x800, 8);
    central.writeUInt16LE(method, 10); central.writeUInt32LE(crc, 16); central.writeUInt32LE(payload.length, 20); central.writeUInt32LE(input.length, 24);
    central.writeUInt16LE(name.length, 28); central.writeUInt32LE(offset, 42); name.copy(central, 46); centralParts.push(central);
    offset += local.length;
  }
  const centralOffset = offset;
  const centralDirectory = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralDirectory.length, 12); end.writeUInt32LE(centralOffset, 16);
  const temporary = outputPath + '.tmp';
  fs.writeFileSync(temporary, Buffer.concat([...localParts, centralDirectory, end]), { mode: 0o600 });
  fs.renameSync(temporary, outputPath);
  return fs.statSync(outputPath).size;
}

function normalizeLibrarySongs(manifest, packagePath, packageHash, packageSize) {
  const input = manifest && typeof manifest === 'object' ? manifest : {};
  const songs = Array.isArray(input.songs) ? input.songs : [];
  if (!songs.length || songs.length > 10000) throw new Error('数据包需要包含 1 至 10000 首歌曲的 songs 数组。');
  const entries = readZipDirectory(packagePath);
  const byName = new Map(entries.map(entry => [entry.name.replace(/^\.\//, ''), entry]));
  const result = [];
  for (const song of songs) {
    if (!song || typeof song !== 'object') continue;
    const songId = cleanText(song.songId || song.id, 128);
    if (!songId) continue;
    const charts = Array.isArray(song.charts) ? song.charts : [];
    const normalizedCharts = [];
    for (const chart of charts) {
      if (!chart || typeof chart !== 'object') continue;
      const chartPath = cleanText(chart.chartPath || chart.path, 256).replace(/^\.\//, '');
      const difficulty = cleanText(chart.difficulty, 32);
      if (!chartPath || !difficulty || chartPath.includes('..') || chartPath.includes('\\')) continue;
      const zipEntry = byName.get(chartPath);
      if (!zipEntry || zipEntry.name.endsWith('/')) continue;
      const bytes = readZipEntry(packagePath, zipEntry);
      const chartHash = validHash(chart.chartHash) && chart.chartHash
        ? String(chart.chartHash).toLowerCase() : crypto.createHash('sha256').update(bytes).digest('hex');
      normalizedCharts.push({ difficulty, level: cleanText(chart.level, 16), designer: cleanText(chart.designer, 96), chartPath, chartHash });
    }
    if (!normalizedCharts.length) continue;
    const coverPath = cleanText(song.coverPath, 256).replace(/^\.\//, '');
    const coverEntry = coverPath ? byName.get(coverPath) : null;
    const coverBytes = coverEntry ? readZipEntry(packagePath, coverEntry) : null;
    result.push({
      songId, songName: cleanText(song.songName || song.name || songId, 160), artist: cleanText(song.artist, 160),
      bpm: cleanText(song.bpm, 24), durationText: cleanText(song.durationText, 16),
      coverPath: coverEntry ? coverPath : '', coverHash: coverBytes ? crypto.createHash('sha256').update(coverBytes).digest('hex') : '',
      coverSize: coverBytes ? coverBytes.length : 0, charts: normalizedCharts,
      packageHash, packageSize
    });
  }
  if (!result.length) throw new Error('数据包中没有可用的歌曲或谱面。');
  return result;
}

function loadSongLibraryIndex() {
  const saved = readJsonFile(SONG_LIBRARY_INDEX_PATH, {});
  const packages = Array.isArray(saved.packages) ? saved.packages.filter(item => {
    if (!item) return false;
    if (item.sourceType === 'folder') return pathIsInside(SONG_LIBRARY_STAGING_DIR, item.sourceRoot) && fs.existsSync(item.sourceRoot) &&
      pathIsInside(item.sourceRoot, path.join(item.sourceRoot, item.songDirectory || ''));
    return typeof item.path === 'string' && fs.existsSync(item.path);
  }) : [];
  return { version: 1, packages };
}

const songLibrary = loadSongLibraryIndex();

function loadSongLibrarySessions() {
  const saved = readJsonFile(SONG_LIBRARY_SESSIONS_PATH, []);
  if (!Array.isArray(saved)) return [];
  return saved.filter(item => item && typeof item.id === 'string' && pathIsInside(SONG_LIBRARY_STAGING_DIR, item.path) && fs.existsSync(item.path));
}

const songLibrarySessions = loadSongLibrarySessions();

function persistSongLibrary() { writeJsonFile(SONG_LIBRARY_INDEX_PATH, songLibrary); }
function persistSongLibrarySessions() { writeJsonFile(SONG_LIBRARY_SESSIONS_PATH, songLibrarySessions); }

function songLibrarySessionView(session) {
  return {
    id: session.id,
    path: session.path,
    status: session.status || 'awaiting_files',
    createdAt: session.createdAt,
    scannedAt: session.scannedAt || null,
    songCount: session.songCount || 0,
    chartCount: session.chartCount || 0,
    errors: Array.isArray(session.errors) ? session.errors.slice(0, 200) : []
  };
}

function createSongLibrarySession() {
  const id = `import-${Date.now().toString(36)}-${randomHex(4)}`;
  const sessionPath = path.join(SONG_LIBRARY_STAGING_DIR, id);
  fs.mkdirSync(sessionPath, { recursive: true, mode: 0o700 });
  const session = { id, path: sessionPath, status: 'awaiting_files', createdAt: isoTime(), songCount: 0, chartCount: 0, errors: [] };
  songLibrarySessions.push(session);
  persistSongLibrarySessions();
  audit('songLibraryImportFolderCreated', { sessionId: id });
  return session;
}

function ensureFolderSongPackage(pack) {
  if (pack.sourceType !== 'folder') return pack;
  const sourceRoot = path.resolve(pack.sourceRoot || '');
  const sourceSong = path.resolve(sourceRoot, pack.songDirectory || '');
  if (!pathIsInside(SONG_LIBRARY_STAGING_DIR, sourceRoot) || !pathIsInside(sourceRoot, sourceSong) || !fs.existsSync(sourceSong))
    throw new Error('歌曲导入目录不存在或路径无效。');
  let generatedPath = pack.path && pathIsInside(SONG_LIBRARY_GENERATED_DIR, pack.path) && fs.existsSync(pack.path)
    ? pack.path : path.join(SONG_LIBRARY_GENERATED_DIR, `${pack.packageHash}.zip`);
  if (!fs.existsSync(generatedPath)) createZipFromFolder(sourceSong, generatedPath);
  const actualHash = fileHash(generatedPath);
  const finalPath = path.join(SONG_LIBRARY_GENERATED_DIR, `${actualHash}.zip`);
  if (path.resolve(generatedPath) !== path.resolve(finalPath)) {
    if (fs.existsSync(finalPath)) fs.unlinkSync(generatedPath);
    else fs.renameSync(generatedPath, finalPath);
  }
  pack.packageHash = actualHash;
  pack.path = finalPath;
  pack.packageSize = fs.statSync(finalPath).size;
  return pack;
}

function scanSongLibrarySession(sessionId) {
  const session = songLibrarySessions.find(item => item.id === sessionId);
  if (!session) return { error: { code: 'IMPORT_SESSION_NOT_FOUND', message: '导入文件夹不存在。' } };
  try {
    const directories = collectFolderSongs(session);
    const errors = [];
    const packages = [];
    for (const item of directories) {
      try { packages.push(normalizeFolderSong(session, item.directory, item.files)); }
      catch (error) { errors.push({ directory: item.directory, message: error.message }); }
    }
    if (!packages.length) {
      session.status = 'failed'; session.errors = errors.length ? errors : [{ directory: '', message: '没有找到包含 .c2s 谱面的歌曲目录。' }];
      session.scannedAt = isoTime(); session.songCount = 0; session.chartCount = 0; persistSongLibrarySessions();
      return { error: { code: 'NO_SONGS_FOUND', message: '没有找到可用歌曲目录。', session: songLibrarySessionView(session) } };
    }
    const oldPackages = songLibrary.packages.filter(pack => pack.sourceSessionId === session.id);
    if (oldPackages.some(pack => Array.from(rooms.values()).some(room => room.song?.packageHash === pack.packageHash)))
      return { error: { code: 'PACKAGE_IN_USE', message: '该导入目录中的歌曲正在被房间使用，请先结束房间。' } };
    for (const old of oldPackages) {
      if (old.path && pathIsInside(SONG_LIBRARY_GENERATED_DIR, old.path)) try { fs.unlinkSync(old.path); } catch (_) {}
    }
    songLibrary.packages = songLibrary.packages.filter(pack => pack.sourceSessionId !== session.id);
    for (const pack of packages) { pack.sourceSessionId = session.id; songLibrary.packages.push(pack); }
    session.status = errors.length ? 'completed_with_errors' : 'completed';
    session.errors = errors.slice(0, 200);
    session.scannedAt = isoTime();
    session.songCount = packages.reduce((sum, pack) => sum + pack.songs.length, 0);
    session.chartCount = packages.reduce((sum, pack) => sum + pack.songs.reduce((inner, song) => inner + song.charts.length, 0), 0);
    persistSongLibrarySessions();
    persistSongLibrary();
    audit('songLibraryFolderScanned', { sessionId, songCount: session.songCount, chartCount: session.chartCount, errorCount: errors.length });
    return { ok: true, session: songLibrarySessionView(session), library: songLibraryView() };
  } catch (error) {
    session.status = 'failed'; session.errors = [{ directory: '', message: error.message }]; session.scannedAt = isoTime();
    persistSongLibrarySessions();
    return { error: { code: 'IMPORT_SCAN_FAILED', message: error.message, session: songLibrarySessionView(session) } };
  }
}

function librarySongViews() {
  return songLibrary.packages.flatMap(pack => (pack.songs || []).map(song => ({
    ...song, packageHash: pack.packageHash, packageSize: pack.packageSize, packageName: pack.fileName,
    importedAt: pack.importedAt
  })));
}

function persistentRoomRecord(room) {
  return {
    id: room.id,
    name: room.name,
    clientVersion: room.members && room.members.size > 0 ? room.clientVersion || '' : '',
    listed: room.listed !== false,
    persistent: true,
    mode: room.mode,
    maxPlayers: room.maxPlayers,
    selectionMode: room.persistent === true ? '' : room.selectionMode,
    roomType: room.persistent === true ? 'persistent' : 'personal',
    librarySelection: normalizeLibrarySelection(room.librarySelection),
    mods: room.mods,
    password: room.password,
    ownerPlayerId: room.ownerPlayerId || '',
    state: 'lobby',
    createdAt: room.createdAt || now(),
    updatedAt: room.updatedAt || now()
  };
}

function persistPersistentRooms() {
  const values = Array.from(rooms.values()).filter(room => room.persistent === true).map(persistentRoomRecord);
  writeJsonFile(PERSISTENT_ROOMS_PATH, values);
}

function loadPersistentRooms() {
  const saved = readJsonFile(PERSISTENT_ROOMS_PATH, []);
  if (!Array.isArray(saved)) return;
  for (const value of saved) {
    if (!value || !validRoomId(value.id) || rooms.has(value.id)) continue;
    const mode = ROOM_MODES.has(value.mode) ? value.mode : 'casual';
    const maxPlayers = normalizeMaxPlayers(value.maxPlayers) && Number(value.maxPlayers) <= Math.min(PERSISTENT_ROOM_MAX_PLAYERS, config.maxPlayersPerRoom)
      ? Number(value.maxPlayers) : Math.min(PERSISTENT_ROOM_MAX_PLAYERS, config.maxPlayersPerRoom);
    const selectionMode = normalizeSelectionMode(value.selectionMode) || 'host';
    const mods = normalizeMods(value.mods) || normalizeMods({});
    const room = {
      id: value.id,
      name: normalizeRoomName(value.name) || '常驻房间',
      // Members are not persisted, so a restored empty room must accept the
      // first client version that joins after a server restart.
      clientVersion: '',
      listed: value.listed !== false,
      persistent: true,
      mode,
      maxPlayers,
      selectionMode,
      mods,
      librarySelection: normalizeLibrarySelection(value.librarySelection),
      password: value.password && typeof value.password === 'object' ? value.password : null,
      state: 'lobby',
      ownerPlayerId: typeof value.ownerPlayerId === 'string' ? value.ownerPlayerId : '',
      hostPlayerId: '',
      members: new Map(),
      kickedGameIds: new Map(),
      song: null,
      transfer: null,
      roundId: null,
      startAt: 0,
      createdAt: Number(value.createdAt) || now(),
      updatedAt: Number(value.updatedAt) || now(),
      songChangeVoteRequiredRatio: config.songChangeVoteRequiredRatio,
      songChangeVoteActive: false,
      songChangeVotes: new Set()
    };
    rooms.set(room.id, room);
    // Re-select an initial server-side song when a persisted room is loaded.
    // The package metadata is intentionally rebuilt from the current library.
    selectLibrarySongForRoom(room);
  }
}
loadPersistentRooms();
// Keep Bot administrators in operational state. Credential form saves and
// Bot hot reloads must never replace this list with stale browser data.
config.qqBot.adminOpenIds = Array.from(new Set([
  ...serverState.qqBotAdminOpenIds,
  ...config.qqBot.adminOpenIds
])).slice(0, 200);
config.qqBot.adminQqIds = Array.from(new Set([
  ...serverState.qqBotAdminQqIds,
  ...config.qqBot.adminQqIds
])).slice(0, 200);
serverState.qqBotAdminOpenIds = [...config.qqBot.adminOpenIds];
serverState.qqBotAdminQqIds = [...config.qqBot.adminQqIds];
if (!serverState.groups.default) {
  serverState.groups.default = { ...DEFAULT_GROUP, createdAt: isoTime(), updatedAt: isoTime() };
  persistServerState();
}
const activeGameIds = new Map();
// The administrator token is intentionally ephemeral. start-server.bat sets
// it before launching Node so it can display the value; direct Node starts
// receive a fresh token here as well.
const adminToken = process.env.CHUNITHM_ADMIN_TOKEN || crypto.randomBytes(32).toString('hex');
const adminSessions = new Map();
const qqAdminBindingCodes = new Map();
const discordAdminBindingCodes = new Map();
const qqRecentLoginSnapshots = new Map();
let persistQqBotConfigTimer = null;

function publicRoomViewsForBot() {
  return publicRooms('', '', { idleOnly: false, notFullOnly: false, unencryptedOnly: false, mode: '' });
}

const qqBot = new QQBot({
  getConfig: () => config.qqBot,
  getPublicRooms: publicRoomViewsForBot,
  getAdminOverview: adminOverview,
  getRecentLogins: createRecentLoginSnapshot,
  consumeGroupJoinCode,
  createGroupJoinCodes,
  listGroupJoinCodes: adminJoinCodeViews,
  setGroupJoinCodeStatus,
  audit,
  recordChat: entry => {
    serverState.qqChat.push({ at: isoTime(), ...entry });
    if (serverState.qqChat.length > 500) serverState.qqChat.splice(0, serverState.qqChat.length - 500);
    persistServerState();
  },
  consumeBindingCode: (code, openId, groupOpenId, platform = 'official') => {
    // QQ 号 Bot 管理员只能由网页后台明确录入 QQ 号，避免群聊中的
    // 一次性绑定码被转发后扩大管理员权限。
    if (platform === 'onebot') return false;
    const normalized = String(code || '').trim().toUpperCase();
    const binding = qqAdminBindingCodes.get(normalized);
    if (!binding || binding.expiresAt <= now() || binding.platform !== platform) return false;
    qqAdminBindingCodes.delete(normalized);
    const ids = platform === 'onebot' ? config.qqBot.adminQqIds : config.qqBot.adminOpenIds;
    if (!ids.includes(openId)) {
      ids.push(openId);
      if (platform === 'onebot') serverState.qqBotAdminQqIds = [...ids];
      else serverState.qqBotAdminOpenIds = [...ids];
      persistServerState();
      saveQqBotConfig(config.qqBot);
    }
    audit('qqBotAdminBound', { platform, userId: openId, groupId: groupOpenId || '' });
    return true;
  },
  log: message => console.log(message)
});

const discordBot = new DiscordBot({
  getConfig: () => config.discordBot,
  getPublicRooms: publicRoomViewsForBot,
  normalizeCommand: value => qqBot.normalizeCommand(value),
  executeCommand: (command, args, admin, context) => qqBot.command(command, args, admin, context),
  consumeBindingCode: (code, userId, guildId) => {
    const normalized = String(code || '').trim().toUpperCase();
    const binding = discordAdminBindingCodes.get(normalized);
    if (!binding || binding.expiresAt <= now()) return false;
    discordAdminBindingCodes.delete(normalized);
    const normalizedUserId = String(userId || '').trim();
    if (!/^\d{5,25}$/.test(normalizedUserId)) return false;
    if (!config.discordBot.adminUserIds.includes(normalizedUserId)) {
      config.discordBot.adminUserIds.push(normalizedUserId);
      saveDiscordBotConfig(config.discordBot);
    }
    audit('discordBotAdminBound', { userId: normalizedUserId, guildId: String(guildId || '').slice(0, 32) });
    return true;
  },
  audit,
  log: message => console.log(message)
});

function saveQqBotConfig(value) {
  config.qqBot = normalizeQqBotConfig(value);
  const configPath = path.join(__dirname, 'config.json');
  const disk = readJsonFile(configPath, {});
  disk.qqBot = { ...config.qqBot, appSecret: encryptQqSecret(config.qqBot.appSecret), oneBotToken: encryptQqSecret(config.qqBot.oneBotToken) };
  writeJsonFile(configPath, disk);
}

function updateQqBotConfig(value) {
  const current = config.qqBot;
  const input = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const next = normalizeQqBotConfig({ ...current, ...input });
  // Secret fields are write-only from the web UI: an empty submitted value
  // keeps the current secret, while an explicit value replaces it.
  if (!input.appSecret) next.appSecret = current.appSecret;
  if (!input.oneBotToken) next.oneBotToken = current.oneBotToken;
  next.adminOpenIds = [...current.adminOpenIds];
  if (!Array.isArray(input.adminQqIds)) next.adminQqIds = [...current.adminQqIds];
  next.sourceAllowlist = [...current.sourceAllowlist];
  saveQqBotConfig(next);
  return next;
}

function saveDiscordBotConfig(value) {
  config.discordBot = normalizeDiscordBotConfig(value);
  const configPath = path.join(__dirname, 'config.json');
  const disk = readJsonFile(configPath, {});
  disk.discordBot = { ...config.discordBot, token: encryptQqSecret(config.discordBot.token) };
  writeJsonFile(configPath, disk);
}

function updateDiscordBotConfig(value) {
  const current = config.discordBot;
  const input = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const next = normalizeDiscordBotConfig({ ...current, ...input });
  if (!input.token) next.token = current.token;
  saveDiscordBotConfig(next);
  return next;
}

function readJsonFile(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (_) {
    return fallback;
  }
}

function writeJsonFile(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporary = filePath + '.tmp';
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  try {
    fs.renameSync(temporary, filePath);
  } catch (_) {
    fs.writeFileSync(filePath, JSON.stringify(value, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
    try { fs.unlinkSync(temporary); } catch (_) { /* best effort */ }
  }
}

function loadSecurity() {
  const saved = readJsonFile(SECURITY_PATH, {});
  const value = {
    identitySecret: typeof saved.identitySecret === 'string' && saved.identitySecret.length >= 32
      ? saved.identitySecret : crypto.randomBytes(32).toString('hex'),
    adminToken: typeof saved.adminToken === 'string' && saved.adminToken.length >= 32
      ? saved.adminToken : crypto.randomBytes(32).toString('hex'),
    adminPassword: saved.adminPassword
      && typeof saved.adminPassword.salt === 'string'
      && typeof saved.adminPassword.digest === 'string'
      ? { salt: saved.adminPassword.salt, digest: saved.adminPassword.digest }
      : null
  };
  writeJsonFile(SECURITY_PATH, value);
  return value;
}

function decryptQqSecret(value) {
  if (typeof value !== 'string' || !value) return '';
  if (!value.startsWith('enc:v1:')) return value;
  try {
    const encoded = Buffer.from(value.slice('enc:v1:'.length), 'base64url');
    if (encoded.length < 12 + 16 + 1) return '';
    const iv = encoded.subarray(0, 12);
    const tag = encoded.subarray(12, 28);
    const ciphertext = encoded.subarray(28);
    const decipher = crypto.createDecipheriv('aes-256-gcm', Buffer.from(security.identitySecret, 'hex'), iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
  } catch (_) {
    return '';
  }
}

function encryptQqSecret(value) {
  if (typeof value !== 'string' || !value) return '';
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(security.identitySecret, 'hex'), iv);
  const ciphertext = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return `enc:v1:${Buffer.concat([iv, cipher.getAuthTag(), ciphertext]).toString('base64url')}`;
}

function loadServerState() {
  const saved = readJsonFile(SERVER_STATE_PATH, {});
  return {
    schemaVersion: 2,
    devices: saved.devices && typeof saved.devices === 'object' ? saved.devices : {},
    blockedGameIds: saved.blockedGameIds && typeof saved.blockedGameIds === 'object' ? saved.blockedGameIds : {},
    groups: saved.groups && typeof saved.groups === 'object' ? saved.groups : {},
    joinCodes: saved.joinCodes && typeof saved.joinCodes === 'object'
      ? Object.fromEntries(Object.entries(saved.joinCodes).map(([id, value]) => [id, normalizeJoinCodeRecord(value, id)]).filter(([, value]) => value))
      : {},
    audit: Array.isArray(saved.audit) ? saved.audit.slice(-500) : [],
    qqChat: Array.isArray(saved.qqChat) ? saved.qqChat.slice(-500) : [],
    joinCodeUses: Array.isArray(saved.joinCodeUses) ? saved.joinCodeUses.slice(-1000) : [],
    qqBotAdminOpenIds: Array.isArray(saved.qqBotAdminOpenIds)
      ? saved.qqBotAdminOpenIds.filter(item => typeof item === 'string' && item.trim()).map(item => item.trim()).slice(0, 200)
      : [],
    qqBotAdminQqIds: Array.isArray(saved.qqBotAdminQqIds)
      ? saved.qqBotAdminQqIds.filter(item => typeof item === 'string' && item.trim()).map(item => item.trim()).slice(0, 200)
      : []
  };
}

function normalizePlayerNameHistory(record) {
  const input = Array.isArray(record.playerNameHistory) ? record.playerNameHistory : [];
  const history = [];
  for (const entry of input) {
    if (!entry || !validName(entry.name) || history.some(item => item.name === entry.name)) continue;
    history.push({
      name: entry.name,
      firstUsedAt: typeof entry.firstUsedAt === 'string' ? entry.firstUsedAt : null,
      lastUsedAt: typeof entry.lastUsedAt === 'string' ? entry.lastUsedAt : null,
      useCount: Math.max(1, Number(entry.useCount) || 1)
    });
    if (history.length >= MAX_PLAYER_NAME_HISTORY) break;
  }
  return history;
}

function storedLastPlayerName(record) {
  if (record && validName(record.lastPlayerName)) return record.lastPlayerName;
  const history = normalizePlayerNameHistory(record || {});
  return history[0]?.name || '';
}

function rememberPlayerName(record, name) {
  if (!record || !validName(name)) return { changed: false, previous: '' };
  const timestamp = isoTime();
  const history = normalizePlayerNameHistory(record);
  const existing = history.find(entry => entry.name === name);
  const previous = storedLastPlayerName(record);
  if (existing) {
    existing.lastUsedAt = timestamp;
    existing.useCount += 1;
    history.splice(history.indexOf(existing), 1);
    history.unshift(existing);
  } else {
    history.unshift({ name, firstUsedAt: timestamp, lastUsedAt: timestamp, useCount: 1 });
  }
  record.playerNameHistory = history.slice(0, MAX_PLAYER_NAME_HISTORY);
  record.lastPlayerName = name;
  return { changed: previous !== name, previous };
}

function persistServerState() {
  writeJsonFile(SERVER_STATE_PATH, serverState);
}

function audit(action, details = {}) {
  serverState.audit.push({ at: isoTime(), action, ...details });
  if (serverState.audit.length > 500) serverState.audit.splice(0, serverState.audit.length - 500);
  persistServerState();
}

function now() {
  return Date.now();
}

function isoTime(value = now()) {
  return new Date(value).toISOString();
}

function randomHex(bytes) {
  return crypto.randomBytes(bytes).toString('hex');
}

function validGameId(value) {
  return typeof value === 'string' && /^GM[A-Z0-9]{10}$/.test(value);
}

function validDeviceId(value) {
  return typeof value === 'string' && value.length >= 8 && value.length <= 256 &&
    !/[\u0000-\u001f\u007f]/u.test(value);
}

function deviceFingerprint(deviceId) {
  return crypto.createHmac('sha256', Buffer.from(security.identitySecret, 'hex'))
    .update(deviceId, 'utf8').digest('hex');
}

function randomGameId() {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  for (let attempt = 0; attempt < 1000; attempt += 1) {
    let value = 'GM';
    for (let index = 0; index < 10; index += 1) {
      value += alphabet[crypto.randomInt(0, alphabet.length)];
    }
    const known = Object.values(serverState.devices).some(device => device.gameId === value);
    if (!known && !activeGameIds.has(value)) return value;
  }
  return null;
}

function getDeviceRecord(gameId) {
  return Object.values(serverState.devices).find(device => device.gameId === gameId) || null;
}

function currentQuotaDay() {
  return new Date().toISOString().slice(0, 10);
}

function normalizeLimit(value, fallback = 0) {
  const number = Number(value);
  return Number.isInteger(number) && number >= -1 && number <= 10000 ? number : fallback;
}

function normalizeGroupId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{1,32}$/.test(value) ? value : null;
}

function normalizeGroupName(value) {
  if (typeof value !== 'string') return null;
  const name = value.trim();
  const length = Array.from(name).length;
  return length >= 1 && length <= 24 && !/[\u0000-\u001f\u007f]/u.test(name) ? name : null;
}

function getGroup(record) {
  const groupId = record && normalizeGroupId(record.groupId) && serverState.groups[record.groupId]
    ? record.groupId : 'default';
  if (record && record.groupId !== groupId) record.groupId = groupId;
  const saved = serverState.groups[groupId] || DEFAULT_GROUP;
  return {
    id: groupId,
    name: normalizeGroupName(saved.name) || DEFAULT_GROUP.name,
    createRoomLimit: normalizeLimit(saved.createRoomLimit, DEFAULT_GROUP.createRoomLimit),
    joinRoomLimit: normalizeLimit(saved.joinRoomLimit, DEFAULT_GROUP.joinRoomLimit)
  };
}

function getQuotaRecord(record) {
  const day = currentQuotaDay();
  if (record.quotaDay !== day) {
    record.quotaDay = day;
    record.createdToday = 0;
    record.joinedToday = 0;
  }
  record.createdToday = Math.max(0, Number(record.createdToday) || 0);
  record.joinedToday = Math.max(0, Number(record.joinedToday) || 0);
  return record;
}

function remainingQuota(limit, used) {
  return limit < 0 ? -1 : Math.max(0, limit - used);
}

function quotaStatus(gameId) {
  const record = getDeviceRecord(gameId);
  if (!record) return null;
  getQuotaRecord(record);
  const group = getGroup(record);
  return {
    day: record.quotaDay,
    groupId: group.id,
    groupName: group.name,
    createRoomLimit: group.createRoomLimit,
    createRoomUsed: record.createdToday,
    createRoomRemaining: remainingQuota(group.createRoomLimit, record.createdToday),
    joinRoomLimit: group.joinRoomLimit,
    joinRoomUsed: record.joinedToday,
    joinRoomRemaining: remainingQuota(group.joinRoomLimit, record.joinedToday)
  };
}

function consumeRoomQuota(client, action) {
  const record = getDeviceRecord(client.gameId);
  if (!record) return false;
  const quota = quotaStatus(client.gameId);
  const isCreate = action === 'create';
  const limit = isCreate ? quota.createRoomLimit : quota.joinRoomLimit;
  const used = isCreate ? quota.createRoomUsed : quota.joinRoomUsed;
  if (limit >= 0 && used >= limit) {
    const actionName = isCreate ? '创建房间' : '加入房间';
    sendError(client, isCreate ? 'DAILY_CREATE_LIMIT_REACHED' : 'DAILY_JOIN_LIMIT_REACHED',
      `今日${actionName}次数已用完。`, { quota });
    return false;
  }
  if (isCreate) record.createdToday += 1;
  else record.joinedToday += 1;
  persistServerState();
  send(client, { type: 'quotaUpdated', quota: quotaStatus(client.gameId), serverTime: now() });
  return true;
}

function adminGroupViews() {
  return Object.values(serverState.groups).map(saved => {
    const group = {
      id: saved.id,
      name: normalizeGroupName(saved.name) || saved.id,
      createRoomLimit: normalizeLimit(saved.createRoomLimit, DEFAULT_GROUP.createRoomLimit),
      joinRoomLimit: normalizeLimit(saved.joinRoomLimit, DEFAULT_GROUP.joinRoomLimit),
      createdAt: saved.createdAt || null,
      updatedAt: saved.updatedAt || null,
      deviceCount: Object.values(serverState.devices).filter(record => getGroup(record).id === saved.id).length
    };
    return group;
  }).sort((a, b) => a.id.localeCompare(b.id));
}

function saveGroup(id, name, createRoomLimit, joinRoomLimit) {
  const groupId = normalizeGroupId(id);
  const groupName = normalizeGroupName(name);
  const createLimit = normalizeLimit(createRoomLimit, NaN);
  const joinLimit = normalizeLimit(joinRoomLimit, NaN);
  if (!groupId) return { code: 'INVALID_GROUP_ID', message: 'Group ID must use 1 to 32 letters, digits, _ or -.' };
  if (!groupName) return { code: 'INVALID_GROUP_NAME', message: 'Group name must contain 1 to 24 characters.' };
  if (!Number.isInteger(createLimit) || !Number.isInteger(joinLimit)) {
    return { code: 'INVALID_GROUP_LIMIT', message: 'Daily room limits must be integers from -1 to 10000. Use -1 for unlimited.' };
  }
  const previous = serverState.groups[groupId];
  const timestamp = isoTime();
  serverState.groups[groupId] = {
    id: groupId,
    name: groupName,
    createRoomLimit: createLimit,
    joinRoomLimit: joinLimit,
    createdAt: previous?.createdAt || timestamp,
    updatedAt: timestamp
  };
  persistServerState();
  for (const client of clients) {
    if (client.hello && getDeviceRecord(client.gameId) && getGroup(getDeviceRecord(client.gameId)).id === groupId)
      send(client, { type: 'quotaUpdated', quota: quotaStatus(client.gameId), serverTime: now() });
  }
  audit(previous ? 'groupUpdated' : 'groupCreated', { groupId, createRoomLimit: createLimit, joinRoomLimit: joinLimit });
  return null;
}

function assignDeviceGroup(gameId, groupId) {
  if (!validGameId(gameId)) return { code: 'INVALID_GAME_ID', message: 'Game ID format is invalid.' };
  if (!normalizeGroupId(groupId) || !serverState.groups[groupId]) return { code: 'GROUP_NOT_FOUND', message: 'Group not found.' };
  const record = getDeviceRecord(gameId);
  if (!record) return { code: 'DEVICE_NOT_FOUND', message: 'Device record not found.' };
  record.groupId = groupId;
  getQuotaRecord(record);
  persistServerState();
  const active = activeGameIds.get(gameId);
  if (active && !active.closed) send(active, { type: 'quotaUpdated', quota: quotaStatus(gameId), serverTime: now() });
  audit('deviceGroupAssigned', { gameId, groupId });
  return null;
}

function hashGroupJoinCode(code) {
  return crypto.createHash('sha256').update(String(code || '').trim().toUpperCase(), 'utf8').digest('hex');
}

function normalizeJoinCodeId(value) {
  return typeof value === 'string' && /^[A-Z0-9_-]{6,40}$/.test(value) ? value : null;
}

function normalizeJoinCodeRecord(saved, fallbackId) {
  if (!saved || typeof saved !== 'object') return null;
  const id = normalizeJoinCodeId(saved.id || fallbackId);
  const groupId = normalizeGroupId(saved.groupId);
  const hash = typeof saved.hash === 'string' && /^[a-f0-9]{64}$/i.test(saved.hash) ? saved.hash.toLowerCase() : null;
  if (!id || !groupId || !hash) return null;
  const uses = Number(saved.maxUses);
  const used = Math.max(0, Math.floor(Number(saved.usedCount) || 0));
  return {
    id,
    groupId,
    hash,
    maxUses: Number.isInteger(uses) && (uses === -1 || (uses >= 1 && uses <= 100000)) ? uses : 1,
    usedCount: used,
    enabled: saved.enabled !== false,
    createdAt: typeof saved.createdAt === 'string' ? saved.createdAt : isoTime(),
    createdBy: typeof saved.createdBy === 'string' ? saved.createdBy.slice(0, 128) : 'admin',
    lastUsedAt: typeof saved.lastUsedAt === 'string' ? saved.lastUsedAt : null
  };
}

function adminJoinCodeViews() {
  return Object.values(serverState.joinCodes || {}).map(record => ({
    id: record.id,
    groupId: record.groupId,
    groupName: serverState.groups[record.groupId]?.name || record.groupId,
    enabled: record.enabled,
    maxUses: record.maxUses,
    usedCount: record.usedCount,
    remainingUses: record.maxUses < 0 ? -1 : Math.max(0, record.maxUses - record.usedCount),
    createdAt: record.createdAt,
    createdBy: record.createdBy,
    lastUsedAt: record.lastUsedAt
  })).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
}

function createGroupJoinCodes(groupId, count = 1, maxUses = 1, createdBy = 'admin') {
  const normalizedGroupId = normalizeGroupId(groupId);
  if (!normalizedGroupId || !serverState.groups[normalizedGroupId]) {
    return { error: { code: 'GROUP_NOT_FOUND', message: 'Group not found.' } };
  }
  const amount = Number(count);
  const uses = Number(maxUses);
  if (!Number.isInteger(amount) || amount < 1 || amount > 500) {
    return { error: { code: 'INVALID_JOIN_CODE_COUNT', message: 'Join code count must be 1 to 500.' } };
  }
  if (!Number.isInteger(uses) || (uses !== -1 && (uses < 1 || uses > 100000))) {
    return { error: { code: 'INVALID_JOIN_CODE_USES', message: 'Join code uses must be -1 or 1 to 100000.' } };
  }
  const codes = [];
  const records = {};
  const prefix = normalizedGroupId.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) || 'GROUP';
  for (let index = 0; index < amount; index += 1) {
    let plaintext = '';
    let hash = '';
    let id = '';
    for (let attempt = 0; attempt < 100; attempt += 1) {
      const token = crypto.randomBytes(8).toString('hex').toUpperCase();
      plaintext = `${prefix}-${token.slice(0, 4)}-${token.slice(4, 8)}`;
      hash = hashGroupJoinCode(plaintext);
      id = `JC-${crypto.randomBytes(6).toString('hex').toUpperCase()}`;
      if (!Object.values(serverState.joinCodes).some(item => item.hash === hash)) break;
    }
    const record = { id, groupId: normalizedGroupId, hash, maxUses: uses, usedCount: 0, enabled: true, createdAt: isoTime(), createdBy: String(createdBy || 'admin').slice(0, 128), lastUsedAt: null };
    serverState.joinCodes[id] = record;
    records[id] = record;
    codes.push(plaintext);
  }
  persistServerState();
  audit('groupJoinCodesCreated', { groupId: normalizedGroupId, count: codes.length, maxUses: uses, createdBy: String(createdBy || 'admin').slice(0, 128) });
  return { codes, records: adminJoinCodeViews().filter(item => records[item.id]), groupId: normalizedGroupId, groupName: serverState.groups[normalizedGroupId].name };
}

function setGroupJoinCodeStatus(codeId, enabled) {
  const id = normalizeJoinCodeId(codeId);
  const record = id ? serverState.joinCodes[id] : null;
  if (!record) return { error: { code: 'JOIN_CODE_NOT_FOUND', message: 'Join code not found.' } };
  record.enabled = enabled !== false;
  persistServerState();
  audit(record.enabled ? 'groupJoinCodeEnabled' : 'groupJoinCodeDisabled', { codeId: id, groupId: record.groupId });
  return { record: adminJoinCodeViews().find(item => item.id === id) };
}

function recentLoginRows() {
  const cutoff = now() - 30 * 60 * 1000;
  return Object.values(serverState.devices)
    .filter(record => Date.parse(record.lastLoginAt || '') >= cutoff)
    .sort((a, b) => Date.parse(b.lastLoginAt || '') - Date.parse(a.lastLoginAt || ''))
    .slice(0, 3)
    .map(record => {
      const active = activeGameIds.get(record.gameId);
      return {
        gameId: record.gameId,
        idSuffix: record.gameId.slice(-4),
        playerName: active && !active.closed ? active.name : storedLastPlayerName(record),
        loginAt: record.lastLoginAt,
        online: Boolean(active && !active.closed),
        groupName: getGroup(record).name,
        groupId: getGroup(record).id
      };
    });
}

function createRecentLoginSnapshot(requesterKey = 'unknown', sourceKey = 'private') {
  const key = `${requesterKey}:${sourceKey}`;
  const snapshot = { id: `RS-${crypto.randomBytes(6).toString('hex').toUpperCase()}`, createdAt: now(), expiresAt: now() + 5 * 60 * 1000, items: recentLoginRows() };
  qqRecentLoginSnapshots.set(key, snapshot);
  for (const [snapshotKey, value] of qqRecentLoginSnapshots) if (value.expiresAt <= now()) qqRecentLoginSnapshots.delete(snapshotKey);
  return snapshot;
}

function consumeGroupJoinCode(code, snapshot, index, qqContext = {}) {
  const normalized = String(code || '').trim().toUpperCase();
  const targetIndex = Number(index);
  if (!snapshot || snapshot.expiresAt <= now()) return { error: '最近登录查询已过期，请先重新发送 /zxdl。' };
  if (!Number.isInteger(targetIndex) || targetIndex < 1 || targetIndex > snapshot.items.length) return { error: '最近登录编号无效，请先发送 /zxdl 查看编号。' };
  const target = snapshot.items[targetIndex - 1];
  const record = serverState.devices && Object.values(serverState.devices).find(item => item.gameId === target.gameId);
  const joinCode = Object.values(serverState.joinCodes || {}).find(item => item.hash === hashGroupJoinCode(normalized));
  if (!joinCode || !joinCode.enabled) return { error: '群组加入码无效或已禁用。' };
  if (joinCode.maxUses >= 0 && joinCode.usedCount >= joinCode.maxUses) return { error: '群组加入码的使用次数已用完。' };
  if (!record || !serverState.groups[joinCode.groupId]) return { error: '目标用户或群组不存在。' };
  const previousGroup = getGroup(record);
  joinCode.usedCount += 1;
  joinCode.lastUsedAt = isoTime();
  record.groupId = joinCode.groupId;
  getQuotaRecord(record);
  persistServerState();
  const active = activeGameIds.get(record.gameId);
  if (active && !active.closed) send(active, { type: 'quotaUpdated', quota: quotaStatus(record.gameId), serverTime: now() });
  const nextGroup = getGroup(record);
  const usage = {
    at: isoTime(),
    codeId: joinCode.id,
    groupId: joinCode.groupId,
    gameId: record.gameId,
    gameIdSuffix: record.gameId.slice(-4),
    playerName: target.playerName,
    qqOpenId: String(qqContext.openId || '').slice(0, 128),
    sourceOpenId: String(qqContext.sourceOpenId || '').slice(0, 128),
    previousGroupId: previousGroup.id
  };
  serverState.joinCodeUses.push(usage);
  if (serverState.joinCodeUses.length > 1000) serverState.joinCodeUses.splice(0, serverState.joinCodeUses.length - 1000);
  audit('groupJoinCodeUsed', usage);
  return { playerName: target.playerName, idSuffix: record.gameId.slice(-4), groupName: nextGroup.name, groupId: nextGroup.id, previousGroupName: previousGroup.name, remainingUses: joinCode.maxUses < 0 ? -1 : Math.max(0, joinCode.maxUses - joinCode.usedCount) };
}

function deleteGroup(groupId) {
  if (groupId === 'default') return { code: 'DEFAULT_GROUP_REQUIRED', message: 'The default group cannot be deleted.' };
  if (!normalizeGroupId(groupId) || !serverState.groups[groupId]) return { code: 'GROUP_NOT_FOUND', message: 'Group not found.' };
  delete serverState.groups[groupId];
  for (const record of Object.values(serverState.devices)) {
    if (record.groupId !== groupId) continue;
    record.groupId = 'default';
    const active = activeGameIds.get(record.gameId);
    if (active && !active.closed) send(active, { type: 'quotaUpdated', quota: quotaStatus(record.gameId), serverTime: now() });
  }
  persistServerState();
  audit('groupDeleted', { groupId });
  return null;
}

function issueGameIdentity(rawDeviceId, client, rawLegacyDeviceId = '') {
  const deviceId = rawDeviceId.trim();
  const fingerprint = deviceFingerprint(deviceId);
  let record = serverState.devices[fingerprint];
  if (!record && validDeviceId(rawLegacyDeviceId)) {
    const legacyFingerprint = deviceFingerprint(rawLegacyDeviceId.trim());
    record = serverState.devices[legacyFingerprint];
    if (record) {
      delete serverState.devices[legacyFingerprint];
      serverState.devices[fingerprint] = record;
      audit('gameIdIdentityMigrated', { gameId: record.gameId });
    }
  }
  if (!record) {
    const gameId = randomGameId();
    if (!gameId) return { error: { code: 'GAME_ID_EXHAUSTED', message: 'Unable to allocate a game ID.' } };
    record = {
      gameId,
      firstSeen: isoTime(),
      lastSeen: isoTime(),
      lastIp: client.ip,
      clientVersion: client.clientVersion || '',
      lastPlayerName: '',
      playerNameHistory: [],
      connectionCount: 0,
      groupId: 'default',
      quotaDay: currentQuotaDay(),
      createdToday: 0,
      joinedToday: 0
    };
    serverState.devices[fingerprint] = record;
    audit('gameIdIssued', { gameId });
  }
  record.lastSeen = isoTime();
  record.lastIp = client.ip;
  record.clientVersion = client.clientVersion || record.clientVersion || '';
  if (!record.groupId || !serverState.groups[record.groupId]) record.groupId = 'default';
  record.connectionCount = Number(record.connectionCount || 0) + 1;
  return { gameId: record.gameId, fingerprint };
}

function randomRoomId() {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const value = crypto.randomInt(0, 1000000).toString().padStart(6, '0');
    if (!reservedRoomIds.has(value) && !rooms.has(value)) return value;
  }
  return null;
}

function randomPersistentRoomId() {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const value = crypto.randomInt(100, 1000).toString();
    if (!reservedRoomIds.has(value) && !rooms.has(value)) return value;
  }
  return null;
}

function codePointLength(value) {
  return Array.from(value).length;
}

function validName(value) {
  if (typeof value !== 'string') return false;
  if (codePointLength(value) < 1 || codePointLength(value) > 6) return false;
  return Array.from(value).every(character => /^[A-Za-z\u4e00-\u9fff]$/u.test(character));
}

function cleanText(value, maxLength) {
  if (typeof value !== 'string') return '';
  return Array.from(value.trim()).slice(0, maxLength).join('');
}

function validRoomId(value) {
  return typeof value === 'string' && /^(?:\d{3}|\d{6})$/.test(value);
}

function validHash(value) {
  return value === undefined || value === null || (typeof value === 'string' && /^[a-f0-9]{64}$/i.test(value));
}

function normalizeMods(value) {
  const input = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  // Accept the historical flickSimpleMode field from older clients, but do not
  // expose it in the normalized room state or use it for gameplay rules.
  const allowedKeys = new Set([...MOD_KEYS, 'musicRate', 'flickSimpleMode']);
  if (Object.keys(input).some(key => !allowedKeys.has(key))) return null;
  const mods = {};
  for (const key of MOD_KEYS) mods[key] = input[key] === true;
  const rate = Number(input.musicRate === undefined ? 1 : input.musicRate);
  const matchingRate = ALLOWED_RATES.find(candidate => Math.abs(candidate - rate) < 0.0001);
  if (matchingRate === undefined) return null;
  mods.musicRate = matchingRate;
  return mods;
}

function isScoringMods(mods) {
  return !mods.autoPlay && !mods.airAreaAuto && !mods.directionalAirAuto &&
    !mods.mineImmunity && !mods.flickAllTap && !mods.fullscreenTouchpad && Math.abs(mods.musicRate - 1) < 0.0001;
}

function validateRoomModeAndMods(mode, mods) {
  if (!ROOM_MODES.has(mode)) return { code: 'INVALID_ROOM_MODE', message: 'Room mode must be casual or normal.' };
  if (!mods) return { code: 'INVALID_MODS', message: 'The MOD payload is invalid.' };
  if (mods.autoPlay) return { code: 'FULL_CHART_AUTO_NOT_ALLOWED', message: 'Full-chart AUTO is not available in multiplayer rooms.' };
  if (mode === 'normal' && !isScoringMods(mods)) {
    return { code: 'MOD_NOT_ALLOWED_IN_NORMAL', message: 'Normal rooms only allow score-counting MODs.' };
  }
  return null;
}

function normalizeRoomName(value) {
  if (typeof value !== 'string') return null;
  const name = value.trim();
  const length = Array.from(name).length;
  if (length < 1 || length > 15 || /[\u0000-\u001f\u007f]/.test(name)) return null;
  return name;
}

function normalizeMaxPlayers(value) {
  const number = Number(value);
  return Number.isInteger(number) && number >= 2 && number <= config.maxPlayersPerRoom ? number : null;
}

function roomMaxPlayers(roomType) {
  return roomType === 'persistent' ? PERSISTENT_ROOM_MAX_PLAYERS : PERSONAL_ROOM_MAX_PLAYERS;
}

function normalizeSelectionMode(value) {
  return SELECTION_MODES.has(value) ? value : null;
}

function normalizeRoomType(value) {
  return ROOM_TYPES.has(value) ? value : 'personal';
}

function hashPassword(password) {
  if (!password) return null;
  const salt = crypto.randomBytes(16);
  const digest = crypto.scryptSync(password, salt, 32);
  return { salt: salt.toString('hex'), digest: digest.toString('hex') };
}

function verifyPassword(password, stored) {
  if (!stored) return true;
  if (typeof password !== 'string' || password.length < 1 || password.length > 64) return false;
  const actual = crypto.scryptSync(password, Buffer.from(stored.salt, 'hex'), 32);
  const expected = Buffer.from(stored.digest, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function isLoopbackIp(ip) {
  const normalized = normalizeIp(ip);
  return normalized === '127.0.0.1' || normalized === '::1' || normalized === '0:0:0:0:0:0:0:1';
}

function isAdminRequestLoopback(request) {
  const directIsLoopback = isLoopbackIp(request.socket.remoteAddress);
  if (!directIsLoopback) return false;
  // Caddy connects to Node over loopback and forwards the real client here.
  // Treat that request as remote unless the original client is also local.
  const forwarded = request.headers['x-forwarded-for'];
  if (typeof forwarded !== 'string' || !forwarded.trim()) return true;
  return isLoopbackIp(forwarded.split(',')[0].trim());
}

function isAdminNetworkAllowed(request) {
  return !config.adminLocalOnly || isAdminRequestLoopback(request);
}

function isAdminAuthorized(request) {
  if (!isAdminNetworkAllowed(request)) return false;
  const header = request.headers.authorization;
  if (typeof header !== 'string' || !header.startsWith('Bearer ')) return false;
  const credential = header.slice('Bearer '.length);
  if (credential === adminToken) return true;
  const expiresAt = adminSessions.get(credential);
  if (!expiresAt) return false;
  if (expiresAt <= now()) { adminSessions.delete(credential); return false; }
  return true;
}

function verifyAdminCredential(credential) {
  if (typeof credential !== 'string' || credential.length < 1 || credential.length > 256) return false;
  if (credential === adminToken) return true;
  return security.adminPassword ? verifyPassword(credential, security.adminPassword) : false;
}

function createAdminSession() {
  const token = crypto.randomBytes(32).toString('base64url');
  const expiresAt = now() + 12 * 60 * 60 * 1000;
  adminSessions.set(token, expiresAt);
  for (const [key, expiry] of adminSessions) if (expiry <= now()) adminSessions.delete(key);
  return { token, expiresAt };
}

function isClientIdleExempt(client) {
  const room = getClientRoom(client);
  return Boolean(room && (room.state === 'loading' || room.state === 'playing'));
}

function idlePolicy() {
  return {
    timeoutMinutes: config.idleClientMinutes,
    warningSeconds: config.idleWarningSeconds,
    exemptRoomStates: ['loading', 'playing'],
    backgroundTimeoutMinutes: config.backgroundTimeoutMinutes
  };
}

async function inspectWssConfiguration(domainInput) {
  const domain = String(domainInput || config.tls.domain || '').trim().toLowerCase();
  const caddyExecutable = path.join(__dirname, 'caddy.exe');
  const caddyfile = path.join(__dirname, 'Caddyfile');
  const keyPath = path.resolve(__dirname, config.tls.keyPath);
  const certPath = path.resolve(__dirname, config.tls.certPath);
  const proxyMode = !config.tls.enabled && config.host === '127.0.0.1' && Boolean(config.tls.domain);
  let dnsResult = { ok: false, addresses: [], message: domain ? '未完成解析' : '尚未填写域名' };
  if (domain && /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(domain)) {
    try {
      const records = await dns.promises.lookup(domain, { all: true });
      dnsResult = { ok: records.length > 0, addresses: [...new Set(records.map(item => item.address))], message: records.length ? '域名解析正常' : '域名没有解析结果' };
    } catch (error) {
      dnsResult = { ok: false, addresses: [], message: `域名解析失败：${error.code || error.message}` };
    }
  }
  const caddyfileText = fs.existsSync(caddyfile) ? fs.readFileSync(caddyfile, 'utf8') : '';
  return {
    checkedAt: isoTime(),
    domain,
    endpoint: domain ? `wss://${domain}/ws` : '',
    mode: proxyMode ? 'caddy' : config.tls.enabled ? 'node-tls' : 'ws',
    dns: dnsResult,
    caddy: {
      executable: fs.existsSync(caddyExecutable),
      config: fs.existsSync(caddyfile),
      domainMatched: Boolean(domain && caddyfileText.toLowerCase().includes(domain)),
      proxyTargetMatched: /127\.0\.0\.1:27960/.test(caddyfileText)
    },
    certificate: {
      required: config.tls.enabled,
      keyExists: fs.existsSync(keyPath),
      certExists: fs.existsSync(certPath)
    },
    backend: { host: config.host, port: config.port, proxyMode },
    ready: Boolean(domain && dnsResult.ok && (proxyMode
      ? fs.existsSync(caddyExecutable) && fs.existsSync(caddyfile) && caddyfileText.toLowerCase().includes(domain)
      : config.tls.enabled && fs.existsSync(keyPath) && fs.existsSync(certPath)))
  };
}

function adminDeviceViews() {
  const current = now();
  const values = Object.values(serverState.devices).map(record => {
    const active = activeGameIds.get(record.gameId);
    const room = active ? getClientRoom(active) : null;
    const online = Boolean(active && !active.closed);
    const lastPlayerName = storedLastPlayerName(record);
    return {
      gameId: record.gameId,
      online,
      // playerName remains the display-compatible field and now falls back to
      // the persisted nickname when the device is offline.
      playerName: online ? active.name : lastPlayerName,
      currentPlayerName: online ? active.name : '',
      lastPlayerName,
      playerNameHistory: normalizePlayerNameHistory(record),
      roomId: active ? active.roomId : null,
      roomName: room ? room.name : null,
      firstSeen: record.firstSeen,
      lastLoginAt: record.lastLoginAt || null,
      lastSeen: record.lastSeen,
      lastIp: record.lastIp || '',
      clientVersion: active ? active.clientVersion : record.clientVersion || '',
      connectionCount: Number(record.connectionCount || 0),
      group: getGroup(record),
      quota: quotaStatus(record.gameId),
      connectedAt: active ? isoTime(active.connectedAt) : null,
      lastActivityAt: online ? isoTime(active.lastActivityAt) : null,
      idleSeconds: online ? Math.max(0, Math.floor((current - active.lastActivityAt) / 1000)) : null,
      idleExempt: online ? isClientIdleExempt(active) : false,
      idleWarningSent: online ? active.idleWarningSent : false,
      blocked: Object.prototype.hasOwnProperty.call(serverState.blockedGameIds, record.gameId),
      blockReason: serverState.blockedGameIds[record.gameId]?.reason || ''
    };
  });
  for (const [gameId, entry] of Object.entries(serverState.blockedGameIds)) {
    if (values.some(value => value.gameId === gameId)) continue;
    values.push({
      gameId,
      online: false,
      playerName: '',
      currentPlayerName: '',
      lastPlayerName: '',
      playerNameHistory: [],
      roomId: null,
      roomName: null,
      firstSeen: null,
      lastLoginAt: null,
      lastSeen: null,
      lastIp: '',
      clientVersion: '',
      connectionCount: 0,
      group: serverState.groups.default ? { ...DEFAULT_GROUP } : null,
      quota: null,
      connectedAt: null,
      lastActivityAt: null,
      idleSeconds: null,
      idleExempt: false,
      idleWarningSent: false,
      blocked: true,
      blockReason: entry.reason || ''
    });
  }
  return values.sort((a, b) => a.gameId.localeCompare(b.gameId));
}

function adminRoomViews() {
  return Array.from(rooms.values()).map(room => ({
    roomId: room.id,
    roomName: room.name,
    persistent: room.persistent === true,
    roomType: room.persistent === true ? 'persistent' : 'personal',
    listed: room.listed,
    mode: room.mode,
    clientVersion: room.clientVersion || '',
    selectionMode: room.persistent === true ? '' : room.selectionMode,
    librarySelection: room.persistent === true ? normalizeLibrarySelection(room.librarySelection) : null,
    modPolicy: room.mode === 'normal' ? 'scoring-only' : 'any',
    maxPlayers: room.maxPlayers,
    memberCount: room.members.size,
    state: room.state,
    hostGameId: room.hostPlayerId,
    hostName: room.members.get(room.hostPlayerId)?.name || 'unknown',
    hasPassword: roomHasPassword(room),
    mods: room.mods,
    song: room.song,
    roundId: room.roundId,
    createdAt: isoTime(room.createdAt),
    updatedAt: isoTime(room.updatedAt),
    members: Array.from(room.members.values()).map(member => ({
      gameId: member.gameId,
      name: member.name,
      clientVersion: member.client.clientVersion || '',
      ready: member.ready,
      online: !member.client.closed,
      connectedAt: isoTime(member.client.connectedAt)
    }))
  })).sort((a, b) => a.roomId.localeCompare(b.roomId));
}

function adminOverview() {
  const devices = adminDeviceViews();
  const roomViews = adminRoomViews();
  return {
    ok: true,
    server: 'chunithm-mobile-multiplayer',
    version: SERVER_VERSION,
    protocol: PROTOCOL_VERSION,
    serverTime: now(),
    deviceCount: devices.length,
    onlineDeviceCount: devices.filter(device => device.online).length,
    blockedDeviceCount: devices.filter(device => device.blocked).length,
    roomCount: roomViews.length,
    idlePolicy: idlePolicy(),
    groups: adminGroupViews(),
    discordBot: adminDiscordBotView(),
    songLibrary: songLibraryView(),
    joinCodes: adminJoinCodeViews(),
    joinCodeUses: serverState.joinCodeUses.slice(-200).reverse(),
    devices,
    rooms: roomViews,
    audit: serverState.audit.slice(-100).reverse()
  };
}

function adminQqBotView() {
  const value = config.qqBot;
  return {
    enabled: value.enabled,
    configured: value.provider === 'napcat' ? Boolean(value.oneBotUrl) : Boolean(value.appId && value.appSecret),
    appId: value.appId,
    apiBase: value.apiBase,
    commandPrefix: value.commandPrefix,
    sourceAllowlist: value.sourceAllowlist,
    adminOpenIds: value.adminOpenIds,
    adminQqIds: value.adminQqIds,
    oneBotUrl: value.oneBotUrl,
    hasOneBotToken: Boolean(value.oneBotToken),
    allowNoPrefixGroup: value.allowNoPrefixGroup,
    oneBotGroupOnly: value.oneBotGroupOnly,
    oneBotGroupAllowlist: value.oneBotGroupAllowlist,
    oneBotPrivateReplies: value.oneBotPrivateReplies,
    recordOneBotImages: value.recordOneBotImages,
    pokeCommand: value.pokeCommand,
    intents: value.intents,
    rateLimitPerMinute: value.rateLimitPerMinute,
    hasAppSecret: Boolean(value.appSecret),
    status: qqBot.status(),
    chatRecords: serverState.qqChat.slice(-200).reverse()
  };
}

function adminDiscordBotView() {
  const value = config.discordBot;
  return {
    enabled: value.enabled,
    configured: Boolean(value.token),
    applicationId: value.applicationId,
    commandPrefix: value.commandPrefix,
    guildAllowlist: value.guildAllowlist,
    channelAllowlist: value.channelAllowlist,
    membersOnly: value.membersOnly,
    memberRoleIds: value.memberRoleIds,
    adminRoleIds: value.adminRoleIds,
    adminUserIds: value.adminUserIds,
    intents: value.intents,
    status: discordBot.status()
  };
}

function songLibraryView() {
  return {
    root: SONG_LIBRARY_DIR,
    stagingRoot: SONG_LIBRARY_STAGING_DIR,
    packageCount: songLibrary.packages.length,
    songCount: librarySongViews().length,
    staging: songLibrarySessions.map(songLibrarySessionView),
    packages: songLibrary.packages.map(pack => ({
      packageHash: pack.packageHash,
      fileName: pack.fileName,
      packageSize: pack.packageSize,
      importedAt: pack.importedAt,
      sourceType: pack.sourceType || 'zip',
      sourceSessionId: pack.sourceSessionId || '',
      songCount: Array.isArray(pack.songs) ? pack.songs.length : 0,
      songs: (pack.songs || []).map(song => ({
        songId: song.songId, songName: song.songName, artist: song.artist,
        charts: song.charts, coverPath: song.coverPath
      }))
    }))
  };
}

function readJsonBody(request) {
  return new Promise(resolve => {
    let size = 0;
    const chunks = [];
    let failed = false;
    request.on('data', chunk => {
      if (failed) return;
      size += chunk.length;
      if (size > config.maxMessageBytes) {
        failed = true;
        resolve({ error: 'request_too_large' });
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('error', () => {
      if (!failed) {
        failed = true;
        resolve({ error: 'request_read_failed' });
      }
    });
    request.on('end', () => {
      if (failed) return;
      try {
        const body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
        resolve({ body });
      } catch (_) {
        resolve({ error: 'invalid_json' });
      }
    });
  });
}

function handleSongLibraryImport(request, response) {
  const fileNameHeader = request.headers['x-file-name'];
  let requestedName = typeof fileNameHeader === 'string' ? fileNameHeader : 'song-library.zip';
  try { requestedName = decodeURIComponent(requestedName); } catch (_) {}
  const fileName = path.basename(requestedName).slice(0, 160);
  if (!/\.zip$/i.test(fileName)) {
    request.resume();
    return jsonResponse(response, 400, { error: 'song_package_must_be_zip' });
  }
  const contentLength = request.headers['content-length'] === undefined ? null : Number(request.headers['content-length']);
  if (contentLength !== null && (!Number.isSafeInteger(contentLength) || contentLength < 1 || contentLength > config.maxTransferBytes)) {
    request.resume();
    return jsonResponse(response, 413, { error: 'song_package_too_large' });
  }
  const temporaryPath = path.join(SONG_LIBRARY_PACKAGES_DIR, `.import-${randomHex(10)}.part`);
  const output = fs.createWriteStream(temporaryPath, { flags: 'wx', mode: 0o600 });
  const digest = crypto.createHash('sha256');
  let bytes = 0;
  let failed = false;
  let responded = false;
  const fail = (status, error, message = '') => {
    if (responded) return;
    responded = true;
    try { request.destroy(); } catch (_) {}
    try { output.destroy(); } catch (_) {}
    try { fs.unlinkSync(temporaryPath); } catch (_) {}
    jsonResponse(response, status, { error, message: message || error });
  };
  request.on('data', chunk => {
    if (failed) return;
    bytes += chunk.length;
    if (bytes > config.maxTransferBytes) {
      failed = true;
      return fail(413, 'song_package_too_large');
    }
    digest.update(chunk);
    if (!output.write(chunk)) request.pause();
  });
  output.on('drain', () => request.resume());
  request.on('error', () => fail(400, 'song_package_upload_failed'));
  output.on('error', () => fail(500, 'song_package_write_failed'));
  request.on('end', () => output.end());
  output.on('finish', () => {
    if (failed || responded) return;
    try {
      const packageHash = digest.digest('hex');
      const entries = readZipDirectory(temporaryPath);
      const manifestEntry = entries.find(entry => /(^|\/)chunithm-song\.json$/i.test(entry.name) || /(^|\/)songs\.json$/i.test(entry.name));
      if (!manifestEntry) return fail(400, 'song_manifest_missing', '数据包中缺少 chunithm-song.json 或 songs.json。');
      const manifest = JSON.parse(readZipEntry(temporaryPath, manifestEntry).toString('utf8'));
      const songs = normalizeLibrarySongs(manifest, temporaryPath, packageHash, bytes);
      const finalPath = path.join(SONG_LIBRARY_PACKAGES_DIR, `${packageHash}.zip`);
      if (fs.existsSync(finalPath)) {
        fs.unlinkSync(temporaryPath);
      } else {
        fs.renameSync(temporaryPath, finalPath);
      }
      songLibrary.packages = songLibrary.packages.filter(item => item.packageHash !== packageHash);
      songLibrary.packages.push({ packageHash, packageSize: bytes, fileName, path: finalPath, importedAt: isoTime(), songs });
      persistSongLibrary();
      audit('songLibraryImported', { packageHash, fileName, packageSize: bytes, songCount: songs.length });
      responded = true;
      return jsonResponse(response, 201, { ok: true, packageHash, packageSize: bytes, songCount: songs.length, library: songLibraryView() });
    } catch (error) {
      return fail(400, 'song_package_invalid', error.message);
    }
  });
}

function deleteSongLibraryPackage(packageHash) {
  const index = songLibrary.packages.findIndex(item => item.packageHash === packageHash);
  if (index < 0) return { error: { code: 'PACKAGE_NOT_FOUND', message: '数据包不存在。' } };
  if (Array.from(rooms.values()).some(room => room.song?.packageHash === packageHash))
    return { error: { code: 'PACKAGE_IN_USE', message: '当前有房间正在使用这个数据包。' } };
  const [removed] = songLibrary.packages.splice(index, 1);
  if (removed.path && pathIsInside(SONG_LIBRARY_GENERATED_DIR, removed.path)) {
    try { fs.unlinkSync(removed.path); } catch (_) {}
  } else if (removed.path) {
    try { fs.unlinkSync(removed.path); } catch (_) {}
  }
  persistSongLibrary();
  audit('songLibraryPackageDeleted', { packageHash });
  return { packageHash };
}

function setGameIdBlocked(gameId, blocked, reason) {
  if (!validGameId(gameId)) return { code: 'INVALID_GAME_ID', message: 'Game ID format is invalid.' };
  if (blocked) {
    serverState.blockedGameIds[gameId] = {
      reason: cleanText(reason || 'Blocked by administrator.', 160),
      blockedAt: isoTime(),
      blockedBy: 'admin'
    };
    const active = activeGameIds.get(gameId);
    if (active && !active.closed) {
      send(active, { type: 'gameIdBlocked', gameId, reason: serverState.blockedGameIds[gameId].reason, serverTime: now() });
      removeFromRoom(active, 'gameId-blocked', true);
      closeClient(active, 1008, 'Game ID blocked');
    }
    audit('gameIdBlocked', { gameId, reason: serverState.blockedGameIds[gameId].reason });
  } else {
    if (!Object.prototype.hasOwnProperty.call(serverState.blockedGameIds, gameId)) {
      return { code: 'GAME_ID_NOT_BLOCKED', message: 'This game ID is not blocked.' };
    }
    delete serverState.blockedGameIds[gameId];
    audit('gameIdUnblocked', { gameId });
  }
  persistServerState();
  broadcastRoomLists();
  return null;
}

function roomHasPassword(room) {
  return room.password !== null;
}

function roomSongSummary(song) {
  if (!song) return null;
  return {
    songId: song.songId,
    songName: song.songName,
    artist: song.artist,
    difficulty: song.difficulty,
    level: song.level,
    coverPath: song.coverPath || '',
    coverHash: song.coverHash || '',
    coverSize: Number(song.coverSize || 0),
    transferReady: song.transferReady === true,
    transferProgress: Number(song.transferProgress || 0),
    transferDirection: song.transferDirection || '',
    transferState: song.transferState || '',
    transferPlayerId: song.transferPlayerId || ''
  };
}

function roomVoteSnapshot(room) {
  // A vote is based on players who are currently connected to this room.
  // Disconnected members remain in the room record briefly so they can be
  // represented in snapshots, but they must not keep the threshold elevated.
  const eligibleMembers = Array.from(room.members.values()).filter(member =>
    !member.exited && member.client && !member.client.closed
  );
  const eligibleIds = new Set(eligibleMembers.map(member => member.gameId));
  const requiredRatio = Number.isFinite(room.songChangeVoteRequiredRatio)
    ? room.songChangeVoteRequiredRatio : config.songChangeVoteRequiredRatio;
  const eligible = eligibleMembers.length;
  const threshold = Math.max(1, Math.ceil(Math.max(1, eligible) * requiredRatio));
  const votes = room.songChangeVotes instanceof Set
    ? new Set(Array.from(room.songChangeVotes).filter(gameId => eligibleIds.has(gameId)))
    : new Set();
  if (room.songChangeVotes instanceof Set) room.songChangeVotes = votes;
  return {
    active: room.songChangeVoteActive === true,
    requiredRatio,
    threshold,
    count: votes.size,
    eligible,
    voters: Array.from(votes)
  };
}

function roomSummary(room) {
  const members = Array.from(room.members.values());
  const host = members.find(member => member.gameId === room.hostPlayerId);
  const owner = members.find(member => member.gameId === room.ownerPlayerId);
  return {
    roomId: room.id,
    roomName: room.name,
    ownerPlayerId: room.ownerPlayerId,
    ownerName: owner ? owner.name : 'unknown',
    hostPlayerId: room.hostPlayerId,
    hostName: host ? host.name : 'unknown',
    clientVersion: room.clientVersion || '',
    listed: room.listed,
    mode: room.mode,
    modPolicy: room.mode === 'normal' ? 'scoring-only' : 'any',
    selectionMode: room.persistent === true ? '' : room.selectionMode,
    roomType: room.persistent === true ? 'persistent' : 'personal',
    maxPlayers: room.maxPlayers,
    memberCount: members.length,
    state: room.state,
    mods: room.mods,
    librarySelection: room.persistent === true ? normalizeLibrarySelection(room.librarySelection) : null,
    hasPassword: roomHasPassword(room),
    persistent: room.persistent === true,
    songChangeVote: roomVoteSnapshot(room),
    song: roomSongSummary(room.song),
    updatedAt: isoTime(room.updatedAt)
  };
}

function memberSnapshot(room, member) {
  return {
    playerId: member.gameId,
    gameId: member.gameId,
    name: member.name,
    clientVersion: member.client.clientVersion || '',
    isOwner: member.gameId === room.ownerPlayerId,
    isHost: member.gameId === room.hostPlayerId,
    ready: member.ready,
    connected: !member.client.closed,
    status: member.status || 'unready',
    songReady: member.songReady === true,
    syncProgress: Number(member.syncProgress || 0),
    bestScore: Number(member.bestScore || 0),
    bestRank: member.bestRank || '',
    result: member.result || null,
    personalResultConfirmed: member.personalResultConfirmed === true,
    groupResultConfirmed: member.groupResultConfirmed === true
  };
}

function roomLeaderboard(room) {
  const completed = Array.from(room.members.values()).map(member => ({
    playerId: member.gameId,
    name: member.name,
    exited: member.exited === true,
    ...(member.result || { score: 0, rank: '', justiceCritical: 0, justice: 0, attack: 0, miss: 0, maxCombo: 0 })
  })).sort((left, right) => {
    if (left.exited !== right.exited) return left.exited ? 1 : -1;
    if (right.score !== left.score) return right.score - left.score;
    return left.name.localeCompare(right.name, 'zh-Hans');
  });
  let previousScore = null;
  let previousRank = 0;
  completed.forEach((result, index) => {
    if (result.exited) result.placement = 0;
    else if (previousScore !== null && result.score === previousScore) result.placement = previousRank;
    else {
      result.placement = index + 1;
      previousRank = result.placement;
      previousScore = result.score;
    }
  });
  return completed;
}

function roomSnapshot(room) {
  return {
    ...roomSummary(room),
    song: room.song,
    members: Array.from(room.members.values()).map(member => memberSnapshot(room, member)),
    roundId: room.roundId,
    startAt: room.startAt || 0,
    leaderboard: room.state === 'groupResults' ? roomLeaderboard(room) : [],
    serverTime: now()
  };
}

function normalizeRoomListFilters(value) {
  const input = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const allowedKeys = new Set(['idleOnly', 'notFullOnly', 'unencryptedOnly', 'mode', 'roomType']);
  if (Object.keys(input).some(key => !allowedKeys.has(key))) return null;
  const mode = input.mode === undefined || input.mode === '' ? '' : input.mode;
  if (mode !== '' && !ROOM_MODES.has(mode)) return null;
  const roomType = input.roomType === undefined || input.roomType === '' ? '' : input.roomType;
  if (roomType !== '' && !ROOM_TYPES.has(roomType)) return null;
  for (const key of ['idleOnly', 'notFullOnly', 'unencryptedOnly']) {
    if (input[key] !== undefined && typeof input[key] !== 'boolean') return null;
  }
  return {
    idleOnly: input.idleOnly === true,
    notFullOnly: input.notFullOnly === true,
    unencryptedOnly: input.unencryptedOnly === true,
    mode,
    roomType
  };
}

function publicRooms(search = '', exactRoomId = '', filters = {}) {
  const normalizedSearch = cleanText(search, 32).toLocaleLowerCase();
  const normalizedFilters = normalizeRoomListFilters(filters) || {
    idleOnly: false, notFullOnly: false, unencryptedOnly: false, mode: '', roomType: ''
  };
  const result = [];
  for (const room of rooms.values()) {
    const exactHiddenLookup = validRoomId(exactRoomId) && room.id === exactRoomId;
    if (!room.listed && !exactHiddenLookup) continue;
    if (normalizedFilters.idleOnly && isRoundActive(room)) continue;
    if (normalizedFilters.notFullOnly && room.members.size >= room.maxPlayers) continue;
    if (normalizedFilters.unencryptedOnly && roomHasPassword(room)) continue;
    if (normalizedFilters.mode && room.mode !== normalizedFilters.mode) continue;
    if (normalizedFilters.roomType && (room.persistent === true ? 'persistent' : 'personal') !== normalizedFilters.roomType) continue;
    if (normalizedSearch && !exactHiddenLookup) {
      const roomName = room.name.toLocaleLowerCase();
      const hostName = (roomSummary(room).hostName || '').toLocaleLowerCase();
      if (!roomName.includes(normalizedSearch) && !hostName.includes(normalizedSearch)) continue;
    }
    result.push(roomSummary(room));
  }
  return result.sort((a, b) => {
    if (a.state !== b.state) return a.state.localeCompare(b.state);
    return a.roomName.localeCompare(b.roomName, 'zh-Hans');
  });
}

function makeFrame(payload, opcode = 0x1) {
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(payload);
  let header;
  if (body.length < 126) {
    header = Buffer.from([0x80 | opcode, body.length]);
  } else if (body.length < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(body.length, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(body.length), 2);
  }
  return Buffer.concat([header, body]);
}

function send(client, message) {
  if (client.closed || !client.socket || client.socket.destroyed) return;
  const payload = Buffer.from(JSON.stringify(message));
  if (payload.length > config.maxMessageBytes) {
    closeClient(client, 1009, 'Message too large');
    return;
  }
  client.socket.write(makeFrame(payload));
}

function sendError(client, code, message, details) {
  const payload = { type: 'error', code, message, serverTime: now() };
  if (details !== undefined) payload.details = details;
  send(client, payload);
}

function closeClient(client, code = 1000, reason = '') {
  if (client.closed) return;
  client.closed = true;
  try {
    const reasonBuffer = Buffer.from(reason).subarray(0, 120);
    const payload = Buffer.alloc(2 + reasonBuffer.length);
    payload.writeUInt16BE(code, 0);
    reasonBuffer.copy(payload, 2);
    client.socket.write(makeFrame(payload, 0x8));
  } catch (_) {
    // The socket may already be half closed.
  }
  setTimeout(() => client.socket.destroy(), 50).unref();
}

function broadcastRoom(room, message) {
  for (const member of room.members.values()) send(member.client, message);
}

function broadcastRoomSnapshot(room) {
  broadcastRoom(room, { type: 'roomUpdated', room: roomSnapshot(room) });
}

function sendRoomList(client, search, exactRoomId, filters) {
  const hasQuery = search !== undefined || exactRoomId !== undefined || filters !== undefined;
  if (hasQuery) {
    const normalizedFilters = normalizeRoomListFilters(filters);
    if (!normalizedFilters) return sendError(client, 'INVALID_ROOM_FILTERS', 'Room search filters are invalid.');
    client.roomListSearch = cleanText(search, 32);
    client.roomListId = validRoomId(exactRoomId) ? exactRoomId : '';
    client.roomListFilters = normalizedFilters;
  }
  const normalizedFilters = client.roomListFilters || {
    idleOnly: false, notFullOnly: false, unencryptedOnly: false, mode: '', roomType: ''
  };
  if (!normalizedFilters) return sendError(client, 'INVALID_ROOM_FILTERS', 'Room search filters are invalid.');
  send(client, {
    type: 'roomList',
    rooms: publicRooms(client.roomListSearch || '', client.roomListId || '', normalizedFilters),
    filters: normalizedFilters,
    quota: quotaStatus(client.gameId),
    serverTime: now()
  });
}

function broadcastRoomLists() {
  for (const client of clients) if (client.hello) sendRoomList(client);
}

function releaseRoomReservation(client) {
  if (!client || !client.reservedRoomId) return;
  const reservation = reservedRoomIds.get(client.reservedRoomId);
  if (reservation && reservation.clientId === client.id) reservedRoomIds.delete(client.reservedRoomId);
  client.reservedRoomId = null;
}

function reserveRoomId(client) {
  if (getClientRoom(client)) return sendError(client, 'ALREADY_IN_ROOM', 'Leave the current room first.');
  const quota = quotaStatus(client.gameId);
  if (quota && quota.createRoomRemaining === 0) {
    return sendError(client, 'DAILY_CREATE_LIMIT_REACHED', '今日创建房间次数已用完。', { quota });
  }
  releaseRoomReservation(client);
  const roomId = randomRoomId();
  if (!roomId) return sendError(client, 'ROOM_ID_EXHAUSTED', 'Unable to reserve a room number.');
  const expiresAt = now() + config.roomReservationSeconds * 1000;
  reservedRoomIds.set(roomId, { clientId: client.id, gameId: client.gameId, expiresAt });
  client.reservedRoomId = roomId;
  send(client, { type: 'roomIdReserved', roomId, expiresAt, quota: quotaStatus(client.gameId), serverTime: now() });
}

function releaseReservedRoomId(client) {
  releaseRoomReservation(client);
  send(client, { type: 'roomIdReleased', quota: quotaStatus(client.gameId), serverTime: now() });
}

function takeReservedRoomId(client, requested) {
  if (validRoomId(requested)) {
    const reservation = reservedRoomIds.get(requested);
    if (reservation && reservation.clientId === client.id && reservation.expiresAt > now()) {
      reservedRoomIds.delete(requested);
      client.reservedRoomId = null;
      return requested;
    }
    return null;
  }
  const roomId = randomRoomId();
  return roomId;
}

function getClientRoom(client) {
  return client.roomId ? rooms.get(client.roomId) : null;
}

function newRoomMember(client, songReady = false) {
  return {
    gameId: client.gameId,
    name: client.name,
    client,
    ready: false,
    status: songReady ? 'unready' : 'syncing',
    songReady,
    syncProgress: songReady ? 1 : 0,
    bestScore: 0,
    bestRank: '',
    loaded: false,
    exited: false,
    result: null,
    personalResultConfirmed: false,
    groupResultConfirmed: false
  };
}

function releaseRoomTransfer(room) {
  if (!room || !room.transfer) return;
  if (room.transfer.path && room.transfer.owned !== false) {
    try { fs.unlinkSync(room.transfer.path); } catch (_) { /* best effort */ }
  }
  room.transfer = null;
}

function destroyRoom(room) {
  if (!room) return;
  releaseRoomTransfer(room);
  rooms.delete(room.id);
  reservedRoomIds.delete(room.id);
}

function lobbyStateFor(room) {
  if (!room.song) return 'lobby';
  return Array.from(room.members.values()).every(member => member.songReady) ? 'lobby' : 'syncing';
}

function resetMemberReadiness(room, preserveSongChangeVote = false) {
  for (const member of room.members.values()) {
    member.ready = false;
    member.loaded = false;
    member.exited = false;
    member.result = null;
    member.personalResultConfirmed = false;
    member.groupResultConfirmed = false;
    member.status = room.song && !member.songReady ? 'syncing' : 'unready';
  }
  room.state = lobbyStateFor(room);
  room.roundId = null;
  room.startAt = 0;
  if (!preserveSongChangeVote) {
    room.songChangeVoteActive = false;
    if (room.songChangeVotes instanceof Set) room.songChangeVotes.clear();
  }
}

function isRoundActive(room) {
  return room && ['readyCountdown', 'loading', 'countdown', 'playing', 'personalResults', 'groupResults'].includes(room.state);
}

function removeFromRoom(client, reason = 'left', announce = true) {
  const room = getClientRoom(client);
  if (!room) return;
  const wasHost = room.hostPlayerId === client.gameId;
  const wasOwner = room.ownerPlayerId === client.gameId;
  room.members.delete(client.gameId);
  client.roomId = null;
  room.updatedAt = now();

  if (room.members.size === 0) {
    if (room.persistent === true) {
      room.hostPlayerId = '';
      room.ownerPlayerId = '';
      room.clientVersion = '';
      room.songChangeVoteActive = false;
      if (room.songChangeVotes instanceof Set) room.songChangeVotes.clear();
      releaseRoomTransfer(room);
      room.song = null;
      room.state = 'lobby';
      room.roundId = null;
      room.startAt = 0;
      room.updatedAt = now();
      persistPersistentRooms();
      broadcastRoomLists();
    } else {
      destroyRoom(room);
    }
    broadcastRoomLists();
    return;
  }

  if (wasOwner) room.ownerPlayerId = room.members.values().next().value.gameId;
  if (wasHost || !room.members.has(room.hostPlayerId)) {
    const successor = room.members.values().next().value;
    room.hostPlayerId = successor.gameId;
    broadcastRoom(room, {
      type: 'hostChanged',
      roomId: room.id,
      hostPlayerId: successor.gameId,
      hostName: successor.name,
      reason: 'previous host left'
    });
  }
  // Keep an active song-change vote alive while membership changes. The vote
  // snapshot will prune the departed player's ballot and recalculate the
  // threshold from the remaining connected members.
  if (!isRoundActive(room)) resetMemberReadiness(room, room.songChangeVoteActive === true);
  if (announce) broadcastRoom(room, { type: 'memberLeft', roomId: room.id, playerId: client.gameId, gameId: client.gameId, reason });
  if (isRoundActive(room)) maybeCompleteRound(room);
  broadcastRoomSnapshot(room);
  broadcastRoomLists();
  if (room.persistent) persistPersistentRooms();
}

function kickFromRoom(hostClient, targetPlayerId) {
  const room = getClientRoom(hostClient);
  if (!room) return sendError(hostClient, 'NOT_IN_ROOM', 'You are not in a room.');
  if (room.hostPlayerId !== hostClient.gameId) return sendError(hostClient, 'HOST_ONLY', 'Only the current room host can remove players.');
  if (isRoundActive(room)) {
    return sendError(hostClient, 'KICK_NOT_ALLOWED_NOW', 'Players cannot be kicked while a song is playing.');
  }
  if (typeof targetPlayerId !== 'string' || targetPlayerId.length > 64) {
    return sendError(hostClient, 'INVALID_PLAYER_ID', 'The target player ID is invalid.');
  }
  if (targetPlayerId === hostClient.gameId) return sendError(hostClient, 'CANNOT_KICK_HOST', 'The host cannot kick themselves.');
  const target = room.members.get(targetPlayerId);
  if (!target) return sendError(hostClient, 'PLAYER_NOT_FOUND', 'That player is not in this room.');

  const cooldownUntil = now() + 60 * 1000;
  room.kickedGameIds.set(target.gameId, cooldownUntil);
  send(target.client, {
    type: 'kickedFromRoom',
    roomId: room.id,
    reason: 'Removed by the room host.',
    cooldownUntil,
    serverTime: now()
  });
  removeFromRoom(target.client, 'kicked', true);
  sendRoomList(hostClient);
}

function transferRoomHost(hostClient, targetPlayerId) {
  const room = getClientRoom(hostClient);
  if (!room) return sendError(hostClient, 'NOT_IN_ROOM', 'You are not in a room.');
  if (room.hostPlayerId !== hostClient.gameId) return sendError(hostClient, 'HOST_ONLY', 'Only the current room host can transfer host rights.');
  if (isRoundActive(room)) return sendError(hostClient, 'HOST_TRANSFER_NOT_ALLOWED_NOW', 'Host cannot be transferred during a round.');
  if (typeof targetPlayerId !== 'string' || targetPlayerId.length > 64) {
    return sendError(hostClient, 'INVALID_PLAYER_ID', 'The target player ID is invalid.');
  }
  const target = room.members.get(targetPlayerId);
  if (!target) return sendError(hostClient, 'PLAYER_NOT_FOUND', 'That player is not in this room.');
  if (target.gameId === hostClient.gameId) return sendError(hostClient, 'ALREADY_HOST', 'That player is already the host.');
  room.hostPlayerId = target.gameId;
  room.updatedAt = now();
  broadcastRoom(room, {
    type: 'hostChanged',
    roomId: room.id,
    hostPlayerId: target.gameId,
    hostName: target.name,
    reason: 'host transferred by the previous host',
    serverTime: now()
  });
  broadcastRoomSnapshot(room);
}

function createRoom(client, message) {
  if (getClientRoom(client)) return sendError(client, 'ALREADY_IN_ROOM', 'Leave the current room first.');
  if (rooms.size >= config.maxRooms) return sendError(client, 'ROOM_LIMIT', 'The server has reached its room limit.');

  const name = normalizeRoomName(message.roomName);
  const mode = message.roomMode;
  const selectionMode = normalizeSelectionMode(message.selectionMode);
  const roomType = normalizeRoomType(message.roomType);
  if (roomType !== 'personal') {
    return sendError(client, 'PERSISTENT_ROOM_ADMIN_ONLY', '常驻房间只能由服务端后台创建。客户端只能创建个人房间。');
  }
  const maxPlayers = normalizeMaxPlayers(message.maxPlayers);
  const mods = normalizeMods(message.mods);
  const password = message.password === undefined || message.password === '' ? null : message.password;
  if (!name) return sendError(client, 'INVALID_ROOM_NAME', 'Room name must contain 1 to 15 characters.');
  if (!ROOM_MODES.has(mode)) return sendError(client, 'INVALID_ROOM_MODE', 'Room mode must be casual or normal.');
  if (!maxPlayers || maxPlayers > PERSONAL_ROOM_MAX_PLAYERS)
    return sendError(client, 'INVALID_MAX_PLAYERS', `Personal rooms support between 2 and ${PERSONAL_ROOM_MAX_PLAYERS} players.`);
  if (!selectionMode) return sendError(client, 'INVALID_SELECTION_MODE', 'Selection mode must be host or loop.');
  if (!mods) return sendError(client, 'INVALID_MODS', 'The MOD payload is invalid.');
  const modeError = validateRoomModeAndMods(mode, mods);
  if (modeError) return sendError(client, modeError.code, modeError.message);
  if (password !== null && (typeof password !== 'string' || password.length < 4 || password.length > 64)) {
    return sendError(client, 'INVALID_PASSWORD', 'Room password must be 4 to 64 characters.');
  }
  if (message.listed !== undefined && typeof message.listed !== 'boolean')
    return sendError(client, 'INVALID_LISTED_FLAG', 'The listed flag must be boolean.');

  let roomId = null;
  if (validRoomId(message.reservedRoomId)) {
    const reservation = reservedRoomIds.get(message.reservedRoomId);
    if (!reservation || reservation.clientId !== client.id || reservation.expiresAt <= now())
      return sendError(client, 'ROOM_RESERVATION_EXPIRED', 'The reserved room number expired. Request another one.');
    roomId = message.reservedRoomId;
  } else roomId = randomRoomId();
  if (!roomId) return sendError(client, 'ROOM_ID_EXHAUSTED', 'Unable to allocate a room number.');
  if (!consumeRoomQuota(client, 'create')) return;
  releaseRoomReservation(client);
  const room = {
    id: roomId,
    name,
    clientVersion: client.clientVersion,
    listed: message.listed !== false,
    persistent: roomType === 'persistent',
    mode,
    maxPlayers,
    selectionMode,
    mods,
    password: hashPassword(password),
    state: 'lobby',
    ownerPlayerId: client.gameId,
    hostPlayerId: client.gameId,
    members: new Map(),
    kickedGameIds: new Map(),
    song: null,
    transfer: null,
    roundId: null,
    startAt: 0,
    createdAt: now(),
    updatedAt: now()
  };
  room.songChangeVoteRequiredRatio = config.songChangeVoteRequiredRatio;
  room.songChangeVoteActive = false;
  room.songChangeVotes = new Set();
  room.members.set(client.gameId, newRoomMember(client, true));
  rooms.set(room.id, room);
  if (room.persistent) persistPersistentRooms();
  client.roomId = room.id;
  send(client, { type: 'roomCreated', room: roomSnapshot(room), quota: quotaStatus(client.gameId), serverTime: now() });
  broadcastRoomLists();
  console.log(`[room] created ${room.id} ${room.name} mode=${room.mode} by=${client.name}`);
}

// Persistent rooms are server-managed resources. They are created from the
// local admin panel without a connected player, then the first client that
// joins becomes the temporary host. This keeps the 20-player capacity out of
// the normal client-created personal-room flow.
function createPersistentRoomFromAdmin(body) {
  if (rooms.size >= config.maxRooms) return { error: { code: 'ROOM_LIMIT', message: 'The server has reached its room limit.' } };
  const suppliedName = body?.roomName === undefined || body.roomName === '' ? '常驻房间' : normalizeRoomName(body.roomName);
  if (!suppliedName) return { error: { code: 'INVALID_ROOM_NAME', message: '常驻房间名称必须为 1 至 15 个字符。' } };
  const name = suppliedName;
  const mode = ROOM_MODES.has(body?.roomMode) ? body.roomMode : 'casual';
  const selectionMode = 'host';
  const mods = normalizeMods(body?.mods || {}) || normalizeMods({});
  const maxAllowed = Math.min(PERSISTENT_ROOM_MAX_PLAYERS, config.maxPlayersPerRoom);
  const requestedMax = body?.maxPlayers === undefined ? maxAllowed : normalizeMaxPlayers(body.maxPlayers);
  const maxPlayers = requestedMax && requestedMax <= maxAllowed ? requestedMax : maxAllowed;
  const password = body?.password === undefined || body.password === '' ? null : body.password;
  if (password !== null && (typeof password !== 'string' || password.length < 4 || password.length > 64))
    return { error: { code: 'INVALID_PASSWORD', message: 'Room password must be 4 to 64 characters.' } };
  const requestedRoomId = body?.roomId === undefined ? '' : String(body.roomId).trim();
  if (requestedRoomId && !/^\d{3}$/.test(requestedRoomId)) {
    return { error: { code: 'INVALID_PERSISTENT_ROOM_ID', message: '常驻房间号必须是 3 位数字。' } };
  }
  if (requestedRoomId && (rooms.has(requestedRoomId) || reservedRoomIds.has(requestedRoomId))) {
    return { error: { code: 'ROOM_ID_IN_USE', message: '这个常驻房间号已经被占用。' } };
  }
  const roomId = requestedRoomId || randomPersistentRoomId();
  if (!roomId) return { error: { code: 'ROOM_ID_EXHAUSTED', message: 'Unable to allocate a room number.' } };
  const room = {
    id: roomId, name, clientVersion: cleanText(body?.clientVersion, 32), listed: body?.listed !== false,
    persistent: true, mode, maxPlayers, selectionMode, mods, password: hashPassword(password), state: 'lobby',
    ownerPlayerId: '', hostPlayerId: '', members: new Map(), kickedGameIds: new Map(), song: null,
    librarySelection: normalizeLibrarySelection(body?.librarySelection),
    transfer: null, roundId: null, startAt: 0, createdAt: now(), updatedAt: now(),
    songChangeVoteRequiredRatio: config.songChangeVoteRequiredRatio, songChangeVoteActive: false,
    songChangeVotes: new Set()
  };
  rooms.set(room.id, room);
  // If the server library is already available, give a newly-created
  // persistent room an initial song immediately. A room created before the
  // library import will be filled when its first member joins.
  selectLibrarySongForRoom(room);
  persistPersistentRooms();
  audit('persistentRoomCreated', { roomId: room.id, roomName: room.name, maxPlayers: room.maxPlayers });
  broadcastRoomLists();
  return { room: roomSnapshot(room) };
}

function updatePersistentRoomFromAdmin(roomId, body) {
  const room = rooms.get(roomId);
  if (!room || room.persistent !== true) return { error: { code: 'ROOM_NOT_FOUND', message: '常驻房间不存在。' } };
  if (isRoundActive(room)) return { error: { code: 'ROOM_IN_PROGRESS', message: '房间正在游玩，暂时不能编辑。' } };
  const name = body?.roomName === undefined ? room.name : normalizeRoomName(body.roomName);
  const mode = body?.roomMode === undefined ? room.mode : body.roomMode;
  const selectionMode = 'host';
  const maxAllowed = Math.min(PERSISTENT_ROOM_MAX_PLAYERS, config.maxPlayersPerRoom);
  const maxPlayers = body?.maxPlayers === undefined ? room.maxPlayers : normalizeMaxPlayers(body.maxPlayers);
  const mods = body?.mods === undefined ? room.mods : normalizeMods(body.mods);
  if (!name) return { error: { code: 'INVALID_ROOM_NAME', message: '房间名称无效。' } };
  if (!ROOM_MODES.has(mode)) return { error: { code: 'INVALID_ROOM_MODE', message: '房间模式无效。' } };
  if (!maxPlayers || maxPlayers < room.members.size || maxPlayers > maxAllowed)
    return { error: { code: 'INVALID_MAX_PLAYERS', message: `常驻房间人数必须为 2 至 ${maxAllowed}，且不能低于当前人数。` } };
  if (!mods) return { error: { code: 'INVALID_MODS', message: 'MOD 配置无效。' } };
  const modeError = validateRoomModeAndMods(mode, mods);
  if (modeError) return { error: modeError };
  if (body?.listed !== undefined && typeof body.listed !== 'boolean')
    return { error: { code: 'INVALID_LISTED_FLAG', message: '公开状态无效。' } };
  if (body?.password !== undefined && body.password !== '' &&
      (typeof body.password !== 'string' || body.password.length < 4 || body.password.length > 64))
    return { error: { code: 'INVALID_PASSWORD', message: '房间密码必须是 4 至 64 个字符。' } };
  room.name = name;
  room.mode = mode;
  room.selectionMode = 'host';
  room.maxPlayers = maxPlayers;
  room.mods = mods;
  room.librarySelection = normalizeLibrarySelection(body?.librarySelection === undefined ? room.librarySelection : body.librarySelection);
  if (body?.listed !== undefined) room.listed = body.listed === true;
  if (body?.password !== undefined) room.password = body.password ? hashPassword(body.password) : null;
  if (!room.song) selectLibrarySongForRoom(room);
  resetMemberReadiness(room);
  room.updatedAt = now();
  persistPersistentRooms();
  broadcastRoomSnapshot(room);
  broadcastRoomLists();
  audit('persistentRoomUpdated', { roomId: room.id, roomName: room.name });
  return { room: roomSnapshot(room) };
}

function selectPersistentRoomSongFromAdmin(roomId, body) {
  const room = rooms.get(roomId);
  if (!room || room.persistent !== true)
    return { error: { code: 'ROOM_NOT_FOUND', message: '常驻房间不存在。' } };
  if (isRoundActive(room))
    return { error: { code: 'ROOM_IN_PROGRESS', message: '房间正在游玩，暂时不能更改歌曲。' } };
  const selected = selectLibrarySongForRoom(room, {
    songId: cleanText(body?.songId, 128),
    difficulty: cleanText(body?.difficulty, 32),
    excludeSongId: cleanText(body?.excludeSongId, 128)
  });
  if (!selected)
    return { error: { code: 'LIBRARY_SONG_NOT_FOUND', message: '曲库中没有符合条件的歌曲，或歌曲包文件不可用。' } };
  audit('persistentRoomSongSelected', { roomId: room.id, songId: room.song?.songId || '' });
  persistPersistentRooms();
  broadcastRoomLists();
  return { room: roomSnapshot(room) };
}

function kickPersistentRoomMemberFromAdmin(roomId, gameId) {
  const room = rooms.get(roomId);
  if (!room || room.persistent !== true)
    return { error: { code: 'ROOM_NOT_FOUND', message: '常驻房间不存在。' } };
  if (isRoundActive(room))
    return { error: { code: 'ROOM_IN_PROGRESS', message: '房间正在游玩，暂时不能踢出成员。' } };
  const member = room.members.get(String(gameId || ''));
  if (!member) return { error: { code: 'PLAYER_NOT_FOUND', message: '成员不在该常驻房间内。' } };
  room.kickedGameIds.set(member.gameId, now() + 60 * 1000);
  send(member.client, { type: 'kickedFromRoom', roomId: room.id, reason: 'Removed by the server administrator.', cooldownUntil: now() + 60 * 1000, serverTime: now() });
  removeFromRoom(member.client, 'admin-kicked', true);
  audit('persistentRoomMemberKicked', { roomId: room.id, gameId: member.gameId });
  return { room: roomSnapshot(room) };
}

function deletePersistentRoomFromAdmin(roomId) {
  const room = rooms.get(roomId);
  if (!room || room.persistent !== true) return { error: { code: 'ROOM_NOT_FOUND', message: '常驻房间不存在。' } };
  if (room.members.size > 0) return { error: { code: 'ROOM_NOT_EMPTY', message: '房间还有成员，成员全部离开后才能删除。' } };
  if (isRoundActive(room)) return { error: { code: 'ROOM_IN_PROGRESS', message: '房间正在游玩，暂时不能删除。' } };
  destroyRoom(room);
  persistPersistentRooms();
  broadcastRoomLists();
  audit('persistentRoomDeleted', { roomId });
  return { roomId };
}

function joinRoom(client, message) {
  if (getClientRoom(client)) return sendError(client, 'ALREADY_IN_ROOM', 'Leave the current room first.');
  if (!validRoomId(message.roomId)) return sendError(client, 'INVALID_ROOM_ID', 'Room ID must be three digits for persistent rooms or six digits for personal rooms.');
  const room = rooms.get(message.roomId);
  if (!room) return sendError(client, 'ROOM_NOT_FOUND', 'Room not found.');
  if (room.members.size >= room.maxPlayers) return sendError(client, 'ROOM_FULL', 'The room is full.');
  if (isRoundActive(room)) {
    return sendError(client, 'ROOM_IN_PROGRESS', 'You can join after the current song ends.');
  }
  if (room.clientVersion && room.clientVersion !== client.clientVersion) {
    return sendError(client, 'CLIENT_VERSION_MISMATCH', 'All players in a room must use the same client version.', {
      expectedVersion: room.clientVersion,
      actualVersion: client.clientVersion
    });
  }
  const kickedUntil = Number(room.kickedGameIds.get(client.gameId) || 0);
  if (kickedUntil > now()) {
    return sendError(client, 'KICKED_FROM_ROOM', '你已被房主移出房间，请等待一分钟后再加入。', {
      cooldownUntil: kickedUntil,
      remainingSeconds: Math.max(1, Math.ceil((kickedUntil - now()) / 1000))
    });
  }
  if (kickedUntil > 0) {
    room.kickedGameIds.delete(client.gameId);
  }
  if (!verifyPassword(message.password, room.password)) return sendError(client, 'INVALID_PASSWORD', 'Room password is incorrect.');
  if (Array.from(room.members.values()).some(member => member.name === client.name)) {
    return sendError(client, 'NAME_IN_USE', 'That player name is already in this room.');
  }
  if (!consumeRoomQuota(client, 'join')) return;
  room.members.set(client.gameId, newRoomMember(client, !room.song));
  if (room.persistent === true && room.members.size === 1) {
    if (!room.ownerPlayerId) room.ownerPlayerId = client.gameId;
    room.hostPlayerId = client.gameId;
    if (!room.clientVersion) room.clientVersion = client.clientVersion;
  }
  if (room.persistent === true && !room.song) {
    selectLibrarySongForRoom(room, { excludeSongId: '' });
  }
  client.roomId = room.id;
  room.updatedAt = now();
  if (room.persistent) persistPersistentRooms();
  send(client, { type: 'roomJoined', room: roomSnapshot(room), quota: quotaStatus(client.gameId), serverTime: now() });
  broadcastRoom(room, { type: 'memberJoined', roomId: room.id, playerId: client.gameId, gameId: client.gameId, playerName: client.name });
  broadcastRoomSnapshot(room);
  broadcastRoomLists();
  console.log(`[room] joined ${room.id} player=${client.name}`);
}

function leaveRoom(client) {
  if (!getClientRoom(client)) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  const roomId = client.roomId;
  removeFromRoom(client, 'left', true);
  send(client, { type: 'roomLeft', roomId, quota: quotaStatus(client.gameId), serverTime: now() });
}

function leaveLobby(client) {
  if (getClientRoom(client)) removeFromRoom(client, 'left', true);
  releaseRoomReservation(client);
  const record = getDeviceRecord(client.gameId);
  if (record) {
    record.lobbyReentryCooldownUntil = now() + LOBBY_REENTRY_COOLDOWN_MS;
    persistServerState();
  }
  send(client, {
    type: 'lobbyLeft',
    cooldownUntil: record ? record.lobbyReentryCooldownUntil : now() + LOBBY_REENTRY_COOLDOWN_MS,
    remainingSeconds: 60,
    serverTime: now()
  });
}

function setReady(client, message) {
  const room = getClientRoom(client);
  if (!room) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (isRoundActive(room)) return sendError(client, 'READY_NOT_ALLOWED_NOW', 'Ready status cannot change during a round.');
  const member = room.members.get(client.gameId);
  if (message.ready === true && !room.song) return sendError(client, 'SONG_NOT_SELECTED', 'Select a song before getting ready.');
  if (message.ready === true && !member.songReady) return sendError(client, 'SONG_NOT_READY', 'Finish downloading and verifying the song first.');
  if (message.ready === true && room.songChangeVoteActive === true)
    return sendError(client, 'READY_NOT_ALLOWED_VOTE', '换歌投票进行中，暂时不能准备。');
  member.ready = message.ready === true;
  member.status = member.ready ? 'ready' : 'unready';
  room.state = lobbyStateFor(room);
  room.updatedAt = now();
  broadcastRoomSnapshot(room);
  maybeBeginRound(room);
}

function updateRoomSettings(client, message) {
  const room = getClientRoom(client);
  if (!room) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (room.hostPlayerId !== client.gameId) return sendError(client, 'HOST_ONLY', 'Only the current room host can change room settings.');
  if (isRoundActive(room)) return sendError(client, 'SETTINGS_LOCKED', 'Room settings are locked during a round.');
  if (Array.from(room.members.values()).some(member => member.ready))
    return sendError(client, 'SETTINGS_LOCKED_READY', '已有成员准备，不能修改 MOD 或房间设置。');

  const nextMode = message.roomMode === undefined ? room.mode : message.roomMode;
  const maxAllowed = roomMaxPlayers(room.persistent === true ? 'persistent' : 'personal');
  const nextMax = message.maxPlayers === undefined ? room.maxPlayers : normalizeMaxPlayers(message.maxPlayers);
  const nextSelection = message.selectionMode === undefined ? room.selectionMode : normalizeSelectionMode(message.selectionMode);
  const nextMods = message.mods === undefined ? room.mods : normalizeMods(message.mods);
  if (!nextMax || nextMax > maxAllowed || nextMax < room.members.size)
    return sendError(client, 'INVALID_MAX_PLAYERS', `This room supports between 2 and ${maxAllowed} players.`);
  if (!nextSelection) return sendError(client, 'INVALID_SELECTION_MODE', 'Selection mode must be host or loop.');
  const modeError = validateRoomModeAndMods(nextMode, nextMods);
  if (modeError) return sendError(client, modeError.code, modeError.message);
  if (message.listed !== undefined && typeof message.listed !== 'boolean')
    return sendError(client, 'INVALID_LISTED_FLAG', 'The listed flag must be boolean.');

  room.maxPlayers = nextMax;
  room.mode = nextMode;
  room.selectionMode = nextSelection;
  room.mods = nextMods;
  if (message.listed !== undefined) room.listed = message.listed === true;
  resetMemberReadiness(room);
  room.updatedAt = now();
  broadcastRoom(room, { type: 'roomSettingsUpdated', room: roomSnapshot(room) });
  broadcastRoomSnapshot(room);
  broadcastRoomLists();
}

function finishSongChangeVote(room, requester) {
  const vote = roomVoteSnapshot(room);
  const previousSong = room.song;
  room.songChangeVoteActive = false;
  if (room.songChangeVotes instanceof Set) room.songChangeVotes.clear();
  // Passing a vote returns the room to song selection. The old package is
  // released immediately so clients cannot start the previous round while
  // the host is selecting the replacement song.
  releaseRoomTransfer(room);
  room.song = null;
  for (const member of room.members.values()) {
    member.ready = false;
    member.songReady = true;
    member.syncProgress = 1;
    member.status = 'unready';
    member.bestScore = 0;
    member.bestRank = '';
  }
  room.state = 'lobby';
  room.roundId = null;
  room.startAt = 0;
  room.updatedAt = now();

  // Persistent rooms are server-managed. Passing a vote must immediately
  // assign the next library song instead of leaving room.song empty.
  if (room.persistent === true) {
    let selected = selectLibrarySongForRoom(room, {
      excludeSongId: previousSong?.songId || ''
    });
    // A filter can legitimately contain only one song. In that case a vote
    // still has to leave the room playable: retry the configured selection
    // without the exclusion before falling back to the previous metadata.
    if (!selected) selected = selectLibrarySongForRoom(room);
    if (selected) {
      broadcastRoom(room, {
        type: 'songChangeVotePassed', roomId: room.id,
        requiredRatio: vote.requiredRatio, voteCount: vote.count,
        eligibleCount: vote.eligible, previousSongId: previousSong?.songId || '',
        requesterId: requester?.gameId || '', serverTime: now()
      });
      broadcastRoomLists();
      persistPersistentRooms();
      return;
    }
    if (previousSong) {
      room.song = previousSong;
      room.state = lobbyStateFor(room);
      room.updatedAt = now();
      broadcastRoom(room, {
        type: 'songChangeVotePassed', roomId: room.id,
        requiredRatio: vote.requiredRatio, voteCount: vote.count,
        eligibleCount: vote.eligible, previousSongId: previousSong.songId || '',
        retainedSong: true, requesterId: requester?.gameId || '', serverTime: now()
      });
      broadcastRoomSnapshot(room);
      broadcastRoomLists();
      persistPersistentRooms();
      return;
    }
  }

  broadcastRoom(room, {
    type: 'songChangeVotePassed',
    roomId: room.id,
    requiredRatio: vote.requiredRatio,
    voteCount: vote.count,
    eligibleCount: vote.eligible,
    previousSongId: previousSong?.songId || '',
    requesterId: requester?.gameId || '',
    serverTime: now()
  });
  broadcastRoom(room, { type: 'returnedToLobby', roomId: room.id, room: roomSnapshot(room), serverTime: now() });
  broadcastRoomSnapshot(room);
  broadcastRoomLists();
  if (room.persistent) persistPersistentRooms();
}

function requestSongChangeVote(client) {
  const room = getClientRoom(client);
  if (!room) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (!room.song) return sendError(client, 'SONG_NOT_SELECTED', 'There is no selected song to change.');
  if (isRoundActive(room)) return sendError(client, 'VOTE_NOT_ALLOWED_NOW', 'A vote cannot start during a round.');
  if (Array.from(room.members.values()).some(member => member.ready))
    return sendError(client, 'VOTE_NOT_ALLOWED_READY', '准备后不能发起换歌投票。');
  const member = room.members.get(client.gameId);
  if (!member) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  room.songChangeVoteActive = true;
  if (!(room.songChangeVotes instanceof Set)) room.songChangeVotes = new Set();
  room.songChangeVotes.add(client.gameId);
  room.updatedAt = now();
  const vote = roomVoteSnapshot(room);
  broadcastRoom(room, {
    type: 'songChangeVoteUpdated', roomId: room.id, ...vote, serverTime: now()
  });
  if (vote.count >= vote.threshold) finishSongChangeVote(room, client);
  else broadcastRoomSnapshot(room);
}

function castSongChangeVote(client) {
  const room = getClientRoom(client);
  if (!room || room.songChangeVoteActive !== true)
    return sendError(client, 'VOTE_NOT_ACTIVE', 'There is no active song-change vote.');
  if (isRoundActive(room)) return sendError(client, 'VOTE_NOT_ALLOWED_NOW', 'A vote cannot continue during a round.');
  if (Array.from(room.members.values()).some(member => member.ready))
    return sendError(client, 'VOTE_NOT_ALLOWED_READY', '准备后不能继续换歌投票。');
  const member = room.members.get(client.gameId);
  if (!member || member.exited) return sendError(client, 'VOTE_NOT_ALLOWED', 'This player cannot vote now.');
  if (!(room.songChangeVotes instanceof Set)) room.songChangeVotes = new Set();
  room.songChangeVotes.add(client.gameId);
  room.updatedAt = now();
  const vote = roomVoteSnapshot(room);
  broadcastRoom(room, {
    type: 'songChangeVoteUpdated', roomId: room.id, ...vote, serverTime: now()
  });
  if (vote.count >= vote.threshold) finishSongChangeVote(room, client);
  else broadcastRoomSnapshot(room);
}

function selectSong(client, message, options = {}) {
  const serverSelection = options.serverSelection === true;
  const room = options.room || getClientRoom(client);
  const selectorId = serverSelection ? 'server' : client.gameId;
  if (!room) return serverSelection ? false : sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (!serverSelection && room.hostPlayerId !== client.gameId)
    return sendError(client, 'HOST_ONLY', 'Only the current room host can select a song.');
  if (isRoundActive(room)) return serverSelection ? false : sendError(client, 'SELECTION_LOCKED', 'Song selection is locked during a round.');
  const songId = cleanText(message.songId, 128);
  const songName = cleanText(message.songName, 160);
  const artist = cleanText(message.artist, 160);
  const chartPath = cleanText(message.chartPath, 256);
  const difficulty = cleanText(message.difficulty, 32);
  const level = cleanText(message.level, 16);
  const designer = cleanText(message.designer, 96);
  const packageHash = typeof message.packageHash === 'string' ? message.packageHash.toLowerCase() : '';
  const packageSize = Number(message.packageSize);
  const coverPath = cleanText(message.coverPath, 256);
  const coverHash = typeof message.coverHash === 'string' ? message.coverHash.toLowerCase() : '';
  const coverSize = Number(message.coverSize);
  if (!songId || !chartPath || !difficulty || chartPath.includes('..') || chartPath.includes('\\')) {
    return sendError(client, 'INVALID_SONG_SELECTION', 'Song selection is invalid.');
  }
  if (!validHash(message.chartHash) || !message.chartHash) return sendError(client, 'INVALID_CHART_HASH', 'Chart hash must be SHA-256.');
  if (!validHash(packageHash) || !packageHash || !Number.isSafeInteger(packageSize) || packageSize < 1 || packageSize > config.maxTransferBytes)
    return sendError(client, 'INVALID_SONG_PACKAGE', 'Song package hash or size is invalid.');
  if (coverPath.includes('..') || coverPath.includes('\\') || (coverHash && !validHash(coverHash)) ||
      (coverSize && (!Number.isSafeInteger(coverSize) || coverSize < 0 || coverSize > config.maxTransferBytes)))
    return sendError(client, 'INVALID_SONG_COVER', 'Song cover metadata is invalid.');
  releaseRoomTransfer(room);
  room.songChangeVoteActive = false;
  if (room.songChangeVotes instanceof Set) room.songChangeVotes.clear();
  const serverPackagePath = typeof options.serverPackagePath === 'string' ? options.serverPackagePath : '';
  const serverTransfer = Boolean(serverPackagePath);
  room.transfer = {
    id: packageHash, expectedSize: packageSize, size: 0, sha256: packageHash,
    ready: serverTransfer, uploadedAt: serverTransfer ? now() : 0, uploadProgress: serverTransfer ? 1 : 0,
    direction: serverTransfer ? 'server' : 'upload', state: serverTransfer ? 'completed' : 'started',
    owned: !serverTransfer, path: serverTransfer ? serverPackagePath : null
  };
  room.song = {
    songId,
    songName: songName || songId,
    artist,
    chartPath,
    difficulty,
    level,
    designer,
    bpm: cleanText(message.bpm, 24),
    durationText: cleanText(message.durationText, 16),
    chartHash: message.chartHash.toLowerCase(),
    packageHash,
    packageSize,
    coverPath,
    coverHash,
    coverSize: coverSize > 0 ? coverSize : 0,
    transferReady: serverTransfer,
    transferProgress: serverTransfer ? 1 : 0,
    transferDirection: serverTransfer ? 'server' : 'upload',
    transferState: serverTransfer ? 'completed' : 'started',
    transferPlayerId: serverTransfer ? '' : selectorId,
    downloadPath: `/api/v1/transfers/${room.id}/${packageHash}`,
    selectedBy: serverTransfer ? 'server' : selectorId,
    selectedAt: isoTime()
  };
  for (const member of room.members.values()) {
    member.ready = false;
    member.songReady = !serverTransfer && member.gameId === client.gameId;
    member.syncProgress = member.songReady ? 1 : 0;
    member.status = member.songReady ? 'unready' : 'syncing';
    member.bestScore = 0;
    member.bestRank = '';
  }
  room.state = lobbyStateFor(room);
  room.updatedAt = now();
  broadcastRoom(room, { type: 'songSelected', roomId: room.id, song: room.song, serverTime: now() });
  broadcastRoomSnapshot(room);
  return true;
}

function chooseLibrarySong(selection, message) {
  let songs = librarySongViews();
  const settings = normalizeLibrarySelection(selection);
  if (settings.mode === 'songs') songs = songs.filter(song => settings.songIds.includes(song.songId));
  if (settings.mode === 'levels') songs = songs.filter(song => song.charts.some(chart => settings.levels.includes(chart.level)));
  if (settings.mode === 'random' && settings.levels.length) songs = songs.filter(song => song.charts.some(chart => settings.levels.includes(chart.level)));
  const requestedId = cleanText(message?.songId, 128);
  const excludedId = cleanText(message?.excludeSongId, 128);
  const requestedDifficulty = cleanText(message?.difficulty, 32);
  if (requestedId) songs = songs.filter(song => song.songId === requestedId);
  if (!requestedId && excludedId && songs.length > 1) songs = songs.filter(song => song.songId !== excludedId);
  if (requestedDifficulty) songs = songs.filter(song => song.charts.some(chart => chart.difficulty === requestedDifficulty));
  if (!songs.length) return null;
  return songs[crypto.randomInt(0, songs.length)];
}

// Select the chart that will actually be sent to the client. A library level
// filter applies to charts, not only to the song container: a song can contain
// BASIC Lv.5 and MASTER Lv.13 at the same time, so taking charts[0] would
// silently bypass the room's configured level range.
function chooseLibraryChart(selection, song, message = {}) {
  if (!song || !Array.isArray(song.charts)) return null;
  const settings = normalizeLibrarySelection(selection);
  const requestedDifficulty = cleanText(message.difficulty, 32);
  if (requestedDifficulty) {
    const requested = song.charts.find(chart => chart.difficulty === requestedDifficulty);
    if (requested && ((settings.mode !== 'levels' && settings.mode !== 'random') || !settings.levels.length ||
      settings.levels.includes(requested.level))) return requested;
    if (settings.mode === 'levels' || settings.mode === 'random') return null;
  }

  let charts = song.charts;
  if ((settings.mode === 'levels' || settings.mode === 'random') && settings.levels.length) {
    charts = charts.filter(chart => settings.levels.includes(chart.level));
  }
  if (!charts.length) return null;
  return charts[crypto.randomInt(0, charts.length)];
}

function listLibrarySongs(client, message) {
  const room = getClientRoom(client);
  if (!room) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (room.persistent !== true) return sendError(client, 'LIBRARY_ONLY_IN_PERSISTENT_ROOM', '服务器曲库只对常驻房间开放。');
  const selection = normalizeLibrarySelection(message?.selection || room.librarySelection);
  const songs = librarySongViews().filter(song => {
    if (selection.mode === 'songs' && !selection.songIds.includes(song.songId)) return false;
    if ((selection.mode === 'levels' || selection.mode === 'random') && selection.levels.length &&
        !song.charts.some(chart => selection.levels.includes(chart.level))) return false;
    return true;
  }).slice(0, 500).map(song => ({
    songId: song.songId, songName: song.songName, artist: song.artist, packageHash: song.packageHash,
    packageSize: song.packageSize, charts: song.charts.map(chart => ({ difficulty: chart.difficulty, level: chart.level, designer: chart.designer })),
    coverPath: song.coverPath, importedAt: song.importedAt
  }));
  send(client, { type: 'librarySongList', roomId: room.id, selection, songs, serverTime: now() });
}

function selectLibrarySong(client, message) {
  const room = getClientRoom(client);
  if (!room) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (room.persistent !== true) return sendError(client, 'LIBRARY_ONLY_IN_PERSISTENT_ROOM', '服务器曲库只对常驻房间开放。');
  if (room.hostPlayerId !== client.gameId) return sendError(client, 'HOST_ONLY', 'Only the current room host can select a song.');
  if (isRoundActive(room)) return sendError(client, 'SELECTION_LOCKED', 'Song selection is locked during a round.');
  const song = chooseLibrarySong(room.librarySelection, message);
  if (!song) return sendError(client, 'LIBRARY_SONG_NOT_FOUND', '当前常驻房间曲库范围内没有符合条件的歌曲。');
  const chart = chooseLibraryChart(room.librarySelection, song, message);
  if (!chart) return sendError(client, 'LIBRARY_CHART_NOT_FOUND', '当前常驻房间曲库范围内没有符合条件的谱面。');
  const packageRecord = songLibrary.packages.find(pack => pack.packageHash === song.packageHash);
  if (!packageRecord) return sendError(client, 'LIBRARY_PACKAGE_MISSING', '服务器曲库数据包不存在。');
  try { ensureFolderSongPackage(packageRecord); }
  catch (error) { return sendError(client, 'LIBRARY_PACKAGE_MISSING', error.message); }
  if (!packageRecord.path || !fs.existsSync(packageRecord.path)) return sendError(client, 'LIBRARY_PACKAGE_MISSING', '服务器曲库数据包不存在。');
  song.packageHash = packageRecord.packageHash;
  song.packageSize = packageRecord.packageSize;
  persistSongLibrary();
  selectSong(client, {
    songId: song.songId, songName: song.songName, artist: song.artist, chartPath: chart.chartPath,
    difficulty: chart.difficulty, level: chart.level, chartHash: chart.chartHash, designer: chart.designer,
    bpm: song.bpm, durationText: song.durationText, packageHash: song.packageHash, packageSize: song.packageSize,
    coverPath: song.coverPath, coverHash: song.coverHash, coverSize: song.coverSize
  }, { serverPackagePath: packageRecord.path });
}

function selectLibrarySongForRoom(room, message = {}) {
  if (!room || room.persistent !== true || isRoundActive(room)) return false;
  const song = chooseLibrarySong(room.librarySelection, message);
  if (!song) return false;
  const chart = chooseLibraryChart(room.librarySelection, song, message);
  const packageRecord = songLibrary.packages.find(pack => pack.packageHash === song.packageHash);
  if (!chart || !packageRecord) return false;
  try { ensureFolderSongPackage(packageRecord); } catch (_) { return false; }
  if (!packageRecord.path || !fs.existsSync(packageRecord.path)) return false;
  return selectSong(null, {
    songId: song.songId, songName: song.songName, artist: song.artist, chartPath: chart.chartPath,
    difficulty: chart.difficulty, level: chart.level, chartHash: chart.chartHash, designer: chart.designer,
    bpm: song.bpm, durationText: song.durationText, packageHash: packageRecord.packageHash,
    packageSize: packageRecord.packageSize, coverPath: song.coverPath, coverHash: song.coverHash,
    coverSize: song.coverSize
  }, { room, serverPackagePath: packageRecord.path, serverSelection: true });
}

function setSongSyncStatus(client, message) {
  const room = getClientRoom(client);
  if (!room) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (!room.song || message.packageHash !== room.song.packageHash)
    return sendError(client, 'SONG_SELECTION_CHANGED', 'The selected song changed.');
  if (isRoundActive(room)) return sendError(client, 'SYNC_NOT_ALLOWED_NOW', 'Song sync cannot change during a round.');
  const member = room.members.get(client.gameId);
  const progress = Math.max(0, Math.min(1, Number(message.progress) || 0));
  const songReady = message.ready === true;
  const nextProgress = songReady ? 1 : progress;
  const nextStatus = songReady ? 'unready' : (message.failed === true ? 'syncFailed' : 'syncing');
  // Clients may retry after room snapshots. Identical sync state is a no-op
  // so it cannot cause repeated broadcasts or consume the message budget.
  if (member.songReady === songReady && Math.abs(member.syncProgress - nextProgress) < 0.0001 &&
      member.status === nextStatus && message.failed !== true) return;
  member.songReady = songReady;
  member.syncProgress = nextProgress;
  member.ready = false;
  member.status = nextStatus;
  room.state = lobbyStateFor(room);
  room.updatedAt = now();
  broadcastRoomSnapshot(room);
}

function setTransferProgress(client, message) {
  const room = getClientRoom(client);
  if (!room || !room.song || !room.transfer) return sendError(client, 'NOT_IN_TRANSFER', 'There is no active song transfer.');
  const packageHash = typeof message.packageHash === 'string' ? message.packageHash.toLowerCase() : '';
  if (packageHash !== room.song.packageHash) return sendError(client, 'SONG_SELECTION_CHANGED', 'The selected song changed.');
  if (isRoundActive(room)) return sendError(client, 'SYNC_NOT_ALLOWED_NOW', 'Song sync cannot change during a round.');
  const direction = message.direction === 'upload' ? 'upload' : message.direction === 'download' ? 'download' : '';
  const state = message.state === 'started' || message.state === 'running' || message.state === 'completed' || message.state === 'failed'
    ? message.state : '';
  const progressValue = Number(message.progress);
  if (!direction || !state || !Number.isFinite(progressValue) || progressValue < 0 || progressValue > 1) {
    return sendError(client, 'INVALID_TRANSFER_PROGRESS', 'Transfer progress is invalid.');
  }
  if (direction === 'upload' && room.hostPlayerId !== client.gameId) {
    return sendError(client, 'HOST_ONLY', 'Only the current room host can upload the song package.');
  }
  if (direction === 'download' && ((room.hostPlayerId === client.gameId && room.transfer.direction !== 'server') || !room.transfer.ready)) {
    return sendError(client, 'DOWNLOAD_NOT_ALLOWED', 'Only members can download after the host upload is ready.');
  }
  const progress = Math.max(0, Math.min(1, progressValue));
  const member = room.members.get(client.gameId);
  if (!member) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (direction === 'upload') {
    room.transfer.uploadProgress = progress;
    room.transfer.direction = 'upload';
    room.transfer.state = state;
    room.song.transferProgress = progress;
    room.song.transferDirection = 'upload';
    room.song.transferState = state;
    room.song.transferPlayerId = client.gameId;
  } else {
    member.syncProgress = progress;
    member.status = state === 'failed' ? 'syncFailed' : state === 'completed' ? 'syncing' : 'syncing';
    room.song.transferProgress = progress;
    room.song.transferDirection = 'download';
    room.song.transferState = state;
    room.song.transferPlayerId = client.gameId;
  }
  room.updatedAt = now();
  broadcastRoom(room, {
    type: 'transferProgress',
    roomId: room.id,
    packageHash,
    playerId: client.gameId,
    playerName: client.name,
    direction,
    transferState: state,
    progress,
    serverTime: now()
  });
}

function setMemberBest(client, message) {
  const room = getClientRoom(client);
  if (!room || !room.song || message.packageHash !== room.song.packageHash) return;
  const member = room.members.get(client.gameId);
  member.bestScore = Math.max(0, Math.min(1010000, Number(message.score) || 0));
  member.bestRank = cleanText(message.rank, 16);
  room.updatedAt = now();
  broadcastRoomSnapshot(room);
}

function maybeBeginRound(room) {
  if (!room || isRoundActive(room) || !room.song) return;
  const members = Array.from(room.members.values());
  if (members.length === 0 || !members.every(member => member.ready && member.songReady)) return;
  room.roundId = randomHex(8);
  const roundId = room.roundId;
  room.state = 'readyCountdown';
  room.startAt = now() + 3000;
  room.updatedAt = now();
  for (const member of members) {
    member.loaded = false;
    member.exited = false;
    member.result = null;
    member.personalResultConfirmed = false;
    member.groupResultConfirmed = false;
    member.status = 'loading';
  }
  broadcastRoom(room, {
    type: 'readyCountdown', roomId: room.id, roundId,
    startAt: room.startAt, song: room.song, mods: room.mods,
    roomMode: room.mode, serverTime: now()
  });
  broadcastRoomSnapshot(room);
  setTimeout(() => {
    const active = rooms.get(room.id);
    if (!active || active.roundId !== roundId || active.state !== 'readyCountdown') return;
    const members = Array.from(active.members.values());
    if (members.length === 0 || !members.every(member => member.ready && member.songReady)) {
      active.roundId = null;
      active.startAt = 0;
      resetMemberReadiness(active);
      active.updatedAt = now();
      broadcastRoom(active, {
        type: 'roundCancelled', roomId: active.id,
        message: '准备状态发生变化，本局已取消。', serverTime: now()
      });
      broadcastRoomSnapshot(active);
      return;
    }
    active.state = 'loading';
    active.startAt = 0;
    active.updatedAt = now();
    broadcastRoom(active, {
      type: 'roundPreparing', roomId: active.id, roundId,
      song: active.song, mods: active.mods, roomMode: active.mode,
      serverTime: now()
    });
    broadcastRoomSnapshot(active);
  }, 3000).unref();
}

function startRound(client) {
  const room = getClientRoom(client);
  if (!room) return sendError(client, 'NOT_IN_ROOM', 'You are not in a room.');
  if (room.hostPlayerId !== client.gameId) return sendError(client, 'HOST_ONLY', 'Only the current room host can start a round.');
  maybeBeginRound(room);
}

function setRoundLoaded(client, message) {
  const room = getClientRoom(client);
  if (!room || room.state !== 'loading' || message.roundId !== room.roundId)
    return sendError(client, 'ROUND_NOT_LOADING', 'This round is not accepting loaded status.');
  const member = room.members.get(client.gameId);
  member.loaded = true;
  member.status = 'loaded';
  room.updatedAt = now();
  if (!Array.from(room.members.values()).every(value => value.loaded || value.exited)) {
    broadcastRoomSnapshot(room);
    return;
  }
  room.state = 'countdown';
  room.startAt = now() + 3000;
  const roundId = room.roundId;
  broadcastRoom(room, {
    type: 'roundStarting', roomId: room.id, roundId, startAt: room.startAt,
    song: room.song, mods: room.mods, roomMode: room.mode, serverTime: now()
  });
  broadcastRoomSnapshot(room);
  setTimeout(() => {
    const active = rooms.get(room.id);
    if (!active || active.roundId !== roundId || active.state !== 'countdown') return;
    active.state = 'playing';
    active.updatedAt = now();
    for (const activeMember of active.members.values())
      if (!activeMember.exited) activeMember.status = 'playing';
    broadcastRoom(active, { type: 'roundStarted', roomId: active.id, roundId: active.roundId, serverTime: now() });
    broadcastRoomSnapshot(active);
    broadcastRoomLists();
  }, Math.max(0, room.startAt - now())).unref();
}

function roundLoadFailed(client, message) {
  const room = getClientRoom(client);
  if (!room || room.state !== 'loading' || message.roundId !== room.roundId) return;
  const failedName = room.members.get(client.gameId)?.name || client.name;
  resetMemberReadiness(room);
  room.updatedAt = now();
  broadcastRoom(room, {
    type: 'roundCancelled', roomId: room.id,
    message: failedName + ' failed to load the selected song.', serverTime: now()
  });
  broadcastRoomSnapshot(room);
}

function rankForScore(score) {
  if (score >= 1009000) return 'SSS+';
  if (score >= 1007500) return 'SSS';
  if (score >= 1005000) return 'SS+';
  if (score >= 1000000) return 'SS';
  if (score >= 990000) return 'S+';
  if (score >= 975000) return 'S';
  if (score >= 950000) return 'AAA';
  if (score >= 925000) return 'AA';
  if (score >= 900000) return 'A';
  return 'B';
}

function validResultCount(value) {
  const number = Number(value);
  return Number.isSafeInteger(number) && number >= 0 && number <= 10000000 ? number : null;
}

function submitResult(client, message) {
  const room = getClientRoom(client);
  if (!room || !['countdown', 'playing'].includes(room.state) || message.roundId !== room.roundId)
    return sendError(client, 'ROUND_NOT_ACTIVE', 'This result does not belong to the active round.');
  const member = room.members.get(client.gameId);
  if (member.result || member.exited) return sendError(client, 'RESULT_ALREADY_SUBMITTED', 'A result was already submitted.');
  const jc = validResultCount(message.justiceCritical);
  const justice = validResultCount(message.justice);
  const attack = validResultCount(message.attack);
  const miss = validResultCount(message.miss);
  const maxCombo = validResultCount(message.maxCombo);
  if ([jc, justice, attack, miss, maxCombo].some(value => value === null))
    return sendError(client, 'INVALID_RESULT', 'Judgement counts are invalid.');
  const total = jc + justice + attack + miss;
  if (total <= 0) return sendError(client, 'INVALID_RESULT', 'The result has no judgement points.');
  const score = Math.max(0, Math.min(1010000,
    Math.round(1000000 * (jc + justice + attack * 0.5) / total + 10000 * jc / total)));
  if (Number.isFinite(Number(message.score)) && Math.abs(Number(message.score) - score) > 1)
    return sendError(client, 'RESULT_SCORE_MISMATCH', 'The score does not match the judgement counts.');
  member.result = {
    score,
    rank: rankForScore(score),
    justiceCritical: jc,
    justice,
    attack,
    miss,
    maxCombo,
    recordsScore: room.mode === 'normal',
    submittedAt: isoTime()
  };
  member.ready = false;
  member.status = 'personalResult';
  room.updatedAt = now();
  send(client, { type: 'resultAccepted', roomId: room.id, roundId: room.roundId, result: member.result, serverTime: now() });
  broadcastRoomSnapshot(room);
  const roomId = room.id;
  const roundId = room.roundId;
  setTimeout(() => autoConfirmPersonalResult(roomId, roundId, client.gameId), 10000).unref();
  maybeCompleteRound(room);
}

function exitRound(client) {
  const room = getClientRoom(client);
  if (!room || !['loading', 'countdown', 'playing'].includes(room.state))
    return sendError(client, 'ROUND_NOT_ACTIVE', 'There is no active round to exit.');
  const member = room.members.get(client.gameId);
  member.exited = true;
  member.loaded = true;
  member.ready = false;
  member.status = 'exited';
  member.personalResultConfirmed = true;
  send(client, { type: 'roundExited', roomId: room.id, roundId: room.roundId, serverTime: now() });
  room.updatedAt = now();
  broadcastRoomSnapshot(room);
  maybeCompleteRound(room);
}

function maybeCompleteRound(room) {
  if (!room || !room.roundId || !['loading', 'countdown', 'playing', 'personalResults'].includes(room.state)) return;
  const members = Array.from(room.members.values());
  if (!members.every(member => member.result || member.exited)) return;
  room.state = 'personalResults';
  room.updatedAt = now();
  broadcastRoom(room, { type: 'allPlayersFinished', roomId: room.id, roundId: room.roundId, serverTime: now() });
  broadcastRoomSnapshot(room);
  maybeShowGroupResults(room);
}

function confirmPersonalResult(client) {
  const room = getClientRoom(client);
  if (!room || !room.roundId) return sendError(client, 'ROUND_NOT_ACTIVE', 'There is no round result to confirm.');
  const member = room.members.get(client.gameId);
  if (!member.result && !member.exited) return sendError(client, 'RESULT_NOT_READY', 'Finish the round first.');
  member.personalResultConfirmed = true;
  member.status = 'waitingResults';
  room.updatedAt = now();
  broadcastRoomSnapshot(room);
  maybeShowGroupResults(room);
}

function autoConfirmPersonalResult(roomId, roundId, gameId) {
  const room = rooms.get(roomId);
  if (!room || room.roundId !== roundId) return;
  const member = room.members.get(gameId);
  if (!member || (!member.result && !member.exited) || member.personalResultConfirmed) return;
  member.personalResultConfirmed = true;
  member.status = 'waitingResults';
  broadcastRoomSnapshot(room);
  maybeShowGroupResults(room);
}

function maybeShowGroupResults(room) {
  const members = Array.from(room.members.values());
  if (!members.every(member => (member.result || member.exited) && member.personalResultConfirmed)) return;
  if (room.state === 'groupResults') return;
  room.state = 'groupResults';
  room.updatedAt = now();
  for (const member of members) {
    member.groupResultConfirmed = false;
    member.status = 'groupResult';
  }
  const leaderboard = roomLeaderboard(room);
  broadcastRoom(room, {
    type: 'groupResultsAvailable', roomId: room.id, roundId: room.roundId,
    song: room.song, leaderboard, serverTime: now()
  });
  broadcastRoomSnapshot(room);
  const roomId = room.id;
  const roundId = room.roundId;
  setTimeout(() => {
    const active = rooms.get(roomId);
    if (active && active.roundId === roundId && active.state === 'groupResults') returnRoomToLobby(active);
  }, 10000).unref();
}

function confirmGroupResult(client) {
  const room = getClientRoom(client);
  if (!room || room.state !== 'groupResults') return sendError(client, 'GROUP_RESULT_NOT_READY', 'Group results are not ready.');
  const member = room.members.get(client.gameId);
  member.groupResultConfirmed = true;
  member.status = 'waitingLobby';
  room.updatedAt = now();
  broadcastRoomSnapshot(room);
  if (Array.from(room.members.values()).every(value => value.groupResultConfirmed)) returnRoomToLobby(room);
}

function returnRoomToLobby(room) {
  const previousHost = room.hostPlayerId;
  if (room.selectionMode === 'loop' && room.members.size > 1) {
    const ids = Array.from(room.members.keys());
    const currentIndex = Math.max(0, ids.indexOf(room.hostPlayerId));
    room.hostPlayerId = ids[(currentIndex + 1) % ids.length];
  } else if (!room.members.has(room.hostPlayerId)) room.hostPlayerId = room.ownerPlayerId;
  resetMemberReadiness(room);
  room.updatedAt = now();
  if (previousHost !== room.hostPlayerId) {
    const next = room.members.get(room.hostPlayerId);
    broadcastRoom(room, {
      type: 'hostChanged', roomId: room.id, hostPlayerId: room.hostPlayerId,
      hostName: next ? next.name : 'unknown', reason: 'selection rotation', serverTime: now()
    });
  }
  broadcastRoom(room, { type: 'returnedToLobby', roomId: room.id, room: roomSnapshot(room), serverTime: now() });
  broadcastRoomSnapshot(room);
  broadcastRoomLists();
}

function setClientAppState(client, message) {
  if (message.state === 'background') client.backgroundAt = now();
  else if (message.state === 'active') client.backgroundAt = null;
  else return sendError(client, 'INVALID_APP_STATE', 'App state must be active or background.');
  send(client, {
    type: 'appStateAccepted',
    state: message.state,
    backgroundTimeoutMinutes: config.backgroundTimeoutMinutes,
    serverTime: now()
  });
}

function handleHello(client, message) {
  if (client.hello) return sendError(client, 'ALREADY_AUTHENTICATED', 'Hello was already completed.');
  if (Number(message.protocol) !== PROTOCOL_VERSION) {
    return sendError(client, 'PROTOCOL_MISMATCH', `Supported protocol version is ${PROTOCOL_VERSION}.`);
  }
  if (config.authToken && message.authToken !== config.authToken) {
    closeClient(client, 1008, 'Authentication failed');
    return;
  }
  if (!validDeviceId(message.deviceId)) {
    return sendError(client, 'DEVICE_ID_REQUIRED', 'A stable device ID is required to receive a game ID.');
  }
  if (message.legacyDeviceId !== undefined && message.legacyDeviceId !== '' && !validDeviceId(message.legacyDeviceId)) {
    return sendError(client, 'INVALID_LEGACY_DEVICE_ID', 'The legacy device ID is invalid.');
  }
  if (!validName(message.playerName)) {
    return sendError(client, 'INVALID_PLAYER_NAME', 'Player name must contain 1 to 6 Chinese or English characters.');
  }
  client.clientVersion = cleanText(message.clientVersion, 32);
  if (!client.clientVersion) {
    return sendError(client, 'CLIENT_VERSION_REQUIRED', 'The client version is required.');
  }
  client.name = message.playerName;
  const identity = issueGameIdentity(message.deviceId, client, message.legacyDeviceId);
  if (identity.error) return sendError(client, identity.error.code, identity.error.message);
  const gameId = identity.gameId;
  if (Object.prototype.hasOwnProperty.call(serverState.blockedGameIds, gameId)) {
    audit('blockedConnectionRejected', { gameId });
    sendError(client, 'GAME_ID_BLOCKED', 'This game ID has been blocked by the server administrator.');
    closeClient(client, 1008, 'Game ID blocked');
    return;
  }
  const identityRecord = getDeviceRecord(gameId);
  const cooldownUntil = Number(identityRecord?.lobbyReentryCooldownUntil || 0);
  if (cooldownUntil > now()) {
    const remainingSeconds = Math.max(1, Math.ceil((cooldownUntil - now()) / 1000));
    sendError(client, 'LOBBY_REENTRY_COOLDOWN', '退出联机大厅后请等待倒计时结束再进入。', {
      remainingSeconds,
      cooldownUntil
    });
    closeClient(client, 1008, 'Lobby re-entry cooldown');
    return;
  }
  if (identityRecord && identityRecord.lobbyReentryCooldownUntil) {
    delete identityRecord.lobbyReentryCooldownUntil;
    persistServerState();
  }
  const existing = activeGameIds.get(gameId);
  if (existing && !existing.closed) {
    sendError(client, 'GAME_ID_ALREADY_ONLINE', 'This game ID already has an active connection.');
    closeClient(client, 1008, 'Game ID already online');
    return;
  }
  const nameUpdate = rememberPlayerName(identityRecord, client.name);
  if (nameUpdate.changed) {
    audit('playerNameChanged', {
      gameId,
      previousPlayerName: nameUpdate.previous || null,
      playerName: client.name
    });
  }
  client.hello = true;
  client.gameId = gameId;
  identityRecord.lastLoginAt = isoTime();
  activeGameIds.set(gameId, client);
  persistServerState();
  client.sessionToken = randomHex(32);
  send(client, {
    type: 'helloAccepted',
    protocol: PROTOCOL_VERSION,
    serverVersion: SERVER_VERSION,
    gameId,
    playerId: gameId,
    sessionToken: client.sessionToken,
    serverTime: now(),
    capabilities: {
      roomModes: ['casual', 'normal'],
      selectionModes: ['host', 'loop'],
      maxPlayers: config.maxPlayersPerRoom,
      personalRoomMaxPlayers: PERSONAL_ROOM_MAX_PLAYERS,
      persistentRoomMaxPlayers: Math.min(PERSISTENT_ROOM_MAX_PLAYERS, config.maxPlayersPerRoom),
      kick: true,
      kickCooldownSeconds: 60,
      hostTransfer: true,
      hiddenRooms: true,
      passwordRooms: true,
      fileTransfer: true,
      transferProgress: true,
      gameplaySync: true,
      serverIssuedGameId: true,
      oneActiveRoomPerGameId: true,
      idleTimeout: true,
      sameClientVersionPerRoom: true,
      dailyRoomQuota: true,
      roomListFilters: true,
      roomTypes: ['personal', 'persistent'],
      persistentRooms: true,
      persistentRoomIdDigits: 3,
      persistentRoomNameMaxLength: 15,
      persistentSelectionManaged: true,
      persistentRandomCountZeroLoop: true,
      serverSongLibrary: true,
      persistentRoomLibrarySelection: true,
      songChangeVote: true,
      songChangeVoteRatio: config.songChangeVoteRequiredRatio,
      lobbyReentryCooldown: true,
      fullChartAutoInMultiplayer: false
    },
    idlePolicy: idlePolicy(),
    quota: quotaStatus(gameId)
  });
  sendRoomList(client);
  audit('gameIdConnected', { gameId, clientVersion: client.clientVersion });
  console.log(`[client] connected ${client.name} gameId=${gameId} ip=${client.ip}`);
}

function handleMessage(client, message) {
  if (!message || typeof message !== 'object' || Array.isArray(message) || typeof message.type !== 'string') {
    return sendError(client, 'INVALID_MESSAGE', 'Message must be a JSON object with a type.');
  }
  if (!client.hello) {
    if (message.type !== 'hello') return sendError(client, 'HELLO_REQUIRED', 'Send hello before other messages.');
    return handleHello(client, message);
  }
  switch (message.type) {
    case 'listRooms':
      return sendRoomList(client, message.search, message.roomId, {
        idleOnly: message.idleOnly,
        notFullOnly: message.notFullOnly,
        unencryptedOnly: message.unencryptedOnly,
        mode: message.mode,
        roomType: message.roomType
      });
    case 'reserveRoomId':
      return reserveRoomId(client);
    case 'releaseRoomId':
      return releaseReservedRoomId(client);
    case 'createRoom':
      return createRoom(client, message);
    case 'joinRoom':
      return joinRoom(client, message);
    case 'leaveRoom':
      return leaveRoom(client);
    case 'leaveLobby':
      return leaveLobby(client);
    case 'setReady':
      return setReady(client, message);
    case 'updateRoomSettings':
      return updateRoomSettings(client, message);
    case 'selectSong':
      return selectSong(client, message);
    case 'listLibrarySongs':
      return listLibrarySongs(client, message);
    case 'selectLibrarySong':
    case 'requestRandomLibrarySong':
      return selectLibrarySong(client, message);
    case 'requestSongChangeVote':
      return requestSongChangeVote(client);
    case 'castSongChangeVote':
      return castSongChangeVote(client);
    case 'setSongSyncStatus':
      return setSongSyncStatus(client, message);
    case 'setMemberBest':
      return setMemberBest(client, message);
    case 'startRound':
      return startRound(client);
    case 'setRoundLoaded':
      return setRoundLoaded(client, message);
    case 'roundLoadFailed':
      return roundLoadFailed(client, message);
    case 'exitRound':
      return exitRound(client);
    case 'submitResult':
      return submitResult(client, message);
    case 'confirmPersonalResult':
      return confirmPersonalResult(client);
    case 'confirmGroupResult':
      return confirmGroupResult(client);
    case 'appState':
      return setClientAppState(client, message);
    case 'kickPlayer':
      return kickFromRoom(client, message.playerId);
    case 'transferHost':
      return transferRoomHost(client, message.playerId);
    case 'transferProgress':
      return setTransferProgress(client, message);
    case 'ping':
      return send(client, { type: 'pong', clientTime: message.clientTime, serverTime: now() });
    default:
      return sendError(client, 'UNKNOWN_MESSAGE', `Unknown message type: ${message.type}`);
  }
}

function consumeFrames(client) {
  while (client.buffer.length >= 2 && !client.closed) {
    const first = client.buffer[0];
    const second = client.buffer[1];
    const fin = (first & 0x80) !== 0;
    const rsv = first & 0x70;
    const opcode = first & 0x0f;
    const masked = (second & 0x80) !== 0;
    let payloadLength = second & 0x7f;
    let headerLength = 2;
    if (!fin || rsv !== 0 || !masked || (opcode !== 0x1 && opcode !== 0x8 && opcode !== 0x9 && opcode !== 0xA)) {
      return closeClient(client, 1002, 'Unsupported WebSocket frame');
    }
    if (payloadLength === 126) {
      if (client.buffer.length < 4) return;
      payloadLength = client.buffer.readUInt16BE(2);
      headerLength = 4;
    } else if (payloadLength === 127) {
      if (client.buffer.length < 10) return;
      const largeLength = client.buffer.readBigUInt64BE(2);
      if (largeLength > BigInt(config.maxMessageBytes)) return closeClient(client, 1009, 'Message too large');
      payloadLength = Number(largeLength);
      headerLength = 10;
    }
    if (payloadLength > config.maxMessageBytes) return closeClient(client, 1009, 'Message too large');
    const frameLength = headerLength + 4 + payloadLength;
    if (client.buffer.length < frameLength) return;
    const mask = client.buffer.subarray(headerLength, headerLength + 4);
    const encoded = client.buffer.subarray(headerLength + 4, frameLength);
    const payload = Buffer.alloc(payloadLength);
    for (let index = 0; index < payloadLength; index += 1) payload[index] = encoded[index] ^ mask[index % 4];
    client.buffer = client.buffer.subarray(frameLength);

    if (opcode === 0x8) return closeClient(client, 1000, '');
    if (opcode === 0x9) {
      client.socket.write(makeFrame(payload, 0xA));
      continue;
    }
    if (opcode === 0xA) {
      client.alive = true;
      continue;
    }
    const current = now();
    if (current - client.lastMessageWindow >= 10000) {
      client.lastMessageWindow = current;
      client.messageCount = 0;
    }
    client.messageCount += 1;
    if (client.messageCount > config.messagesPer10Seconds) return closeClient(client, 1008, 'Rate limit exceeded');
    let message;
    try {
      message = JSON.parse(payload.toString('utf8'));
    } catch (_) {
      sendError(client, 'INVALID_JSON', 'Message payload must be valid JSON.');
      continue;
    }
    if (message && typeof message === 'object' && MEANINGFUL_ACTIVITY_TYPES.has(message.type)) {
      client.lastActivityAt = current;
      client.idleWarningSent = false;
    }
    handleMessage(client, message);
  }
}

function normalizeIp(value) {
  if (!value) return 'unknown';
  return value.startsWith('::ffff:') ? value.substring(7) : value;
}

function canAcceptIp(ip) {
  return (ipConnectionCounts.get(ip) || 0) < config.maxConnectionsPerIp;
}

function incrementIp(ip) {
  ipConnectionCounts.set(ip, (ipConnectionCounts.get(ip) || 0) + 1);
}

function decrementIp(ip) {
  const next = (ipConnectionCounts.get(ip) || 1) - 1;
  if (next <= 0) ipConnectionCounts.delete(ip);
  else ipConnectionCounts.set(ip, next);
}

function attachClient(socket, ip, initialData) {
  const client = {
    id: randomHex(12),
    name: '',
    ip,
    socket,
    buffer: Buffer.alloc(0),
    hello: false,
    closed: false,
    alive: true,
    connectedAt: now(),
    lastActivityAt: now(),
    idleWarningSent: false,
    lastMessageWindow: now(),
    messageCount: 0,
    roomId: null,
    roomListSearch: '',
    roomListId: '',
    roomListFilters: { idleOnly: false, notFullOnly: false, unencryptedOnly: false, mode: '', roomType: '' },
    gameId: null,
    sessionToken: null,
    reservedRoomId: null,
    backgroundAt: null
  };
  clients.add(client);
  incrementIp(ip);
  socket.setNoDelay(true);
  socket.setKeepAlive(true, 30000);
  socket.on('data', data => {
    if (client.closed) return;
    client.buffer = Buffer.concat([client.buffer, data]);
    if (client.buffer.length > config.maxMessageBytes * 2) return closeClient(client, 1009, 'Message buffer too large');
    consumeFrames(client);
  });
  socket.on('error', () => closeClient(client, 1001, 'Socket error'));
  socket.on('close', () => {
    if (!client.closed) client.closed = true;
    releaseRoomReservation(client);
    removeFromRoom(client, 'disconnected', true);
    if (client.gameId && activeGameIds.get(client.gameId) === client) {
      activeGameIds.delete(client.gameId);
      const record = getDeviceRecord(client.gameId);
      if (record) {
        record.lastSeen = isoTime();
        record.lastIp = client.ip;
      }
      persistServerState();
    }
    clients.delete(client);
    decrementIp(ip);
    if (client.hello) console.log(`[client] disconnected ${client.name} gameId=${client.gameId}`);
  });
  if (initialData && initialData.length > 0) {
    client.buffer = Buffer.from(initialData);
    consumeFrames(client);
  }
  return client;
}

function jsonResponse(response, status, value) {
  const body = JSON.stringify(value);
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  response.end(body);
}

function transferClientFromRequest(request) {
  const authorization = request.headers.authorization;
  if (typeof authorization !== 'string' || !authorization.startsWith('Bearer ')) return null;
  const token = authorization.substring(7);
  if (!/^[a-f0-9]{64}$/i.test(token)) return null;
  for (const client of clients) {
    if (client.hello && !client.closed && client.sessionToken === token) return client;
  }
  return null;
}

function transferRoute(pathname) {
  const match = /^\/api\/v1\/transfers\/(\d{6})\/([a-f0-9]{64})$/i.exec(pathname);
  return match ? { roomId: match[1], packageHash: match[2].toLowerCase() } : null;
}

function handleTransferUpload(request, response, client, room, packageHash) {
  if (room.hostPlayerId !== client.gameId) {
    request.resume();
    return jsonResponse(response, 403, { error: 'host_only' });
  }
  if (!room.song || room.song.packageHash !== packageHash || !room.transfer) {
    request.resume();
    return jsonResponse(response, 409, { error: 'song_selection_changed' });
  }
  const transfer = room.transfer;
  if (transfer.uploading) {
    request.resume();
    return jsonResponse(response, 409, { error: 'upload_in_progress' });
  }
  const contentLengthHeader = request.headers['content-length'];
  const contentLength = contentLengthHeader === undefined ? null : Number(contentLengthHeader);
  if (contentLength !== null && (!Number.isSafeInteger(contentLength) || contentLength !== transfer.expectedSize)) {
    request.resume();
    return jsonResponse(response, 400, { error: 'content_length_mismatch', expectedSize: transfer.expectedSize });
  }

  const temporaryPath = path.join(TRANSFER_DIR, `${room.id}-${packageHash}-${randomHex(6)}.part`);
  const finalPath = path.join(TRANSFER_DIR, `${room.id}-${packageHash}.zip`);
  const digest = crypto.createHash('sha256');
  const output = fs.createWriteStream(temporaryPath, { flags: 'wx', mode: 0o600 });
  let bytes = 0;
  let requestEnded = false;
  let settled = false;
  transfer.uploading = true;

  const fail = (status, error) => {
    if (settled) return;
    settled = true;
    if (room.transfer === transfer) transfer.uploading = false;
    request.removeAllListeners('data');
    request.resume();
    output.destroy();
    try { fs.unlinkSync(temporaryPath); } catch (_) { /* best effort */ }
    if (!response.writableEnded) jsonResponse(response, status, { error });
  };

  output.on('error', () => fail(500, 'transfer_write_failed'));
  output.on('drain', () => request.resume());
  output.on('finish', () => {
    if (settled || !requestEnded) return;
    if (bytes !== transfer.expectedSize) return fail(400, 'transfer_size_mismatch');
    const actualHash = digest.digest('hex');
    if (actualHash !== packageHash) return fail(400, 'transfer_hash_mismatch');
    const activeRoom = rooms.get(room.id);
    if (!activeRoom || activeRoom.transfer !== transfer || !activeRoom.song || activeRoom.song.packageHash !== packageHash) {
      return fail(409, 'song_selection_changed');
    }
    try {
      try { fs.unlinkSync(finalPath); } catch (_) { /* no existing transfer */ }
      fs.renameSync(temporaryPath, finalPath);
    } catch (_) {
      return fail(500, 'transfer_commit_failed');
    }
    settled = true;
    transfer.uploading = false;
    transfer.path = finalPath;
    transfer.size = bytes;
    transfer.ready = true;
    transfer.uploadProgress = 1;
    transfer.direction = 'upload';
    transfer.state = 'completed';
    transfer.uploadedAt = now();
    transfer.lastAccessAt = transfer.uploadedAt;
    activeRoom.song.transferReady = true;
    activeRoom.song.transferProgress = 1;
    activeRoom.song.transferDirection = 'upload';
    activeRoom.song.transferState = 'completed';
    activeRoom.song.transferPlayerId = client.gameId;
    activeRoom.updatedAt = now();
    broadcastRoom(activeRoom, {
      type: 'transferReady',
      roomId: activeRoom.id,
      packageHash,
      packageSize: bytes,
      downloadPath: activeRoom.song.downloadPath,
      serverTime: now()
    });
    broadcastRoomSnapshot(activeRoom);
    audit('songPackageUploaded', { roomId: activeRoom.id, gameId: client.gameId, packageHash, bytes });
    jsonResponse(response, 201, { ok: true, roomId: activeRoom.id, packageHash, size: bytes });
  });
  request.on('aborted', () => fail(400, 'upload_aborted'));
  request.on('error', () => fail(400, 'upload_failed'));
  request.on('data', chunk => {
    if (settled) return;
    bytes += chunk.length;
    if (bytes > transfer.expectedSize || bytes > config.maxTransferBytes) return fail(413, 'transfer_too_large');
    digest.update(chunk);
    if (!output.write(chunk)) request.pause();
  });
  request.on('end', () => {
    if (settled) return;
    requestEnded = true;
    output.end();
  });
}

function handleTransferDownload(request, response, room, packageHash) {
  const transfer = room.transfer;
  if (!room.song || room.song.packageHash !== packageHash || !transfer || !transfer.ready || !transfer.path) {
    return jsonResponse(response, 404, { error: 'transfer_not_ready' });
  }
  let stat;
  try {
    stat = fs.statSync(transfer.path);
  } catch (_) {
    transfer.ready = false;
    transfer.path = null;
    room.song.transferReady = false;
    return jsonResponse(response, 404, { error: 'transfer_missing' });
  }
  let start = 0;
  let end = stat.size - 1;
  let status = 200;
  const rangeHeader = request.headers.range;
  if (typeof rangeHeader === 'string') {
    const match = /^bytes=(\d+)-(\d*)$/.exec(rangeHeader.trim());
    if (!match) {
      response.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
      return response.end();
    }
    start = Number(match[1]);
    end = match[2] ? Number(match[2]) : end;
    if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end < start || start >= stat.size) {
      response.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
      return response.end();
    }
    end = Math.min(end, stat.size - 1);
    status = 206;
  }
  const headers = {
    'Content-Type': 'application/zip',
    'Content-Length': end - start + 1,
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'private, no-store',
    'X-Content-Type-Options': 'nosniff',
    'Content-Disposition': `attachment; filename="multiplayer-${room.id}.zip"`
  };
  if (status === 206) headers['Content-Range'] = `bytes ${start}-${end}/${stat.size}`;
  response.writeHead(status, headers);
  transfer.lastAccessAt = now();
  if (request.method === 'HEAD') return response.end();
  const input = fs.createReadStream(transfer.path, { start, end });
  input.on('error', () => response.destroy());
  input.pipe(response);
}

function handleTransferRequest(request, response, route) {
  const client = transferClientFromRequest(request);
  if (!client) {
    request.resume();
    return jsonResponse(response, 401, { error: 'transfer_unauthorized' });
  }
  const room = rooms.get(route.roomId);
  if (!room || client.roomId !== room.id || !room.members.has(client.gameId)) {
    request.resume();
    return jsonResponse(response, 403, { error: 'room_membership_required' });
  }
  if (request.method === 'POST') return handleTransferUpload(request, response, client, room, route.packageHash);
  if (request.method === 'GET' || request.method === 'HEAD') return handleTransferDownload(request, response, room, route.packageHash);
  request.resume();
  return jsonResponse(response, 405, { error: 'method_not_allowed' });
}

function handleHttp(request, response) {
  const requestUrl = new URL(request.url, 'http://localhost');
  const transfer = transferRoute(requestUrl.pathname);
  if (transfer) return handleTransferRequest(request, response, transfer);
  if (request.method === 'GET' && requestUrl.pathname === '/admin-v2') {
    if (!isAdminNetworkAllowed(request)) return jsonResponse(response, 403, { error: 'admin_local_only' });
    const adminPath = path.join(__dirname, 'admin-v2.html');
    if (!fs.existsSync(adminPath)) return jsonResponse(response, 404, { error: 'admin_page_missing' });
    const body = fs.readFileSync(adminPath);
    response.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Length': body.length,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'"
    });
    return response.end(body);
  }
  if (request.method === 'GET' && requestUrl.pathname === '/admin') {
    if (!isAdminNetworkAllowed(request)) return jsonResponse(response, 403, { error: 'admin_local_only' });
    const adminPath = path.join(__dirname, 'admin.html');
    if (!fs.existsSync(adminPath)) return jsonResponse(response, 404, { error: 'admin_page_missing' });
    const body = fs.readFileSync(adminPath);
    response.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Length': body.length,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'"
    });
    return response.end(body);
  }
  if (request.method === 'POST' && requestUrl.pathname === '/admin/api/login') {
    if (!isAdminNetworkAllowed(request)) return jsonResponse(response, 403, { error: 'admin_local_only' });
    return readJsonBody(request).then(result => {
      if (result.error) return jsonResponse(response, 400, { error: result.error });
      const credential = result.body?.credential;
      if (!isAdminRequestLoopback(request) && credential === adminToken)
        return jsonResponse(response, 401, { error: 'admin_password_required_for_remote_login' });
      if (!verifyAdminCredential(credential)) return jsonResponse(response, 401, { error: 'admin_invalid_credential' });
      const session = createAdminSession();
      audit('adminLogin', { method: credential === adminToken ? 'startupToken' : 'password' });
      return jsonResponse(response, 200, { ok: true, sessionToken: session.token, expiresAt: session.expiresAt, passwordEnabled: Boolean(security.adminPassword) });
    });
  }
  if (requestUrl.pathname.startsWith('/admin/api/')) {
    if (!isAdminAuthorized(request)) return jsonResponse(response, 401, { error: 'admin_unauthorized' });
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/security')
      return jsonResponse(response, 200, { passwordEnabled: Boolean(security.adminPassword), adminLocalOnly: config.adminLocalOnly, sessionHours: 12, serverTime: now() });
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/security/network-access') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const allowRemote = result.body?.allowRemote === true;
        if (allowRemote && !security.adminPassword)
          return jsonResponse(response, 400, { error: 'admin_password_required_for_remote_access' });
        config.adminLocalOnly = !allowRemote;
        const disk = readJsonFile(path.join(__dirname, 'config.json'), {});
        disk.adminLocalOnly = config.adminLocalOnly;
        writeJsonFile(path.join(__dirname, 'config.json'), disk);
        audit('adminNetworkAccessUpdated', { allowRemote });
        return jsonResponse(response, 200, { ok: true, adminLocalOnly: config.adminLocalOnly, serverTime: now() });
      });
    }
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/tls') {
      const proxyMode = !config.tls.enabled && config.host === '127.0.0.1' && Boolean(config.tls.domain);
      return jsonResponse(response, 200, { tls: { ...config.tls }, host: config.host, port: config.port, proxyMode, scheme: config.tls.enabled || proxyMode ? 'wss' : 'ws', serverTime: now() });
    }
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/wss/check') {
      return inspectWssConfiguration(requestUrl.searchParams.get('domain')).then(result =>
        jsonResponse(response, 200, result));
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/tls/save') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const body = result.body || {};
        const proxyMode = body.proxyMode === true;
        const enabled = body.enabled === true && !proxyMode;
        const keyPath = typeof body.keyPath === 'string' ? body.keyPath.trim().slice(0, 260) : config.tls.keyPath;
        const certPath = typeof body.certPath === 'string' ? body.certPath.trim().slice(0, 260) : config.tls.certPath;
        if (enabled && (!keyPath || !certPath)) return jsonResponse(response, 400, { error: 'tls_certificate_paths_required' });
        const domain = typeof body.domain === 'string' ? body.domain.trim().slice(0, 253) : '';
        config.tls = { enabled, domain, keyPath: keyPath || 'certs/server.key', certPath: certPath || 'certs/server.crt' };
        const disk = readJsonFile(path.join(__dirname, 'config.json'), {});
        disk.tls = config.tls;
        if (proxyMode) {
          config.host = '127.0.0.1';
          disk.host = config.host;
        }
        writeJsonFile(path.join(__dirname, 'config.json'), disk);
        audit('tlsConfigUpdated', { enabled, proxyMode, domain, keyPath, certPath });
        return jsonResponse(response, 200, { ok: true, restartRequired: true, proxyMode, tls: config.tls });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/security/password') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const enabled = result.body?.enabled !== false;
        if (!enabled) {
          security.adminPassword = null;
          writeJsonFile(SECURITY_PATH, security);
          adminSessions.clear();
          audit('adminPasswordDisabled', {});
          return jsonResponse(response, 200, { ok: true, passwordEnabled: false, loginRequired: true });
        }
        const password = result.body?.password;
        if (typeof password !== 'string' || password.length < 8 || password.length > 128)
          return jsonResponse(response, 400, { error: 'admin_password_must_be_8_to_128_characters' });
        security.adminPassword = hashPassword(password);
        writeJsonFile(SECURITY_PATH, security);
        adminSessions.clear();
        audit('adminPasswordUpdated', {});
        return jsonResponse(response, 200, { ok: true, passwordEnabled: true, loginRequired: true });
      });
    }
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/settings') {
      return jsonResponse(response, 200, {
        idlePolicy: idlePolicy(),
        songChangeVoteRequiredRatio: config.songChangeVoteRequiredRatio,
        songChangeVoteRequiredPercent: Math.round(config.songChangeVoteRequiredRatio * 100),
        serverTime: now()
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/settings/song-change-vote') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const value = Number(result.body?.requiredRatio ?? (Number(result.body?.requiredPercent) / 100));
        if (!Number.isFinite(value) || value < 0.1 || value > 1)
          return jsonResponse(response, 400, { error: 'vote_ratio_must_be_between_10_and_100_percent' });
        config.songChangeVoteRequiredRatio = Math.round(value * 1000) / 1000;
        const disk = readJsonFile(path.join(__dirname, 'config.json'), {});
        disk.songChangeVoteRequiredRatio = config.songChangeVoteRequiredRatio;
        writeJsonFile(path.join(__dirname, 'config.json'), disk);
        for (const room of rooms.values()) {
          room.songChangeVoteRequiredRatio = config.songChangeVoteRequiredRatio;
          if (room.songChangeVoteActive) broadcastRoomSnapshot(room);
        }
        audit('songChangeVoteRatioUpdated', { requiredRatio: config.songChangeVoteRequiredRatio });
        return jsonResponse(response, 200, {
          ok: true,
          songChangeVoteRequiredRatio: config.songChangeVoteRequiredRatio,
          songChangeVoteRequiredPercent: Math.round(config.songChangeVoteRequiredRatio * 100),
          serverTime: now()
        });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/settings/idle') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const body = result.body || {};
        const idleClientMinutes = integerInRange(body.idleClientMinutes, 5, 24 * 60, -1);
        const idleWarningSeconds = integerInRange(body.idleWarningSeconds, 15, 300, -1);
        const backgroundTimeoutMinutes = integerInRange(body.backgroundTimeoutMinutes, 1, 60, -1);
        if (idleClientMinutes < 0 || idleWarningSeconds < 0 || backgroundTimeoutMinutes < 0)
          return jsonResponse(response, 400, { error: 'invalid_idle_policy' });
        if (idleWarningSeconds >= idleClientMinutes * 60)
          return jsonResponse(response, 400, { error: 'idle_warning_must_be_shorter_than_timeout' });
        config.idleClientMinutes = idleClientMinutes;
        config.idleWarningSeconds = idleWarningSeconds;
        config.backgroundTimeoutMinutes = backgroundTimeoutMinutes;
        const disk = readJsonFile(path.join(__dirname, 'config.json'), {});
        disk.idleClientMinutes = idleClientMinutes;
        disk.idleWarningSeconds = idleWarningSeconds;
        disk.backgroundTimeoutMinutes = backgroundTimeoutMinutes;
        writeJsonFile(path.join(__dirname, 'config.json'), disk);
        audit('idlePolicyUpdated', idlePolicy());
        return jsonResponse(response, 200, { ok: true, idlePolicy: idlePolicy(), restartRequired: false, serverTime: now() });
      });
    }
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/overview')
      return jsonResponse(response, 200, adminOverview());
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/devices')
      return jsonResponse(response, 200, { devices: adminDeviceViews(), serverTime: now() });
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/rooms')
      return jsonResponse(response, 200, { rooms: adminRoomViews(), serverTime: now() });
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/rooms/persistent') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const created = createPersistentRoomFromAdmin(result.body || {});
        if (created.error) return jsonResponse(response, 400, created.error);
        return jsonResponse(response, 201, { ok: true, room: created.room, serverTime: now() });
      });
    }
    const persistentRoomMatch = /^\/admin\/api\/rooms\/persistent\/(\d{3}|\d{6})$/.exec(requestUrl.pathname);
    if (persistentRoomMatch && request.method === 'PATCH') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const updated = updatePersistentRoomFromAdmin(persistentRoomMatch[1], result.body || {});
        if (updated.error) return jsonResponse(response, 400, updated.error);
        return jsonResponse(response, 200, { ok: true, room: updated.room, serverTime: now() });
      });
    }
    if (persistentRoomMatch && request.method === 'DELETE') {
      const deleted = deletePersistentRoomFromAdmin(persistentRoomMatch[1]);
      if (deleted.error) return jsonResponse(response, 400, deleted.error);
      return jsonResponse(response, 200, { ok: true, roomId: deleted.roomId, serverTime: now() });
    }
    const persistentRoomSongMatch = /^\/admin\/api\/rooms\/persistent\/(\d{3}|\d{6})\/song$/.exec(requestUrl.pathname);
    if (persistentRoomSongMatch && request.method === 'POST') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const selected = selectPersistentRoomSongFromAdmin(persistentRoomSongMatch[1], result.body || {});
        if (selected.error) return jsonResponse(response, 400, selected.error);
        return jsonResponse(response, 200, { ok: true, room: selected.room, serverTime: now() });
      });
    }
    const persistentRoomKickMatch = /^\/admin\/api\/rooms\/persistent\/(\d{3}|\d{6})\/kick$/.exec(requestUrl.pathname);
    if (persistentRoomKickMatch && request.method === 'POST') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const kicked = kickPersistentRoomMemberFromAdmin(persistentRoomKickMatch[1], result.body?.gameId);
        if (kicked.error) return jsonResponse(response, 400, kicked.error);
        return jsonResponse(response, 200, { ok: true, room: kicked.room, serverTime: now() });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/song-library/staging') {
      const session = createSongLibrarySession();
      return jsonResponse(response, 201, { ok: true, session: songLibrarySessionView(session), serverTime: now() });
    }
    const stagingScanMatch = /^\/admin\/api\/song-library\/staging\/([^/]+)\/scan$/.exec(requestUrl.pathname);
    if (stagingScanMatch && request.method === 'POST') {
      const result = scanSongLibrarySession(stagingScanMatch[1]);
      if (result.error) return jsonResponse(response, result.error.code === 'PACKAGE_IN_USE' ? 409 : 400, result.error);
      return jsonResponse(response, 200, result);
    }
    const stagingDeleteMatch = /^\/admin\/api\/song-library\/staging\/([^/]+)$/.exec(requestUrl.pathname);
    if (stagingDeleteMatch && request.method === 'DELETE') {
      const session = songLibrarySessions.find(item => item.id === stagingDeleteMatch[1]);
      if (!session) return jsonResponse(response, 404, { error: 'import_session_not_found' });
      if (Array.from(rooms.values()).some(room => room.song && songLibrary.packages.some(pack => pack.sourceSessionId === session.id && pack.packageHash === room.song.packageHash)))
        return jsonResponse(response, 409, { error: 'import_session_in_use', message: '该导入目录中的歌曲正在被房间使用。' });
      const removedPackages = songLibrary.packages.filter(pack => pack.sourceSessionId === session.id);
      songLibrary.packages = songLibrary.packages.filter(pack => pack.sourceSessionId !== session.id);
      for (const pack of removedPackages) {
        if (pack.path && pathIsInside(SONG_LIBRARY_GENERATED_DIR, pack.path)) try { fs.unlinkSync(pack.path); } catch (_) {}
      }
      const index = songLibrarySessions.indexOf(session);
      if (index >= 0) songLibrarySessions.splice(index, 1);
      persistSongLibrary(); persistSongLibrarySessions();
      audit('songLibraryImportFolderDeleted', { sessionId: session.id });
      return jsonResponse(response, 200, { ok: true, sessionId: session.id, library: songLibraryView() });
    }
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/song-library')
      return jsonResponse(response, 200, { library: songLibraryView(), songs: librarySongViews().map(song => ({ songId: song.songId, songName: song.songName, artist: song.artist, packageHash: song.packageHash, packageSize: song.packageSize, charts: song.charts, coverPath: song.coverPath })) });
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/song-library/import')
      return handleSongLibraryImport(request, response);
    const libraryPackageMatch = /^\/admin\/api\/song-library\/packages\/([a-f0-9]{64})$/i.exec(requestUrl.pathname);
    if (libraryPackageMatch && request.method === 'DELETE') {
      const deleted = deleteSongLibraryPackage(libraryPackageMatch[1].toLowerCase());
      if (deleted.error) return jsonResponse(response, 400, deleted.error);
      return jsonResponse(response, 200, { ok: true, ...deleted, library: songLibraryView() });
    }
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/discord-bot')
      return jsonResponse(response, 200, { discordBot: adminDiscordBotView(), serverTime: now() });
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/discord-bot/save') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const value = updateDiscordBotConfig(result.body || {});
        discordBot.stop();
        return discordBot.start().then(() => jsonResponse(response, 200, { ok: true, reloadRequired: false, discordBot: adminDiscordBotView(), serverTime: now() }));
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/discord-bot/admin/users') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const ids = result.body?.ids;
        if (!Array.isArray(ids) || ids.length > 200 || ids.some(id => typeof id !== 'string' || !/^\d{5,25}$/.test(id.trim())))
          return jsonResponse(response, 400, { error: 'invalid_discord_admin_user_ids', message: 'Discord 管理员用户 ID 必须为数字，每次最多 200 个。' });
        config.discordBot.adminUserIds = [...new Set(ids.map(id => id.trim()))];
        saveDiscordBotConfig(config.discordBot);
        audit('discordBotAdminUsersUpdated', { count: config.discordBot.adminUserIds.length });
        return jsonResponse(response, 200, { ok: true, discordBot: adminDiscordBotView(), serverTime: now() });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/discord-bot/binding-code') {
      const code = `DC-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
      const expiresAt = now() + 10 * 60 * 1000;
      discordAdminBindingCodes.set(code, { expiresAt });
      for (const [key, value] of discordAdminBindingCodes) if (value.expiresAt <= now()) discordAdminBindingCodes.delete(key);
      audit('discordBotAdminBindingCodeCreated', { expiresAt: isoTime(expiresAt) });
      return jsonResponse(response, 201, { ok: true, code, command: `/bindadmin code:${code}`, expiresAt });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/discord-bot/reload') {
      discordBot.stop();
      return discordBot.start().then(() => jsonResponse(response, 200, { ok: true, discordBot: adminDiscordBotView(), serverTime: now() }));
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/discord-bot/start')
      return discordBot.start().then(() => jsonResponse(response, 200, { ok: true, discordBot: adminDiscordBotView(), serverTime: now() }));
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/discord-bot/stop') {
      discordBot.stop();
      return jsonResponse(response, 200, { ok: true, discordBot: adminDiscordBotView(), serverTime: now() });
    }
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/audit')
      return jsonResponse(response, 200, { audit: serverState.audit.slice(-500).reverse(), serverTime: now() });
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/groups')
      return jsonResponse(response, 200, { groups: adminGroupViews(), serverTime: now() });
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/qq-bot')
      return jsonResponse(response, 200, { qqBot: adminQqBotView(), serverTime: now() });
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/qq-bot/save') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const groupIds = result.body?.oneBotGroupAllowlist;
        if (groupIds !== undefined && (!Array.isArray(groupIds) || groupIds.length > 200 || groupIds.some(id => typeof id !== 'string' || !/^\d{5,20}$/.test(id.trim()))))
          return jsonResponse(response, 400, { error: 'invalid_onebot_group_ids', message: '群号必须为 5 至 20 位数字，每次最多 200 个。' });
        const value = updateQqBotConfig(result.body || {});
        audit('qqBotConfigUpdated', { enabled: value.enabled, appId: value.appId, sourceCount: value.sourceAllowlist.length, adminCount: value.adminOpenIds.length });
        return jsonResponse(response, 200, { ok: true, reloadRequired: true, qqBot: adminQqBotView(), serverTime: now() });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/qq-bot/reload') {
      qqBot.stop();
      return qqBot.start().then(() => jsonResponse(response, 200, { ok: true, qqBot: adminQqBotView(), serverTime: now() }));
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/qq-bot/binding-code') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const code = crypto.randomBytes(4).toString('hex').toUpperCase();
        // Binding codes remain available for the official Bot flow only.
        const platform = 'official';
        const expiresAt = now() + 10 * 60 * 1000;
        qqAdminBindingCodes.set(code, { expiresAt, platform });
        audit('qqBotBindingCodeCreated', { platform, expiresAt: isoTime(expiresAt) });
        return jsonResponse(response, 200, { code, platform, expiresAt, command: `/bindadmin ${code}` });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/qq-bot/admin/qq-ids') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const ids = Array.isArray(result.body?.ids) ? result.body.ids : [];
        if (ids.length > 200 || ids.some(id => typeof id !== 'string' || !/^\d{5,20}$/.test(id.trim())))
          return jsonResponse(response, 400, { error: 'invalid_qq_admin_ids', message: 'QQ 管理员必须是 5 至 20 位数字，每次最多 200 个。' });
        config.qqBot.adminQqIds = [...new Set(ids.map(id => id.trim()))];
        serverState.qqBotAdminQqIds = [...config.qqBot.adminQqIds];
        persistServerState();
        saveQqBotConfig(config.qqBot);
        audit('qqBotQqAdminsUpdated', { count: config.qqBot.adminQqIds.length });
        return jsonResponse(response, 200, { ok: true, qqBot: adminQqBotView(), serverTime: now() });
      });
    }
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/groups/join-codes')
      return jsonResponse(response, 200, { joinCodes: adminJoinCodeViews(), serverTime: now() });
    if (request.method === 'GET' && requestUrl.pathname === '/admin/api/groups/join-code-uses')
      return jsonResponse(response, 200, { uses: serverState.joinCodeUses.slice(-500).reverse(), serverTime: now() });
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/groups/join-codes') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const body = result.body || {};
        const created = createGroupJoinCodes(body.groupId, body.count, body.maxUses, 'web-admin');
        if (created.error) return jsonResponse(response, 400, created.error);
        // Plaintext codes are returned only in this response so the browser can
        // immediately download them. They are never persisted on the server.
        return jsonResponse(response, 200, { ok: true, groupId: created.groupId, groupName: created.groupName, codes: created.codes, records: created.records, serverTime: now() });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/groups/join-codes/status') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const value = setGroupJoinCodeStatus(result.body?.codeId, result.body?.enabled);
        if (value.error) return jsonResponse(response, 400, value.error);
        return jsonResponse(response, 200, { ok: true, record: value.record, serverTime: now() });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/qq-bot/admin/remove') {
      return readJsonBody(request).then(result => {
        const platform = result.body?.platform === 'onebot' ? 'onebot' : 'official';
        const id = String(result.body?.id || result.body?.openId || '');
        const field = platform === 'onebot' ? 'adminQqIds' : 'adminOpenIds';
        config.qqBot[field] = config.qqBot[field].filter(item => item !== id);
        serverState[platform === 'onebot' ? 'qqBotAdminQqIds' : 'qqBotAdminOpenIds'] = [...config.qqBot[field]];
        persistServerState();
        saveQqBotConfig(config.qqBot); audit('qqBotAdminRemoved', { platform, id });
        return jsonResponse(response, 200, { ok: true, qqBot: adminQqBotView() });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/qq-bot/start') {
      return qqBot.start().then(() => jsonResponse(response, 200, { ok: true, qqBot: adminQqBotView(), serverTime: now() }));
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/qq-bot/stop') {
      qqBot.stop();
      return jsonResponse(response, 200, { ok: true, qqBot: adminQqBotView(), serverTime: now() });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/groups/save') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const body = result.body || {};
        const error = saveGroup(body.groupId, body.name, body.createRoomLimit, body.joinRoomLimit);
        if (error) return jsonResponse(response, 400, error);
        return jsonResponse(response, 200, { ok: true, groups: adminGroupViews(), serverTime: now() });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/groups/delete') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const body = result.body || {};
        const error = deleteGroup(typeof body.groupId === 'string' ? body.groupId : '');
        if (error) return jsonResponse(response, 400, error);
        return jsonResponse(response, 200, { ok: true, groups: adminGroupViews(), serverTime: now() });
      });
    }
    if (request.method === 'POST' && requestUrl.pathname === '/admin/api/devices/group') {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const body = result.body || {};
        const gameId = typeof body.gameId === 'string' ? body.gameId.trim().toUpperCase() : '';
        const error = assignDeviceGroup(gameId, body.groupId);
        if (error) return jsonResponse(response, 400, error);
        return jsonResponse(response, 200, { ok: true, gameId, groupId: body.groupId, serverTime: now() });
      });
    }
    if (request.method === 'POST' && (requestUrl.pathname === '/admin/api/block' || requestUrl.pathname === '/admin/api/unblock')) {
      return readJsonBody(request).then(result => {
        if (result.error) return jsonResponse(response, 400, { error: result.error });
        const body = result.body || {};
        const gameId = typeof body.gameId === 'string' ? body.gameId.trim().toUpperCase() : '';
        const blocked = requestUrl.pathname.endsWith('/block');
        const error = setGameIdBlocked(gameId, blocked, body.reason);
        if (error) return jsonResponse(response, 400, error);
        return jsonResponse(response, 200, { ok: true, gameId, blocked, serverTime: now() });
      });
    }
    return jsonResponse(response, 404, { error: 'admin_endpoint_not_found' });
  }
  if (request.method === 'GET' && requestUrl.pathname === '/health') {
    if (!isAdminAuthorized(request)) return jsonResponse(response, 401, { error: 'admin_authorization_required' });
    return jsonResponse(response, 200, {
      ok: true,
      server: 'chunithm-mobile-multiplayer',
      version: SERVER_VERSION,
      protocol: PROTOCOL_VERSION,
      rooms: rooms.size,
      clients: clients.size,
      listedRooms: publicRooms().length,
      tls: config.tls.enabled,
      idlePolicy: idlePolicy(),
      serverTime: now()
    });
  }
  if (request.method === 'GET' && requestUrl.pathname === '/api/v1/rooms') {
    if (!isAdminAuthorized(request)) return jsonResponse(response, 401, { error: 'admin_authorization_required' });
    return jsonResponse(response, 200, {
      protocol: PROTOCOL_VERSION,
      rooms: publicRooms(requestUrl.searchParams.get('search') || '', requestUrl.searchParams.get('roomId') || ''),
      serverTime: now()
    });
  }
  if (request.method === 'GET' && requestUrl.pathname === '/api/v1/config') {
    if (!isAdminAuthorized(request)) return jsonResponse(response, 401, { error: 'admin_authorization_required' });
    return jsonResponse(response, 200, {
      protocol: PROTOCOL_VERSION,
      serverVersion: SERVER_VERSION,
      websocketPath: '/ws',
      maxPlayers: PERSONAL_ROOM_MAX_PLAYERS,
      persistentRoomMaxPlayers: Math.min(PERSISTENT_ROOM_MAX_PLAYERS, config.maxPlayersPerRoom),
      roomModes: ['casual', 'normal'],
      selectionModes: ['host', 'loop'],
      sameClientVersionPerRoom: true,
      dailyRoomQuota: true,
      roomListFilters: ['idleOnly', 'notFullOnly', 'unencryptedOnly', 'mode', 'roomType'],
      serverSongLibrary: true,
      persistentRoomEditing: true,
      persistentRoomDeletion: true,
      persistentRoomIdDigits: 3,
      persistentRoomNameMaxLength: 15,
      persistentSelectionManaged: true,
      persistentRandomCountZeroLoop: true,
      discordBotAdmin: true,
      lobbyReentryCooldownSeconds: 60,
      fullChartAutoInMultiplayer: false,
      fileTransfer: true,
      transferProgress: true,
      hostTransfer: true,
      kickCooldownSeconds: 60,
      gameplaySync: true,
      idlePolicy: idlePolicy(),
      maxTransferBytes: config.maxTransferBytes,
      tlsRequiredForInternet: true
    });
  }
  return jsonResponse(response, 404, { error: 'not_found' });
}

function createServer() {
  let server;
  if (config.tls.enabled) {
    const keyPath = path.resolve(__dirname, config.tls.keyPath);
    const certPath = path.resolve(__dirname, config.tls.certPath);
    if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
      throw new Error(`TLS is enabled but certificate files are missing: ${keyPath}, ${certPath}`);
    }
    server = https.createServer({ key: fs.readFileSync(keyPath), cert: fs.readFileSync(certPath) }, handleHttp);
  } else {
    server = http.createServer(handleHttp);
  }

  server.on('upgrade', (request, socket, head) => {
    const requestUrl = new URL(request.url, config.tls.enabled ? 'https://localhost' : 'http://localhost');
    const ip = normalizeIp(request.socket.remoteAddress);
    if (requestUrl.pathname !== '/ws') return socket.destroy();
    if (clients.size >= config.maxConnections || !canAcceptIp(ip)) {
      socket.write('HTTP/1.1 429 Too Many Requests\r\nConnection: close\r\n\r\n');
      return socket.destroy();
    }
    const key = request.headers['sec-websocket-key'];
    if (typeof key !== 'string' || key.length < 16 || request.headers.upgrade?.toLowerCase() !== 'websocket') return socket.destroy();
    const accept = crypto.createHash('sha1').update(key + WEBSOCKET_GUID).digest('base64');
    socket.write([
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${accept}`,
      '\r\n'
    ].join('\r\n'));
    attachClient(socket, ip, head);
  });
  return server;
}

function cleanup() {
  const cutoff = now() - config.roomIdleMinutes * 60 * 1000;
  const transferCutoff = now() - config.transferRetentionMinutes * 60 * 1000;
  const reservationTime = now();
  for (const [roomId, reservation] of reservedRoomIds) {
    if (reservation.expiresAt <= reservationTime) reservedRoomIds.delete(roomId);
  }
  for (const room of rooms.values()) {
    if (room.persistent === true) {
      if (room.members.size === 0) {
        room.hostPlayerId = '';
        room.ownerPlayerId = '';
        room.clientVersion = '';
        room.songChangeVoteActive = false;
        if (room.songChangeVotes instanceof Set) room.songChangeVotes.clear();
        releaseRoomTransfer(room);
        room.song = null;
        room.state = 'lobby';
        room.roundId = null;
        room.startAt = 0;
        room.updatedAt = now();
        persistPersistentRooms();
      } else if (room.state === 'groupResults' && room.updatedAt < cutoff) {
        returnRoomToLobby(room);
      }
    } else if (room.members.size === 0 || (room.state === 'groupResults' && room.updatedAt < cutoff)) {
      destroyRoom(room);
      continue;
    }
    if (room.persistent === true && room.members.size > 0 && room.state === 'lobby' &&
        room.librarySelection?.mode === 'random' && room.librarySelection.randomCount === 0 && room.hostPlayerId) {
      selectLibrarySongForRoom(room, { excludeSongId: room.song?.songId || '' });
    }
    if (room.transfer && room.transfer.ready && room.transfer.uploadedAt < transferCutoff) {
      releaseRoomTransfer(room);
      if (room.song) {
        room.song.transferReady = false;
        room.song.transferProgress = 0;
        room.song.transferDirection = '';
        room.song.transferState = '';
        room.song.transferPlayerId = '';
      }
      broadcastRoom(room, { type: 'transferExpired', roomId: room.id, serverTime: now() });
      broadcastRoomSnapshot(room);
    }
  }
  const referencedTransfers = new Set(Array.from(rooms.values())
    .map(room => room.transfer && room.transfer.path)
    .filter(Boolean)
    .map(filePath => path.resolve(filePath)));
  try {
    for (const entry of fs.readdirSync(TRANSFER_DIR, { withFileTypes: true })) {
      if (!entry.isFile()) continue;
      const filePath = path.resolve(TRANSFER_DIR, entry.name);
      if (referencedTransfers.has(filePath)) continue;
      const stat = fs.statSync(filePath);
      if (stat.mtimeMs < transferCutoff) fs.unlinkSync(filePath);
    }
  } catch (_) {
    // Orphan cleanup is best effort.
  }
  broadcastRoomLists();
}

function heartbeat() {
  const current = now();
  const idleTimeoutMs = config.idleClientMinutes * 60 * 1000;
  const idleWarningMs = config.idleWarningSeconds * 1000;
  const backgroundTimeoutMs = config.backgroundTimeoutMinutes * 60 * 1000;
  for (const client of clients) {
    if (!client.hello && current - client.connectedAt > 10000) {
      closeClient(client, 1008, 'Hello timeout');
      continue;
    }
    if (!client.alive) {
      closeClient(client, 1001, 'Heartbeat timeout');
      continue;
    }
    if (client.hello && client.backgroundAt && current - client.backgroundAt >= backgroundTimeoutMs) {
      audit('backgroundClientDisconnected', {
        gameId: client.gameId,
        roomId: client.roomId,
        backgroundMinutes: config.backgroundTimeoutMinutes
      });
      send(client, {
        type: 'backgroundTimeout',
        message: '等待超时',
        timeoutMinutes: config.backgroundTimeoutMinutes,
        serverTime: current
      });
      removeFromRoom(client, 'background-timeout', true);
      closeClient(client, 1008, 'Background timeout');
      continue;
    }
    if (client.hello && isClientIdleExempt(client)) {
      client.lastActivityAt = current;
      client.idleWarningSent = false;
    } else if (client.hello) {
      const idleMs = current - client.lastActivityAt;
      if (idleMs >= idleTimeoutMs) {
        const idleMinutes = Math.floor(idleMs / 60000);
        audit('idleClientDisconnected', { gameId: client.gameId, roomId: client.roomId, idleMinutes });
        send(client, {
          type: 'idleTimeout',
          idleMinutes,
          serverTime: current
        });
        removeFromRoom(client, 'idle-timeout', true);
        closeClient(client, 1008, 'Idle timeout');
        continue;
      }
      if (!client.idleWarningSent && idleMs >= idleTimeoutMs - idleWarningMs) {
        const remainingSeconds = Math.max(1, Math.ceil((idleTimeoutMs - idleMs) / 1000));
        client.idleWarningSent = true;
        send(client, {
          type: 'idleWarning',
          disconnectAt: current + remainingSeconds * 1000,
          remainingSeconds,
          serverTime: current
        });
      }
    }
    client.alive = false;
    if (!client.closed) client.socket.write(makeFrame(Buffer.alloc(0), 0x9));
  }
}

function start() {
  let server;
  try {
    server = createServer();
  } catch (error) {
    console.error(`[startup] ${error.message}`);
    process.exitCode = 1;
    return null;
  }
  server.on('error', error => console.error(`[server] ${error.message}`));
  server.listen(config.port, config.host, () => {
    const scheme = config.tls.enabled ? 'wss' : 'ws';
    console.log(`CHUNITHM Mobile multiplayer server ${SERVER_VERSION}`);
    console.log(`WebSocket: ${scheme}://${config.host}:${config.port}/ws`);
    console.log(`Health: ${config.tls.enabled ? 'https' : 'http'}://${config.host}:${config.port}/health`);
    console.log(`Admin: ${config.tls.enabled ? 'https' : 'http'}://127.0.0.1:${config.port}/admin-v2`);
    console.log(`Limits: ${config.maxConnections} clients, ${config.maxRooms} rooms, ${config.maxPlayersPerRoom} players per room`);
    console.log(`Idle timeout: ${config.idleClientMinutes} minutes (warning ${config.idleWarningSeconds} seconds before disconnect)`);
    if (process.env.CHUNITHM_TOKEN_DISPLAYED !== '1')
      console.log(`[security] Administrator token for this start: ${adminToken}`);
    if (!config.tls.enabled && config.tls.domain && config.host === '127.0.0.1')
      console.log(`[security] TLS is terminated by Caddy for ${config.tls.domain}; Node is loopback-only.`);
    else if (!config.tls.enabled)
      console.warn('[security] TLS is disabled. Use this only on a trusted LAN or enable TLS before port forwarding.');
    if (!config.authToken) console.warn('[security] authToken is empty. Set a long random token before exposing the port to the Internet.');
    if (config.qqBot.enabled && config.qqBot.appId && config.qqBot.appSecret) {
      qqBot.start().catch(error => console.error(`[qq-bot] startup failed: ${error.message}`));
    } else {
      console.log('[qq-bot] disabled or not configured. Use /admin-v2 to configure it.');
    }
    if (config.discordBot.enabled && config.discordBot.token) {
      discordBot.start().catch(error => console.error(`[discord-bot] startup failed: ${error.message}`));
    } else {
      console.log('[discord-bot] disabled or not configured. Use /admin-v2 to configure it.');
    }
  });
  const heartbeatTimer = setInterval(heartbeat, 15000);
  const cleanupTimer = setInterval(cleanup, 60000);
  heartbeatTimer.unref();
  cleanupTimer.unref();
  const shutdown = signal => {
    console.log(`[server] ${signal}, shutting down`);
    clearInterval(heartbeatTimer);
    clearInterval(cleanupTimer);
    qqBot.stop();
    discordBot.stop();
    for (const client of clients) closeClient(client, 1001, 'Server shutting down');
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 1000).unref();
  };
  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  return server;
}

if (require.main === module) start();

module.exports = { start, validateRoomModeAndMods, normalizeMods, isScoringMods };
