@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%PS%" goto :powershell_ready
echo Windows PowerShell was not found.
pause
exit /b 1
:powershell_ready
echo 1. 中文
echo 2. English
choice /c 12 /n /m "请选择语言 / Select language: "
if errorlevel 2 goto :english
if errorlevel 1 goto :chinese
goto :end
:chinese
call "%~dp0setup-wss-zh.bat"
goto :end
:english
call "%~dp0setup-wss-en.bat"
:end
if errorlevel 1 pause
