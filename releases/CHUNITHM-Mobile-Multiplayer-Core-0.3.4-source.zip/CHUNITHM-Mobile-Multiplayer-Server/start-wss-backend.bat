@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title CHUNITHM Server Backend
echo Starting CHUNITHM server from %CD%
echo Startup time: %date% %time% > "%~dp0server-startup.log"
node start-server.js
set "EXIT_CODE=%ERRORLEVEL%"
echo.
echo Server exited with code %EXIT_CODE%.
echo Review the messages above for the startup error.
pause
exit /b %EXIT_CODE%
