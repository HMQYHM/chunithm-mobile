BongoCat Live2D 平板触控示例皮肤

本包使用 BongoCat gamepad 模型资源和自定义透明平板图。
游戏接口会提供左右触控区域的中心点、按下状态和运动速度。

当前版本已接入 Cubism SDK for Unity。导入本包后，游戏会在游玩界面加载模型，
并将左右触控区域的中心点和按下状态映射到模型参数。模型位置由
ui/gameplay-ui.json 中 live2d 的 x、y、width、height 决定。

模型加载由游戏内置适配器完成，皮肤包只提供数据文件，不执行 C#、DLL、Prefab、
Shader 或原生代码。

素材来源：
https://github.com/vladelaina/BongoCat

模型素材许可：MIT，完整文本见 LICENSE-MIT.txt。
BongoCat 源码和原生运行时代码没有放入本皮肤包。
