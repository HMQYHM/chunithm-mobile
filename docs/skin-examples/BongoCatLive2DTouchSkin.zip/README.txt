BongoCat Live2D 平板触控示例皮肤

本包使用 BongoCat gamepad 模型资源和自定义透明平板图。
游戏接口会提供左右触控区域的中心点、按下状态和运动速度。

当前工程尚未安装 Cubism SDK for Unity，因此模型文件可以安全导入和读取配置，
但暂时不会在游戏内渲染 Live2D 模型。接入 Cubism SDK 后即可使用同一配置。

素材来源：
https://github.com/vladelaina/BongoCat

模型素材许可：MIT，完整文本见 LICENSE-MIT.txt。
BongoCat 源码和原生运行时代码没有放入本皮肤包。
