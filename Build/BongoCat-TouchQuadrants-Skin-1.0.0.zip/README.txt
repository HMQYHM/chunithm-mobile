BongoCat 四区触控示例皮肤

这是一个用于验证安全皮肤接口的示例包：

- 触控板按左上、左下、右上、右下四区发布状态。
- 皮肤只能读取触控、AIR、判定、Combo、分数和评级事件。
- 不包含 C#、DLL、Prefab、Shader 或 BongoCat 原生运行时代码。
- 当前四区图片使用同一份 MIT 模型封面素材，分别作为四个动作资源占位；
  真实动作应由后续皮肤资源提供者制作对应 PNG 帧。
- gameplay-ui.json 中保留 Combo、分数数字和分数预警特效的接口配置示例。

安装：在游戏的游玩皮肤管理界面导入本 ZIP 文件。

素材来源：
https://github.com/vladelaina/BongoCat

许可：
本包中的 BongoCat 模型素材依据仓库 LICENSE-MIT 使用，完整文本见 LICENSE-MIT.txt。
BongoCat 源码和原生运行时不包含在本包中。
