# CHUNITHM Mobile Multiplayer Core Server

这是 CHUNITHM Mobile 的公开联机核心服务端。它使用 Node.js 18+ 内置模块，不需要 npm 运行时依赖。

## 包含内容

- WebSocket `/ws` 房间协议
- 房间创建、加入、房主转移、准备和回合状态同步
- 歌曲 ZIP 的房主上传、成员下载、SHA-256 校验和 HTTP Range 断点续传
- 设备 Game ID、客户端版本一致性、房间/加入配额和连接限制
- 管理员健康检查、配置查询和协议烟测

## 启动

```text
node start-server.js
```

默认监听 `27960`。首次启动会生成一次性管理员令牌。复制 `config.example.json` 为 `config.json`，设置长随机 `authToken`；公网部署必须配置 TLS/WSS。

## 烟测

```text
node smoke-test.js
```

烟测覆盖房间预约、配额、上传鉴权、Range 下载、同步、加载、平局结算和房主轮换。

## 公开范围

本目录只发布联机核心。QQ Bot、Bot 测试、Bot 凭据、管理后台网页、加入码扩展和运行时 `data/` 不包含在公开仓库中；这些属于部署者自己的运维扩展。

本服务端不保存任何生产配置或密钥。
