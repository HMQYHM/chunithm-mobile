'use strict';

const assert = require('assert');
const crypto = require('crypto');
const net = require('net');
const path = require('path');

const HOST = process.env.TEST_HOST || '127.0.0.1';
const PORT = Number(process.env.TEST_PORT || 27960);
const BASE_URL = `http://${HOST}:${PORT}`;

function localAdminToken() {
  if (process.env.TEST_ADMIN_TOKEN) return process.env.TEST_ADMIN_TOKEN;
  if (HOST !== '127.0.0.1' && HOST !== 'localhost') return '';
  try {
    const dataDir = process.env.CHUNITHM_DATA_DIR || path.join(__dirname, 'data');
    return require(path.join(dataDir, 'security.json')).adminToken || '';
  } catch (_) { return ''; }
}

function adminHeaders() {
  const token = localAdminToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

const sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

async function adminDevices() {
  const response = await fetch(`${BASE_URL}/admin/api/devices`, { headers: adminHeaders() });
  assert.strictEqual(response.status, 200);
  return (await response.json()).devices;
}

function clientFrame(value) {
  const body = Buffer.from(JSON.stringify(value));
  const mask = crypto.randomBytes(4);
  const header = body.length < 126 ? Buffer.from([0x81, 0x80 | body.length]) : Buffer.from([0x81, 0xFE, body.length >> 8, body.length & 0xFF]);
  const encoded = Buffer.alloc(body.length);
  for (let index = 0; index < body.length; index += 1) encoded[index] = body[index] ^ mask[index % 4];
  return Buffer.concat([header, mask, encoded]);
}

function connect(playerName, deviceId, clientVersion = '0.2.4-smoke') {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection(PORT, HOST);
    const client = { socket, buffer: Buffer.alloc(0), messages: [], waiters: [] };
    const key = crypto.randomBytes(16).toString('base64');
    const request = [
      'GET /ws HTTP/1.1',
      `Host: ${HOST}:${PORT}`,
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Key: ${key}`,
      'Sec-WebSocket-Version: 13',
      '\r\n'
    ].join('\r\n');
    let handshakeDone = false;

    const dispatch = message => {
      client.messages.push(message);
      for (const waiter of client.waiters.slice()) {
        if (!waiter.predicate(message)) continue;
        client.waiters.splice(client.waiters.indexOf(waiter), 1);
        clearTimeout(waiter.timer);
        waiter.resolve(message);
      }
    };

    const parseFrames = () => {
      while (client.buffer.length >= 2) {
        const opcode = client.buffer[0] & 0x0F;
        let length = client.buffer[1] & 0x7F;
        let headerLength = 2;
        if (length === 126) {
          if (client.buffer.length < 4) return;
          length = client.buffer.readUInt16BE(2);
          headerLength = 4;
        } else if (length === 127) {
          if (client.buffer.length < 10) return;
          length = Number(client.buffer.readBigUInt64BE(2));
          headerLength = 10;
        }
        if (client.buffer.length < headerLength + length) return;
        const payload = client.buffer.subarray(headerLength, headerLength + length);
        client.buffer = client.buffer.subarray(headerLength + length);
        if (opcode === 0x1) dispatch(JSON.parse(payload.toString('utf8')));
        else if (opcode === 0x9) socket.write(Buffer.concat([Buffer.from([0x8A, 0x80]), crypto.randomBytes(4)]));
      }
    };

    socket.on('connect', () => socket.write(request));
    socket.on('data', data => {
      client.buffer = Buffer.concat([client.buffer, data]);
      if (!handshakeDone) {
        const marker = client.buffer.indexOf('\r\n\r\n');
        if (marker < 0) return;
        assert.match(client.buffer.subarray(0, marker).toString('utf8'), /^HTTP\/1\.1 101 Switching Protocols/m);
        client.buffer = client.buffer.subarray(marker + 4);
        handshakeDone = true;
        client.send({ type: 'hello', protocol: 2, clientVersion, playerName, deviceId });
      }
      parseFrames();
    });
    socket.on('error', reject);
    socket.on('close', () => {
      for (const waiter of client.waiters.splice(0)) waiter.reject(new Error('socket closed'));
    });
    client.send = message => socket.write(clientFrame(message));
    client.waitFor = (type, timeout = 5000, predicate = null) => new Promise((waitResolve, waitReject) => {
      const matches = value => value.type === type && (!predicate || predicate(value));
      const queued = client.messages.find(matches);
      if (queued) return waitResolve(queued);
      const waiter = { predicate: matches, resolve: waitResolve, reject: waitReject };
      waiter.timer = setTimeout(() => {
        client.waiters.splice(client.waiters.indexOf(waiter), 1);
        waitReject(new Error(`Timed out waiting for ${type}`));
      }, timeout);
      client.waiters.push(waiter);
    });
    client.close = () => socket.destroy();
    client.waitFor('helloAccepted').then(message => {
      client.hello = message;
      resolve(client);
    }).catch(reject);
  });
}

async function main() {
  const healthResponse = await fetch(`${BASE_URL}/health`, { headers: adminHeaders() });
  if (!localAdminToken()) {
    assert.strictEqual(healthResponse.status, 401);
  }
  const health = localAdminToken() ? await healthResponse.json() : { protocol: 2 };
  assert.strictEqual(health.ok, true);
  assert.strictEqual(health.protocol, 2);
  assert.strictEqual(health.idlePolicy.backgroundTimeoutMinutes, 10);
  const configResponse = await fetch(`${BASE_URL}/api/v1/config`, { headers: adminHeaders() });
  const serverConfig = localAdminToken() ? await configResponse.json() : {};
  if (!localAdminToken()) assert.strictEqual(configResponse.status, 401);
  assert.strictEqual(serverConfig.fileTransfer, true);
  assert.strictEqual(serverConfig.gameplaySync, true);

  const unique = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}`;
  // Verify that a nickname survives disconnecting, then that the latest name
  // replaces it while the previous name remains in the server-side history.
  const historyDeviceId = `history-${unique}`;
  const firstNameClient = await connect('历史甲', historyDeviceId);
  const historyGameId = firstNameClient.hello.gameId;
  firstNameClient.close();
  await sleep(100);
  let historyDevice = (await adminDevices()).find(device => device.gameId === historyGameId);
  assert.ok(historyDevice);
  assert.strictEqual(historyDevice.online, false);
  assert.strictEqual(historyDevice.playerName, '历史甲');
  assert.strictEqual(historyDevice.lastPlayerName, '历史甲');

  const secondNameClient = await connect('历史乙', historyDeviceId);
  secondNameClient.close();
  await sleep(100);
  historyDevice = (await adminDevices()).find(device => device.gameId === historyGameId);
  assert.ok(historyDevice);
  assert.strictEqual(historyDevice.online, false);
  assert.strictEqual(historyDevice.playerName, '历史乙');
  assert.deepStrictEqual(
    historyDevice.playerNameHistory.map(entry => entry.name).sort(),
    ['历史甲', '历史乙'].sort()
  );

  const host = await connect('联甲', `host-${unique}`);
  const guest = await connect('联乙', `guest-${unique}`);
  try {
    assert.match(host.hello.gameId, /^GM[A-Z0-9]{10}$/);
    assert.strictEqual(host.hello.capabilities.fileTransfer, true);

    const quotaBefore = host.hello.quota.createRoomRemaining;
    host.send({ type: 'reserveRoomId' });
    const firstReservation = await host.waitFor('roomIdReserved');
    assert.match(firstReservation.roomId, /^\d{6}$/);
    host.send({ type: 'releaseRoomId' });
    await host.waitFor('roomIdReleased');
    host.send({ type: 'listRooms' });
    const roomListAfterCancel = await host.waitFor('roomList', 5000, message => message.quota.createRoomRemaining === quotaBefore);
    assert.strictEqual(roomListAfterCancel.quota.createRoomRemaining, quotaBefore);

    host.send({ type: 'reserveRoomId' });
    const reservation = await host.waitFor('roomIdReserved', 5000, message => message.roomId !== firstReservation.roomId);
    host.send({
      type: 'createRoom', reservedRoomId: reservation.roomId, roomName: '联测', roomMode: 'normal', maxPlayers: 2,
      selectionMode: 'loop', listed: true, mods: { airLongNoMotion: true, flickSimpleMode: true, musicRate: 1 }
    });
    const created = await host.waitFor('roomCreated');
    assert.strictEqual(created.room.roomId, reservation.roomId);
    assert.strictEqual(created.quota.createRoomRemaining, quotaBefore - 1);

    host.send({ type: 'listRooms', search: 'this-room-does-not-match', idleOnly: false,
      notFullOnly: false, unencryptedOnly: false, mode: '' });
    const filteredList = await host.waitFor('roomList', 5000,
      message => message.rooms.length === 0 && message.filters.mode === '');
    assert.strictEqual(filteredList.rooms.length, 0);

    // A room update broadcasts a fresh list; the query must survive that broadcast.
    guest.send({ type: 'joinRoom', roomId: created.room.roomId });
    const joined = await guest.waitFor('roomJoined');
    assert.strictEqual(joined.room.members.length, 2);
    host.send({ type: 'updateRoomSettings', roomMode: 'normal', selectionMode: 'loop',
      mods: { mirrorChart: true, airLongNoMotion: true, fullscreenTouchpad: true, musicRate: 1 } });
    const rejectedFullscreen = await host.waitFor('error', 5000,
      message => message.code === 'MOD_NOT_ALLOWED_IN_NORMAL');
    assert.strictEqual(rejectedFullscreen.code, 'MOD_NOT_ALLOWED_IN_NORMAL');
    host.send({ type: 'updateRoomSettings', roomMode: 'casual', selectionMode: 'loop',
      mods: { mirrorChart: true, airLongNoMotion: true, fullscreenTouchpad: true, musicRate: 1 } });
    const casualSettings = await host.waitFor('roomSettingsUpdated', 5000,
      message => message.room.mode === 'casual' && message.room.mods.fullscreenTouchpad);
    assert.strictEqual(casualSettings.room.mods.fullscreenTouchpad, true);
    host.send({ type: 'updateRoomSettings', roomMode: 'normal', selectionMode: 'loop',
      mods: { mirrorChart: true, airLongNoMotion: true, fullscreenTouchpad: false, musicRate: 1 } });
    await host.waitFor('roomSettingsUpdated', 5000,
      message => message.room.mode === 'normal' && !message.room.mods.fullscreenTouchpad);
    const filteredBroadcast = await host.waitFor('roomList', 5000,
      message => message.rooms.length === 0 && message.filters.mode === '');
    assert.strictEqual(filteredBroadcast.rooms.length, 0);

    const songPackage = Buffer.from('PK\u0003\u0004CHUNITHM-MULTIPLAYER-SMOKE-PACKAGE');
    const packageHash = crypto.createHash('sha256').update(songPackage).digest('hex');
    const chartHash = crypto.createHash('sha256').update('smoke-chart').digest('hex');
    host.send({
      type: 'selectSong', songId: 'SMOKE_TEST', songName: '联机测试曲', artist: 'Codex',
      chartPath: 'smoke-test.c2s', difficulty: 'MASTER', level: '14', chartHash,
      packageHash, packageSize: songPackage.length
    });
    await host.waitFor('songSelected');

    const transferUrl = `${BASE_URL}/api/v1/transfers/${created.room.roomId}/${packageHash}`;
    const unauthorized = await fetch(transferUrl, { method: 'POST', body: songPackage });
    assert.strictEqual(unauthorized.status, 401);
    const guestUpload = await fetch(transferUrl, {
      method: 'POST', headers: { Authorization: `Bearer ${guest.hello.sessionToken}` }, body: songPackage
    });
    assert.strictEqual(guestUpload.status, 403);
    const upload = await fetch(transferUrl, {
      method: 'POST', headers: { Authorization: `Bearer ${host.hello.sessionToken}` }, body: songPackage
    });
    assert.strictEqual(upload.status, 201);
    await guest.waitFor('transferReady');

    const partialDownload = await fetch(transferUrl, {
      headers: { Authorization: `Bearer ${guest.hello.sessionToken}`, Range: 'bytes=4-' }
    });
    assert.strictEqual(partialDownload.status, 206);
    assert.deepStrictEqual(Buffer.from(await partialDownload.arrayBuffer()), songPackage.subarray(4));

    host.send({ type: 'setMemberBest', packageHash, score: 1000000, rank: 'SS' });
    guest.send({ type: 'setMemberBest', packageHash, score: 990000, rank: 'S+' });
    guest.send({ type: 'setSongSyncStatus', packageHash, ready: true, progress: 1 });
    await host.waitFor('roomUpdated', 5000, message => message.room.members.every(member => member.songReady));
    host.send({ type: 'setReady', ready: true });
    guest.send({ type: 'setReady', ready: true });
    const preparing = await host.waitFor('roundPreparing');
    host.send({ type: 'setRoundLoaded', roundId: preparing.roundId });
    guest.send({ type: 'setRoundLoaded', roundId: preparing.roundId });
    const starting = await host.waitFor('roundStarting');
    assert.ok(starting.startAt > starting.serverTime);

    const result = {
      type: 'submitResult', roundId: preparing.roundId, justiceCritical: 900, justice: 80,
      attack: 10, miss: 10, maxCombo: 500
    };
    host.send(result);
    guest.send(result);
    await Promise.all([host.waitFor('resultAccepted'), guest.waitFor('resultAccepted')]);
    await host.waitFor('allPlayersFinished');
    host.send({ type: 'confirmPersonalResult' });
    guest.send({ type: 'confirmPersonalResult' });
    const groupResults = await host.waitFor('groupResultsAvailable');
    assert.strictEqual(groupResults.leaderboard.length, 2);
    assert.strictEqual(groupResults.leaderboard[0].placement, 1);
    assert.strictEqual(groupResults.leaderboard[1].placement, 1);

    host.send({ type: 'confirmGroupResult' });
    guest.send({ type: 'confirmGroupResult' });
    const returned = await host.waitFor('returnedToLobby');
    assert.strictEqual(returned.room.hostPlayerId, guest.hello.gameId);
    assert.strictEqual(returned.room.members.every(member => !member.ready), true);

    guest.send({ type: 'leaveRoom' });
    await guest.waitFor('roomLeft');
    host.send({ type: 'leaveRoom' });
    await host.waitFor('roomLeft');
    console.log(JSON.stringify({
      ok: true, protocol: health.protocol, roomId: created.room.roomId,
      tested: ['reservation', 'quota', 'transfer-auth', 'range-download', 'sync', 'loading', 'tie-results', 'host-rotation']
    }));
  } finally {
    host.close();
    guest.close();
  }
}

main().catch(error => {
  console.error(`SMOKE TEST FAILED: ${error.stack || error.message}`);
  process.exitCode = 1;
});
